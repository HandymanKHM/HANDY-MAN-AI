import { Job, Activity, User, Client, EmailMonitoring } from "@shared/schema";

export interface DashboardStats {
  newJobs: number;
  inProgress: number;
  completed: number;
  issues: number;
}

export interface JobWithClient extends Job {
  client: Client;
  assignedToUser?: User;
}

export interface WebSocketMessage {
  type: 'newJob' | 'jobUpdate' | 'activityUpdate' | 'emailMonitoring';
  data: any;
}

export interface AssignJobData {
  jobId: number;
  claimId: string;
  technicianId: number;
  scheduleDate: string;
  scheduleTime: string;
  notes?: string;
}

export interface AuthUser {
  id: number;
  username: string;
  email: string;
  fullName: string;
  role: string;
  mfaEnabled: boolean;
}

export interface EmailMonitoringStatus extends EmailMonitoring {
  email: string;
  lastCheckedFormatted: string;
}

export type JobStatus = 'new' | 'assigned' | 'in-progress' | 'completed' | 'issue';
export type UserRole = 'admin' | 'manager' | 'technician';
export type ServiceType = 'plumbing' | 'construction' | 'electrical' | 'general';
export type Priority = 'low' | 'medium' | 'high' | 'urgent';

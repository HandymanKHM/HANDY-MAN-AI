import { formatDistanceToNow, format, isToday, isYesterday, isTomorrow } from 'date-fns';

/**
 * Formats a date relative to now (e.g., "5 minutes ago", "2 days ago")
 */
export function formatRelativeTime(date: Date | string): string {
  if (!date) return '';
  return formatDistanceToNow(new Date(date), { addSuffix: true });
}

/**
 * Formats a date to a readable string with natural language for today, yesterday, tomorrow
 */
export function formatFriendlyDate(date: Date | string): string {
  if (!date) return '';
  const dateObj = new Date(date);
  
  if (isToday(dateObj)) {
    return `Today, ${format(dateObj, 'h:mm a')}`;
  } else if (isYesterday(dateObj)) {
    return `Yesterday, ${format(dateObj, 'h:mm a')}`;
  } else if (isTomorrow(dateObj)) {
    return `Tomorrow, ${format(dateObj, 'h:mm a')}`;
  } else {
    return format(dateObj, 'dd MMM yyyy, h:mm a');
  }
}

/**
 * Formats a date for display in a form input (YYYY-MM-DD)
 */
export function formatDateForInput(date: Date | string | null): string {
  if (!date) return '';
  return format(new Date(date), 'yyyy-MM-dd');
}

/**
 * Formats a time for display in a form input (HH:MM)
 */
export function formatTimeForInput(date: Date | string | null): string {
  if (!date) return '';
  return format(new Date(date), 'HH:mm');
}

/**
 * Gets the day of the week name
 */
export function getDayOfWeek(date: Date | string): string {
  if (!date) return '';
  return format(new Date(date), 'EEEE');
}

/**
 * Formats a date for schedule display
 */
export function formatScheduleDate(date: Date | string): string {
  if (!date) return '';
  const dateObj = new Date(date);
  
  if (isToday(dateObj)) {
    return `Today (${format(dateObj, 'd MMM')})`;
  } else if (isYesterday(dateObj)) {
    return `Yesterday (${format(dateObj, 'd MMM')})`;
  } else if (isTomorrow(dateObj)) {
    return `Tomorrow (${format(dateObj, 'd MMM')})`;
  } else {
    return format(dateObj, 'EEE, d MMM yyyy');
  }
}

/**
 * Creates a time slot string (e.g., "08:00 - 10:00")
 */
export function createTimeSlot(startHour: number, durationHours: number = 2): string {
  const start = new Date();
  start.setHours(startHour, 0, 0, 0);
  
  const end = new Date(start);
  end.setHours(start.getHours() + durationHours, 0, 0, 0);
  
  return `${format(start, 'HH:mm')} - ${format(end, 'HH:mm')}`;
}

/**
 * Generates an array of time slots for scheduling
 */
export function generateTimeSlots(startHour: number = 8, endHour: number = 18, durationHours: number = 2): string[] {
  const slots = [];
  for (let hour = startHour; hour < endHour; hour += durationHours) {
    slots.push(createTimeSlot(hour, durationHours));
  }
  return slots;
}

/**
 * Returns the next working day (skipping weekends)
 */
export function getNextWorkingDay(date: Date = new Date()): Date {
  const nextDay = new Date(date);
  nextDay.setDate(nextDay.getDate() + 1);
  
  // Skip weekends
  const dayOfWeek = nextDay.getDay();
  if (dayOfWeek === 0) { // Sunday
    nextDay.setDate(nextDay.getDate() + 1);
  } else if (dayOfWeek === 6) { // Saturday
    nextDay.setDate(nextDay.getDate() + 2);
  }
  
  return nextDay;
}

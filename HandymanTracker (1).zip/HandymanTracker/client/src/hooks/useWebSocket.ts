import { useState, useEffect, useRef, useCallback } from 'react';
import { WebSocketMessage } from '@/lib/types';
import { useAuth } from './useAuth';

type MessageHandler = (message: WebSocketMessage) => void;

export const useWebSocket = () => {
  const [isConnected, setIsConnected] = useState(false);
  const webSocketRef = useRef<WebSocket | null>(null);
  const messageHandlersRef = useRef<Map<string, MessageHandler[]>>(new Map());
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const { isAuthenticated } = useAuth();

  const connect = useCallback(() => {
    if (webSocketRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    // Close existing connection if any
    if (webSocketRef.current) {
      webSocketRef.current.close();
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    webSocketRef.current = ws;

    ws.addEventListener('open', () => {
      console.log('WebSocket connection established');
      setIsConnected(true);
      
      // Clear any reconnect timeout
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
    });

    ws.addEventListener('close', () => {
      console.log('WebSocket connection closed');
      setIsConnected(false);
      
      // Attempt to reconnect after a delay
      if (!reconnectTimeoutRef.current && isAuthenticated) {
        reconnectTimeoutRef.current = setTimeout(() => {
          connect();
          reconnectTimeoutRef.current = null;
        }, 3000);
      }
    });

    ws.addEventListener('error', (error) => {
      console.error('WebSocket error:', error);
    });

    ws.addEventListener('message', (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketMessage;
        
        // Call all handlers registered for this message type
        const handlers = messageHandlersRef.current.get(message.type) || [];
        handlers.forEach(handler => handler(message));
        
        // Call all handlers registered for '*' (all messages)
        const allHandlers = messageHandlersRef.current.get('*') || [];
        allHandlers.forEach(handler => handler(message));
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    });

    return () => {
      ws.close();
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
    };
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) {
      const cleanup = connect();
      return cleanup;
    } else {
      // Close connection if user logs out
      if (webSocketRef.current) {
        webSocketRef.current.close();
        webSocketRef.current = null;
      }
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = null;
      }
      
      setIsConnected(false);
    }
  }, [isAuthenticated, connect]);

  // Register a message handler
  const subscribe = useCallback((type: string, handler: MessageHandler) => {
    const handlers = messageHandlersRef.current.get(type) || [];
    handlers.push(handler);
    messageHandlersRef.current.set(type, handlers);
    
    // Return unsubscribe function
    return () => {
      const currentHandlers = messageHandlersRef.current.get(type) || [];
      messageHandlersRef.current.set(
        type,
        currentHandlers.filter(h => h !== handler)
      );
    };
  }, []);

  // Send a message to the server
  const send = useCallback((data: any) => {
    if (webSocketRef.current?.readyState === WebSocket.OPEN) {
      webSocketRef.current.send(JSON.stringify(data));
      return true;
    }
    return false;
  }, []);

  return {
    isConnected,
    subscribe,
    send
  };
};

export default useWebSocket;

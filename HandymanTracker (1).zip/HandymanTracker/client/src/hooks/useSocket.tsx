import { useState, useEffect, useRef } from 'react';
// Removed auth dependency

export const useSocket = () => {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isAuthenticated = true;

  useEffect(() => {
    if (!isAuthenticated) {
      if (socket) {
        socket.close();
        setSocket(null);
        setIsConnected(false);
      }
      return;
    }

    // Create WebSocket connection
    const connectWebSocket = () => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const ws = new WebSocket(wsUrl);
      
      ws.addEventListener('open', () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        
        // Clear any reconnect timer
        if (reconnectTimer.current) {
          clearTimeout(reconnectTimer.current);
          reconnectTimer.current = null;
        }
      });
      
      ws.addEventListener('close', () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        
        // Try to reconnect
        if (reconnectTimer.current) {
          clearTimeout(reconnectTimer.current);
        }
        
        reconnectTimer.current = setTimeout(() => {
          console.log('Attempting to reconnect WebSocket...');
          connectWebSocket();
        }, 3000);
      });
      
      ws.addEventListener('error', (error) => {
        console.error('WebSocket error:', error);
        ws.close();
      });
      
      setSocket(ws);
    };
    
    connectWebSocket();
    
    // Cleanup on unmount
    return () => {
      if (socket) {
        socket.close();
      }
      
      if (reconnectTimer.current) {
        clearTimeout(reconnectTimer.current);
      }
    };
  }, [isAuthenticated]);

  return { socket, isConnected };
};

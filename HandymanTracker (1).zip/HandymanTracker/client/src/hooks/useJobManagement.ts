import { useState, useEffect, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from '@/lib/queryClient';
import { useJobs } from '@/context/JobContext';
import { AssignJobData } from '@/lib/types';

export const useJobManagement = () => {
  const { toast } = useToast();
  const { 
    selectedJob,
    closeJobDetails,
    closeAssignJobModal,
    viewJobDetails,
    openAssignJobModal,
    assignJob,
    fetchJobs
  } = useJobs();
  
  const [loading, setLoading] = useState(false);
  
  // Handle job selection for viewing details
  const handleViewJobDetails = useCallback((jobId: number) => {
    viewJobDetails(jobId);
  }, [viewJobDetails]);
  
  // Handle job selection for assignment
  const handleAssignJob = useCallback((jobId: number) => {
    openAssignJobModal(jobId);
  }, [openAssignJobModal]);
  
  // Handle assignment from the details modal
  const handleAssignJobFromDetails = useCallback(() => {
    if (selectedJob) {
      closeJobDetails();
      openAssignJobModal(selectedJob.id);
    }
  }, [selectedJob, closeJobDetails, openAssignJobModal]);
  
  // Confirm assignment
  const handleConfirmAssignment = useCallback(async (data: AssignJobData) => {
    setLoading(true);
    try {
      const success = await assignJob(data);
      
      if (success) {
        closeAssignJobModal();
        toast({
          title: "Job Assigned",
          description: `Job ${data.claimId} has been successfully assigned.`,
        });
        
        // Refresh jobs list
        await fetchJobs();
      }
    } catch (error) {
      console.error("Error assigning job:", error);
      toast({
        title: "Assignment Failed",
        description: "Failed to assign job. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [assignJob, closeAssignJobModal, toast, fetchJobs]);
  
  // Update job status
  const updateJobStatus = useCallback(async (jobId: number, status: string) => {
    setLoading(true);
    try {
      const res = await apiRequest('PUT', `/api/jobs/${jobId}/status`, { status });
      
      if (res.ok) {
        toast({
          title: "Status Updated",
          description: `Job status has been updated to ${status}.`,
        });
        
        // Refresh jobs list
        await fetchJobs();
        
        // If details modal is open, refresh it
        if (selectedJob && selectedJob.id === jobId) {
          viewJobDetails(jobId);
        }
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error("Error updating job status:", error);
      toast({
        title: "Update Failed",
        description: "Failed to update job status. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast, fetchJobs, selectedJob, viewJobDetails]);
  
  return {
    loading,
    handleViewJobDetails,
    handleAssignJob,
    handleAssignJobFromDetails,
    handleConfirmAssignment,
    updateJobStatus
  };
};

export default useJobManagement;

import { useState } from "react";
import { JobWithClient } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

interface JobDetailModalProps {
  job: JobWithClient | null;
  isOpen: boolean;
  onClose: () => void;
  onAssign: () => void;
}

const JobDetailModal = ({ job, isOpen, onClose, onAssign }: JobDetailModalProps) => {
  if (!isOpen || !job) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-5xl sm:w-full">
          <div className="flex justify-between items-center px-6 py-4 bg-primary text-white">
            <h3 className="text-lg font-medium font-heading">Job {job.claimId} Details</h3>
            <button className="text-white hover:text-gray-200 focus:outline-none" onClick={onClose}>
              <span className="material-icons">close</span>
            </button>
          </div>
          <div className="bg-white p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <div className="mb-6">
                  <h4 className="text-lg font-medium text-gray-800 mb-3 font-heading">Client Information</h4>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Name</p>
                        <p className="font-medium text-gray-900">{job.client?.name || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Contact Number</p>
                        <p className="font-medium text-gray-900">{job.client?.phone || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Email</p>
                        <p className="font-medium text-gray-900">{job.client?.email || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Insurance Policy</p>
                        <p className="font-medium text-gray-900">{job.client?.policyNumber || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mb-6">
                  <h4 className="text-lg font-medium text-gray-800 mb-3 font-heading">Job Information</h4>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                      <div>
                        <p className="text-gray-500">Claim ID</p>
                        <p className="font-medium text-gray-900">{job.claimId}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Service Type</p>
                        <p className="font-medium text-gray-900">{job.serviceType}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Insurer</p>
                        <p className="font-medium text-gray-900">{job.client?.insurer || 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Status</p>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          job.status === 'new' ? 'bg-blue-100 text-blue-800' :
                          job.status === 'assigned' ? 'bg-yellow-100 text-yellow-800' :
                          job.status === 'in-progress' ? 'bg-orange-100 text-orange-800' :
                          job.status === 'completed' ? 'bg-green-100 text-green-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                        </span>
                      </div>
                    </div>
                    <div className="text-sm">
                      <p className="text-gray-500 mb-2">Description</p>
                      <p className="text-gray-800">{job.description || 'No description provided'}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-medium text-gray-800 mb-3 font-heading">Location</h4>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm mb-4">
                      <p className="text-gray-500 mb-1">Address</p>
                      <p className="font-medium text-gray-900">{job.location || 'Address not provided'}</p>
                    </div>
                    <div className="h-48 bg-gray-200 rounded-lg flex items-center justify-center">
                      <span className="text-gray-500">Map Location</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="mb-6">
                  <h4 className="text-lg font-medium text-gray-800 mb-3 font-heading">Assignment</h4>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="mb-4">
                      <label htmlFor="technician" className="block text-sm font-medium text-gray-700 mb-1">Select Technician</label>
                      <select id="technician" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md">
                        <option selected disabled>Select a technician</option>
                        <option>David Miller - Plumbing</option>
                        <option>Robert Johnson - Plumbing</option>
                        <option>Sarah Adams - Construction</option>
                        <option>Michael Thompson - Construction</option>
                      </select>
                    </div>
                    <div className="mb-4">
                      <label htmlFor="schedule-date" className="block text-sm font-medium text-gray-700 mb-1">Schedule Date</label>
                      <input type="date" id="schedule-date" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md" />
                    </div>
                    <div className="mb-4">
                      <label htmlFor="schedule-time" className="block text-sm font-medium text-gray-700 mb-1">Schedule Time</label>
                      <select id="schedule-time" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md">
                        <option>08:00 - 10:00</option>
                        <option>10:00 - 12:00</option>
                        <option>12:00 - 14:00</option>
                        <option>14:00 - 16:00</option>
                        <option>16:00 - 18:00</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                      <select id="priority" className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md">
                        <option>Low</option>
                        <option selected>Medium</option>
                        <option>High</option>
                        <option>Urgent</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-medium text-gray-800 mb-3 font-heading">Actions</h4>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                    <Button 
                      className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                      onClick={onAssign}
                    >
                      <span className="material-icons mr-2">assignment_ind</span>
                      Assign & Schedule
                    </Button>
                    <Button className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-info hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-info">
                      <span className="material-icons mr-2">email</span>
                      Contact Client
                    </Button>
                    <Button variant="outline" className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                      <span className="material-icons mr-2">print</span>
                      Print Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetailModal;

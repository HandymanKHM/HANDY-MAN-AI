interface SidebarProps {
  isMobileOpen: boolean;
  setIsMobileOpen: (isOpen: boolean) => void;
}

const Sidebar = ({ isMobileOpen, setIsMobileOpen }: SidebarProps) => {
  // Removed auth dependencies
  const user = { fullName: 'Kimberley Handyman', role: 'Admin' };

  const handleLogout = () => {
    // No logout needed
  };

  return (
    <div 
      className={`fixed inset-y-0 left-0 z-30 w-64 transform transition duration-300 bg-primary text-white lg:translate-x-0 lg:static lg:inset-0 ${
        isMobileOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      <div className="flex items-center justify-center h-16 px-6 border-b border-primary-dark">
        <svg 
          className="h-8" 
          viewBox="0 0 24 24" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg">
          <rect width="24" height="24" rx="4" fill="#ffffff"/>
          <path d="M7 12H8.5M12 7V8.5M17 12H15.5M12 17V15.5M9 9L10.5 10.5M15 9L13.5 10.5M15 15L13.5 13.5M9 15L10.5 13.5" stroke="#1E4D8C" strokeWidth="1.5" strokeLinecap="round"/>
          <circle cx="12" cy="12" r="3" stroke="#1E4D8C" strokeWidth="1.5"/>
        </svg>
      </div>
      <div className="px-4 py-6">
        <div className="mb-8">
          <div className="flex items-center px-3 py-2 mb-2 text-sm font-medium rounded-md text-white bg-primary-light">
            <span className="material-icons mr-3 text-lg">dashboard</span>
            Dashboard
          </div>
          <div className="flex items-center px-3 py-2 mb-2 text-sm font-medium rounded-md text-white hover:bg-primary-light cursor-pointer">
            <span className="material-icons mr-3 text-lg">work</span>
            Jobs
          </div>
          <div className="flex items-center px-3 py-2 mb-2 text-sm font-medium rounded-md text-white hover:bg-primary-light cursor-pointer">
            <span className="material-icons mr-3 text-lg">people</span>
            Technicians
          </div>
          <div className="flex items-center px-3 py-2 mb-2 text-sm font-medium rounded-md text-white hover:bg-primary-light cursor-pointer">
            <span className="material-icons mr-3 text-lg">business</span>
            Clients
          </div>
          <div className="flex items-center px-3 py-2 mb-2 text-sm font-medium rounded-md text-white hover:bg-primary-light cursor-pointer">
            <span className="material-icons mr-3 text-lg">assessment</span>
            Reports
          </div>
          <div className="flex items-center px-3 py-2 mb-2 text-sm font-medium rounded-md text-white hover:bg-primary-light cursor-pointer">
            <span className="material-icons mr-3 text-lg">settings</span>
            Settings
          </div>
        </div>
        <div className="border-t border-primary-light pt-4">
          <div className="flex items-center px-3 py-2 text-sm font-medium text-white">
            <div className="flex-shrink-0">
              <span className="material-icons text-xl">account_circle</span>
            </div>
            <div className="ml-3">
              <p className="text-base font-medium">{user?.fullName || 'User'}</p>
              <p className="text-xs">{user?.role || 'Role'}</p>
            </div>
          </div>
          <div 
            className="flex items-center px-3 py-2 mt-2 text-sm font-medium rounded-md text-white hover:bg-primary-light cursor-pointer"
            onClick={handleLogout}
          >
            <span className="material-icons mr-3 text-lg">logout</span>
            Logout
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;

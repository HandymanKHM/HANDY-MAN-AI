import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  HelpCircle, 
  ChevronRight, 
  CheckCircle, 
  Star,
  Phone,
  Camera,
  MapPin,
  Clock,
  FileText,
  Lightbulb,
  ArrowRight
} from 'lucide-react';

interface GuideStep {
  id: string;
  title: string;
  description: string;
  icon: any;
  tips: string[];
  completed?: boolean;
}

interface TechnicianGuideProps {
  isOpen: boolean;
  onClose: () => void;
  activeFeature?: string;
}

export default function TechnicianGuide({ isOpen, onClose, activeFeature }: TechnicianGuideProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  const guideSteps: GuideStep[] = [
    {
      id: 'overview',
      title: 'Welcome to Your Mobile Workshop',
      description: 'Your complete field service companion designed for Kimberley Handyman technicians',
      icon: Star,
      tips: [
        'Work seamlessly offline - your data syncs when you\'re back online',
        'Access all job details, client info, and tools in one place',
        'Professional client communication tools built-in',
        'GPS navigation and photo documentation made easy'
      ]
    },
    {
      id: 'jobs',
      title: 'Managing Your Jobs',
      description: 'View, update, and track all your assigned jobs',
      icon: FileText,
      tips: [
        'Tap any job card to see full details and start working',
        'Priority levels help you focus on urgent tasks first',
        'Update job status as you progress through the work',
        'Add notes and photos to document your work professionally'
      ]
    },
    {
      id: 'photos',
      title: 'Photo Documentation',
      description: 'Capture before/after photos and document your work',
      icon: Camera,
      tips: [
        'Take photos before starting work to show initial conditions',
        'Document progress photos during complex jobs',
        'Capture final results to show completed work quality',
        'Photos automatically sync when you\'re back online'
      ]
    },
    {
      id: 'navigation',
      title: 'Client Communication & Navigation',
      description: 'Connect with clients and navigate to job sites efficiently',
      icon: MapPin,
      tips: [
        'Tap the phone icon to call clients directly',
        'Use the navigation button for GPS directions to job sites',
        'Send professional completion messages with one click',
        'Request reviews automatically after successful jobs'
      ]
    },
    {
      id: 'offline',
      title: 'Working Offline',
      description: 'Stay productive even without internet connection',
      icon: Clock,
      tips: [
        'Download jobs when online for offline access',
        'All your work saves locally and syncs automatically',
        'Photos and notes are stored safely on your device',
        'Monitor storage usage in the Settings tab'
      ]
    }
  ];

  useEffect(() => {
    // Load completed steps from localStorage
    const saved = localStorage.getItem('technicianGuideProgress');
    if (saved) {
      setCompletedSteps(JSON.parse(saved));
    }
  }, []);

  const markStepCompleted = (stepId: string) => {
    const updated = [...completedSteps, stepId];
    setCompletedSteps(updated);
    localStorage.setItem('technicianGuideProgress', JSON.stringify(updated));
  };

  const isStepCompleted = (stepId: string) => completedSteps.includes(stepId);

  const nextStep = () => {
    if (currentStep < guideSteps.length - 1) {
      markStepCompleted(guideSteps[currentStep].id);
      setCurrentStep(currentStep + 1);
    } else {
      markStepCompleted(guideSteps[currentStep].id);
      onClose();
    }
  };

  const previousStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const jumpToStep = (index: number) => {
    setCurrentStep(index);
  };

  const currentGuideStep = guideSteps[currentStep];
  const IconComponent = currentGuideStep.icon;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <HelpCircle className="h-5 w-5 text-blue-600" />
            <span>Technician Quick Guide</span>
          </DialogTitle>
          <DialogDescription>
            Step {currentStep + 1} of {guideSteps.length}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress Indicator */}
          <div className="flex items-center space-x-2">
            {guideSteps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <button
                  onClick={() => jumpToStep(index)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-colors ${
                    index === currentStep
                      ? 'bg-blue-600 text-white'
                      : isStepCompleted(step.id)
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {isStepCompleted(step.id) ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    index + 1
                  )}
                </button>
                {index < guideSteps.length - 1 && (
                  <div className={`w-8 h-0.5 ${
                    isStepCompleted(step.id) ? 'bg-green-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>

          {/* Current Step Content */}
          <Card>
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <IconComponent className="h-8 w-8 text-blue-600" />
              </div>
              <CardTitle className="text-xl">{currentGuideStep.title}</CardTitle>
              <CardDescription>{currentGuideStep.description}</CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {currentGuideStep.tips.map((tip, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Lightbulb className="h-3 w-3 text-green-600" />
                    </div>
                    <p className="text-sm text-gray-700">{tip}</p>
                  </div>
                ))}
              </div>

              {/* Special guidance based on active feature */}
              {activeFeature && (
                <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800 font-medium">
                    💡 You're currently viewing: {activeFeature}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Navigation Buttons */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={previousStep}
              disabled={currentStep === 0}
            >
              Previous
            </Button>

            <div className="flex space-x-2">
              <Button variant="outline" onClick={onClose}>
                Skip Guide
              </Button>
              
              <Button onClick={nextStep}>
                {currentStep === guideSteps.length - 1 ? 'Finish' : 'Next'}
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>

          {/* Quick Access Tips */}
          <div className="border-t pt-4">
            <p className="text-xs text-gray-500 text-center">
              💡 Tip: You can access this guide anytime from the Settings tab
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
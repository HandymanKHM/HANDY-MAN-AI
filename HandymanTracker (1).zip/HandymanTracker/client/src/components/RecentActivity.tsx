import { Activity } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface RecentActivityProps {
  activities: Activity[];
  isLoading: boolean;
}

const RecentActivity = ({ activities, isLoading }: RecentActivityProps) => {
  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow">
        <div className="flex justify-between items-center p-5 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-800 font-heading">Recent Activity</h3>
          <button className="text-sm text-primary hover:text-primary-dark font-medium">View All</button>
        </div>
        <div className="p-5 animate-pulse">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="flex mb-6">
              <div className="mr-4 h-8 w-8 bg-gray-200 rounded-full"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 rounded mb-2 w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'job_assigned':
        return { icon: 'assignment_turned_in', bg: 'bg-blue-100', color: 'text-primary' };
      case 'job_completed':
        return { icon: 'check_circle', bg: 'bg-green-100', color: 'text-success' };
      case 'new_job':
        return { icon: 'email', bg: 'bg-blue-100', color: 'text-primary' };
      case 'job_issue':
        return { icon: 'warning', bg: 'bg-yellow-100', color: 'text-warning' };
      default:
        return { icon: 'info', bg: 'bg-gray-100', color: 'text-gray-500' };
    }
  };

  const formatTime = (date: Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="flex justify-between items-center p-5 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-800 font-heading">Recent Activity</h3>
        <button className="text-sm text-primary hover:text-primary-dark font-medium">View All</button>
      </div>
      <div className="p-5">
        <div className="flow-root">
          <ul className="-mb-8">
            {activities.length === 0 ? (
              <li className="text-center py-4 text-gray-500">No recent activities</li>
            ) : (
              activities.slice(0, 4).map((activity, index) => {
                const { icon, bg, color } = getActivityIcon(activity.activityType);
                const isLast = index === activities.length - 1 || index === 3;
                
                return (
                  <li key={activity.id}>
                    <div className="relative pb-8">
                      {!isLast && (
                        <span 
                          className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" 
                          aria-hidden="true"
                        ></span>
                      )}
                      <div className="relative flex space-x-3">
                        <div>
                          <span className={`h-8 w-8 rounded-full ${bg} flex items-center justify-center ring-8 ring-white`}>
                            <span className={`material-icons ${color} text-sm`}>{icon}</span>
                          </span>
                        </div>
                        <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                          <div>
                            <p className="text-sm text-gray-700">{activity.description}</p>
                          </div>
                          <div className="text-right text-sm whitespace-nowrap text-gray-500">
                            <time>{formatTime(activity.createdAt)}</time>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;

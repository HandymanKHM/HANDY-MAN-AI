import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Brain, Zap, DollarSign, Clock, AlertTriangle, Wrench } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface JobAnalysis {
  category: 'plumbing' | 'electrical' | 'construction' | 'general';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedDuration: number;
  estimatedCost: number;
  requiredSkills: string[];
  materials: string[];
  riskFactors: string[];
  recommendation: string;
}

interface SmartQuote {
  laborCost: number;
  materialCost: number;
  totalCost: number;
  breakdown: {
    item: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }[];
  timeline: string;
  warranty: string;
  notes: string;
}

const AIJobAnalyzer = () => {
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [analysis, setAnalysis] = useState<JobAnalysis | null>(null);
  const [quote, setQuote] = useState<SmartQuote | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGeneratingQuote, setIsGeneratingQuote] = useState(false);

  const analyzeJob = async () => {
    if (!description.trim() || !location.trim()) return;
    
    setIsAnalyzing(true);
    try {
      const result = await fetch("/api/ai/analyze-job", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          description,
          location,
          clientHistory: "Premium client with history of quality work"
        })
      });
      
      if (!result.ok) {
        throw new Error("Analysis failed");
      }
      
      const analysisResult = await result.json();
      setAnalysis(analysisResult);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generateQuote = async () => {
    if (!analysis) return;
    
    setIsGeneratingQuote(true);
    try {
      const result = await fetch("/api/ai/generate-quote", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          jobDescription: description,
          analysis
        })
      });
      
      if (!result.ok) {
        throw new Error("Quote generation failed");
      }
      
      const quoteResult = await result.json();
      setQuote(quoteResult);
    } catch (error) {
      console.error("Quote generation failed:", error);
    } finally {
      setIsGeneratingQuote(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500 text-white';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-black';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'plumbing': return 'bg-blue-500 text-white';
      case 'electrical': return 'bg-yellow-500 text-black';
      case 'construction': return 'bg-orange-500 text-white';
      case 'general': return 'bg-gray-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Brain className="h-5 w-5 text-primary" />
            AI Job Analyzer
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Get instant intelligent analysis and professional quotes using advanced AI
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Job Description
              </label>
              <Textarea
                placeholder="Describe the handyman job in detail..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="min-h-[100px] bg-background border-border text-foreground"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">
                Location
              </label>
              <Input
                placeholder="Job location or address"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="bg-background border-border text-foreground"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={analyzeJob}
              disabled={isAnalyzing || !description.trim() || !location.trim()}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {isAnalyzing ? (
                <>
                  <Zap className="h-4 w-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="h-4 w-4 mr-2" />
                  Analyze Job
                </>
              )}
            </Button>
            
            {analysis && (
              <Button 
                onClick={generateQuote}
                disabled={isGeneratingQuote}
                variant="outline"
                className="border-primary text-primary hover:bg-primary/10"
              >
                {isGeneratingQuote ? (
                  <>
                    <DollarSign className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <DollarSign className="h-4 w-4 mr-2" />
                    Generate Quote
                  </>
                )}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {analysis && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">AI Analysis Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <Badge className={getCategoryColor(analysis.category)}>
                  {analysis.category.toUpperCase()}
                </Badge>
                <p className="text-xs text-muted-foreground mt-1">Category</p>
              </div>
              <div className="text-center">
                <Badge className={getPriorityColor(analysis.priority)}>
                  {analysis.priority.toUpperCase()}
                </Badge>
                <p className="text-xs text-muted-foreground mt-1">Priority</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-foreground">
                  <Clock className="h-4 w-4" />
                  <span className="font-semibold">{analysis.estimatedDuration}h</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Duration</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-foreground">
                  <DollarSign className="h-4 w-4" />
                  <span className="font-semibold">${analysis.estimatedCost}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Estimate</p>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                  <Wrench className="h-4 w-4" />
                  Required Skills
                </h4>
                <div className="space-y-1">
                  {analysis.requiredSkills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-foreground mb-2">Materials Needed</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {analysis.materials.map((material, index) => (
                    <li key={index}>• {material}</li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  Risk Factors
                </h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {analysis.riskFactors.map((risk, index) => (
                    <li key={index} className="text-yellow-600">• {risk}</li>
                  ))}
                </ul>
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-medium text-foreground mb-2">AI Recommendation</h4>
              <p className="text-sm text-muted-foreground bg-muted p-3 rounded-lg">
                {analysis.recommendation}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {quote && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground">Professional Quote</CardTitle>
            <CardDescription className="text-muted-foreground">
              AI-generated professional estimate
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-muted p-4 rounded-lg">
                <div className="text-2xl font-bold text-foreground">${quote.laborCost}</div>
                <div className="text-sm text-muted-foreground">Labor</div>
              </div>
              <div className="bg-muted p-4 rounded-lg">
                <div className="text-2xl font-bold text-foreground">${quote.materialCost}</div>
                <div className="text-sm text-muted-foreground">Materials</div>
              </div>
              <div className="bg-primary/10 p-4 rounded-lg border border-primary">
                <div className="text-2xl font-bold text-primary">${quote.totalCost}</div>
                <div className="text-sm text-primary">Total</div>
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-medium text-foreground mb-3">Cost Breakdown</h4>
              <div className="space-y-2">
                {quote.breakdown.map((item, index) => (
                  <div key={index} className="flex justify-between items-center text-sm">
                    <span className="text-foreground">{item.item} (x{item.quantity})</span>
                    <span className="font-medium text-foreground">${item.total}</span>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-foreground mb-2">Timeline</h4>
                <p className="text-sm text-muted-foreground">{quote.timeline}</p>
              </div>
              <div>
                <h4 className="font-medium text-foreground mb-2">Warranty</h4>
                <p className="text-sm text-muted-foreground">{quote.warranty}</p>
              </div>
            </div>

            {quote.notes && (
              <div>
                <h4 className="font-medium text-foreground mb-2">Additional Notes</h4>
                <p className="text-sm text-muted-foreground bg-muted p-3 rounded-lg">
                  {quote.notes}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AIJobAnalyzer;
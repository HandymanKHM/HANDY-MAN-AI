import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/hooks/useAuth";
import MFASection from "./MFASetup";
import kimberleyLogo from "@assets/Right Logo.jpeg";

const formSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  rememberMe: z.boolean().optional(),
});

const AuthForm = () => {
  const { login, isLoading, isVerifyingMFA, verifyMFA } = useAuth();
  const [mfaCode, setMfaCode] = useState("");

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: "",
      password: "",
      rememberMe: false,
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    await login(values.email, values.password, values.rememberMe);
  };

  const handleVerifyMFA = async () => {
    await verifyMFA(mfaCode);
  };

  return (
    <div className="max-w-md w-full bg-card p-12 rounded-lg shadow-2xl border border-border backdrop-blur-sm transition-all duration-300 hover:shadow-2xl hover:border-primary/20">
      <div className="text-center mb-10">
        <div className="relative mb-8">
          <div className="absolute inset-0 bg-primary/10 rounded-full blur-2xl"></div>
          <img 
            src={kimberleyLogo} 
            alt="Kimberley Handyman Logo" 
            className="relative mx-auto h-28 w-auto object-contain"
          />
        </div>
        <h2 className="text-3xl font-light tracking-tight text-foreground mb-2">
          Field Service Management
        </h2>
        <div className="w-16 h-0.5 bg-gradient-to-r from-primary to-primary/50 mx-auto mb-4"></div>
        <p className="text-base text-muted-foreground">
          Advanced Tech Solutions for Modern Handyman Services
        </p>
        <p className="text-sm text-muted-foreground/80 mt-2">
          Sign in to continue to your workspace
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-7">
          <div className="space-y-5">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input
                      placeholder="Email address"
                      type="email"
                      autoComplete="email"
                      aria-label="Email address"
                      className="appearance-none block w-full px-4 py-3 border border-input placeholder-muted-foreground text-foreground rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary bg-background/50 backdrop-blur-sm transition-all duration-300 text-base hover:bg-background/70"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage className="text-sm font-medium mt-1 text-destructive" role="alert" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input
                      placeholder="Password"
                      type="password"
                      autoComplete="current-password"
                      aria-label="Password"
                      className="appearance-none block w-full px-4 py-3 border border-input placeholder-muted-foreground text-foreground rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary bg-background/50 backdrop-blur-sm transition-all duration-300 text-base hover:bg-background/70"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage className="text-sm font-medium mt-1 text-destructive" role="alert" />
                </FormItem>
              )}
            />
          </div>

          <div className="flex items-center justify-between mt-3">
            <FormField
              control={form.control}
              name="rememberMe"
              render={({ field }) => (
                <FormItem className="flex items-center space-x-2">
                  <FormControl>
                    <Checkbox
                      id="remember-me"
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      aria-label="Remember me on this device"
                      className="h-5 w-5 text-primary focus:ring-primary border-gray-200 rounded"
                    />
                  </FormControl>
                  <label htmlFor="remember-me" className="ml-2 block text-base text-foreground">
                    Remember me
                  </label>
                </FormItem>
              )}
            />

            <div className="text-base">
              <a href="#" className="font-medium text-primary hover:text-primary/80 transition-colors duration-200 underline decoration-primary/50 hover:decoration-primary">
                Forgot password?
              </a>
            </div>
          </div>

          <div className="mt-10">
            <Button
              type="submit"
              disabled={isLoading}
              aria-label="Sign in to account"
              className="w-full py-4 px-5 text-base font-medium tracking-wide rounded-lg text-primary-foreground bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-background"
            >
              {isLoading ? "Signing in..." : "Sign in"}
            </Button>
          </div>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Or continue with</span>
              </div>
            </div>

            <div className="mt-6">
              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={() => {
                  function LoginWithReplit() {
                    window.addEventListener("message", authComplete);
                    var h = 500;
                    var w = 350;
                    var left = screen.width / 2 - w / 2;
                    var top = screen.height / 2 - h / 2;

                    var authWindow = window.open(
                      "https://replit.com/auth_with_repl_site?domain=" + location.host,
                      "_blank",
                      "modal=yes, toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=" +
                        w +
                        ", height=" +
                        h +
                        ", top=" +
                        top +
                        ", left=" +
                        left
                    );

                    function authComplete(e: MessageEvent) {
                      if (e.data !== "auth_complete") {
                        return;
                      }

                      window.removeEventListener("message", authComplete);
                      authWindow.close();
                      location.reload();
                    }
                  }
                  LoginWithReplit();
                }}
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 9.74s9-4.19 9-9.74V7L12 2z"/>
                </svg>
                Sign in with Replit
              </Button>
            </div>
          </div>

          {isVerifyingMFA && (
            <MFASection
              mfaCode={mfaCode}
              setMfaCode={setMfaCode}
              onVerify={handleVerifyMFA}
              isLoading={isLoading}
            />
          )}
        </form>
      </Form>
    </div>
  );
};

export default AuthForm;
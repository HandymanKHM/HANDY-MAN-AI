import { format, formatDistanceToNow } from 'date-fns';
import { JobWithClient } from '@/lib/types';

interface JobTableProps {
  jobs: JobWithClient[];
  isLoading: boolean;
  onViewDetails: (jobId: number) => void;
  onAssignJob: (jobId: number) => void;
}

const JobTable = ({ jobs, isLoading, onViewDetails, onAssignJob }: JobTableProps) => {
  const formatReceivedTime = (date: Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'new':
        return 'bg-blue-100 text-blue-800';
      case 'assigned':
        return 'bg-yellow-100 text-yellow-800';
      case 'in-progress':
        return 'bg-orange-100 text-orange-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'issue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow mb-6">
        <div className="flex justify-between items-center p-5 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-800 font-heading">New Job Requests</h3>
          <div className="flex items-center">
            <span className="material-icons text-gray-400 mr-2">refresh</span>
            <span className="text-sm text-gray-500">Auto-refresh enabled</span>
          </div>
        </div>
        <div className="animate-pulse p-6">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-12 bg-gray-200 rounded mb-4"></div>
          ))}
        </div>
      </div>
    );
  }

  const newJobs = jobs.filter(job => job.status === 'new');
  
  return (
    <div className="bg-white rounded-lg shadow mb-6">
      <div className="flex justify-between items-center p-5 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-800 font-heading">New Job Requests</h3>
        <div className="flex items-center">
          <span className="material-icons text-gray-400 mr-2">refresh</span>
          <span className="text-sm text-gray-500">Auto-refresh enabled</span>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Claim ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Insurer</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service Type</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Received</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {newJobs.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-4 text-center text-sm text-gray-500">
                  No new job requests at the moment
                </td>
              </tr>
            ) : (
              newJobs.map((job) => (
                <tr 
                  key={job.id} 
                  className="hover:bg-gray-50 cursor-pointer"
                  onClick={() => onViewDetails(job.id)}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{job.claimId}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{job.client?.insurer}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{job.client?.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{job.serviceType}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatReceivedTime(job.createdAt)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(job.status)}`}>
                      {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button 
                      className="text-primary hover:text-primary-dark"
                      onClick={(e) => {
                        e.stopPropagation();
                        onAssignJob(job.id);
                      }}
                    >
                      <span className="material-icons">assignment_ind</span>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <div className="bg-gray-50 px-6 py-3 flex justify-between items-center border-t border-gray-200">
        <span className="text-sm text-gray-700">
          Showing <span className="font-medium">1</span> to <span className="font-medium">{newJobs.length}</span> of <span className="font-medium">{newJobs.length}</span> results
        </span>
        <div className="flex items-center space-x-2">
          <button disabled className="px-3 py-1 rounded-md bg-gray-200 text-gray-400 cursor-not-allowed">
            Previous
          </button>
          <button disabled className="px-3 py-1 rounded-md bg-gray-200 text-gray-400 cursor-not-allowed">
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

export default JobTable;

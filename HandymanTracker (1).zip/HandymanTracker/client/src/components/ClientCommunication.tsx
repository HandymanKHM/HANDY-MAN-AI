import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  MessageSquare, 
  Star, 
  Send, 
  Copy, 
  Phone,
  CheckCircle,
  Heart,
  ThumbsUp,
  Sparkles,
  Clock,
  UserCheck
} from 'lucide-react';

interface TechnicianJob {
  id: number;
  claimId: string;
  clientName: string;
  clientPhone: string;
  serviceType: string;
  description: string;
  status: string;
}

interface ClientCommunicationProps {
  job: TechnicianJob;
  technicianName?: string;
}

export default function ClientCommunication({ job, technicianName = "Your Kimberley Handyman Technician" }: ClientCommunicationProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [customMessage, setCustomMessage] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  // Professional message templates
  const messageTemplates = {
    arrival: {
      title: "Arrival Notification",
      icon: Clock,
      color: "bg-blue-100 text-blue-600",
      message: `Hi ${job.clientName}! 👋

This is ${technicianName} from Kimberley Handyman. I'm on my way to your property for the ${job.serviceType} service (Job #${job.claimId}).

I'll be arriving within the next 15-30 minutes. Please ensure I have clear access to the work area.

If you have any questions or concerns, please don't hesitate to call me directly.

Looking forward to providing you with excellent service!

🔧 Kimberley Handyman Pty Ltd
📱 Professional Service You Can Trust`
    },

    completion: {
      title: "Job Completion & Review Request",
      icon: CheckCircle,
      color: "bg-green-100 text-green-600",
      message: `Dear ${job.clientName}, ✨

Great news! I've successfully completed your ${job.serviceType} service (Job #${job.claimId}).

🎯 Work Summary:
${job.description}

✅ Quality assurance check completed
✅ Work area cleaned and tidied
✅ All materials properly disposed of

Your satisfaction is our top priority! If everything meets your expectations, we would be incredibly grateful if you could take a moment to share your experience:

⭐ LEAVE A GOOGLE REVIEW ⭐
https://g.page/r/kimberley-handyman/review

We truly appreciate 5-star reviews when we've served with excellence! Your feedback helps other families in our community discover our reliable services.

💙 Thank you for choosing Kimberley Handyman! 

Questions or concerns? Please call us anytime - we're here to serve and ensure everything is perfect.

🔧 Kimberley Handyman Pty Ltd
📞 Call us 24/7 for any assistance
🏆 Your Local Trusted Trade Professionals`
    },

    followUp: {
      title: "Follow-up Check",
      icon: Heart,
      color: "bg-purple-100 text-purple-600",
      message: `Hello ${job.clientName}! 😊

I hope you're completely satisfied with the ${job.serviceType} work we completed (Job #${job.claimId}).

At Kimberley Handyman, we believe in going above and beyond. I wanted to personally follow up to ensure everything is working perfectly and you're 100% happy with the results.

🔍 Quick Check:
• Is everything functioning as expected?
• Do you have any questions about the work?
• Are there any concerns we should address?

If you haven't already, and if we've earned it, we'd be honored if you could share a quick Google review:
⭐ https://g.page/r/kimberley-handyman/review

Your feedback means the world to us and helps fellow community members find reliable service.

Don't hesitate to reach out if you need anything at all - we're always here to help!

Warm regards,
${technicianName}
🔧 Kimberley Handyman Pty Ltd`
    },

    issue: {
      title: "Issue Resolution",
      icon: UserCheck,
      color: "bg-orange-100 text-orange-600",
      message: `Dear ${job.clientName},

Thank you for bringing this matter to our attention regarding Job #${job.claimId}.

At Kimberley Handyman, we stand behind our work 100%. Your satisfaction is our absolute priority, and we're committed to making this right immediately.

🛠️ Next Steps:
• I'll return at your earliest convenience
• We'll resolve this completely at no additional cost
• We'll ensure you're completely satisfied with the results

This is our promise to you - if anything isn't right, we fix it. No exceptions.

Please let me know when it's convenient for you, and I'll be there promptly.

We truly appreciate your patience and the opportunity to make this right.

${technicianName}
🔧 Kimberley Handyman Pty Ltd
📞 Call us anytime - we're here to serve`
    }
  };

  const sendMessage = (template: string) => {
    const templateData = messageTemplates[template as keyof typeof messageTemplates];
    
    // In a real implementation, this would integrate with SMS service
    const smsUrl = `sms:${job.clientPhone}?body=${encodeURIComponent(templateData.message)}`;
    window.open(smsUrl);
    
    toast({
      title: "Message Ready to Send! 📱",
      description: `Professional ${templateData.title.toLowerCase()} message prepared for ${job.clientName}`,
    });
    
    setIsDialogOpen(false);
  };

  const copyToClipboard = (template: string) => {
    const templateData = messageTemplates[template as keyof typeof messageTemplates];
    navigator.clipboard.writeText(templateData.message);
    
    toast({
      title: "Message Copied! 📋",
      description: "Professional message copied to clipboard",
    });
  };

  const sendCustomMessage = () => {
    if (!customMessage.trim()) {
      toast({
        title: "Please enter a message",
        description: "Write your custom message before sending",
        variant: "destructive"
      });
      return;
    }

    const smsUrl = `sms:${job.clientPhone}?body=${encodeURIComponent(customMessage)}`;
    window.open(smsUrl);
    
    toast({
      title: "Custom Message Ready! 📱",
      description: `Message prepared for ${job.clientName}`,
    });
    
    setCustomMessage('');
    setIsDialogOpen(false);
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button className="w-full" size="sm">
          <MessageSquare className="h-4 w-4 mr-2" />
          Client Communication
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-blue-600" />
            <span>Professional Client Communication</span>
          </DialogTitle>
          <DialogDescription>
            Send professional messages to {job.clientName} for Job #{job.claimId}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Quick Action Templates */}
          <div className="grid gap-3 md:grid-cols-2">
            {Object.entries(messageTemplates).map(([key, template]) => {
              const IconComponent = template.icon;
              return (
                <Card key={key} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${template.color}`}>
                        <IconComponent className="h-5 w-5" />
                      </div>
                      <div>
                        <CardTitle className="text-sm">{template.title}</CardTitle>
                        <CardDescription className="text-xs">
                          {key === 'completion' ? 'Includes review request' : 'Professional template'}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-3">
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        onClick={() => sendMessage(key)}
                      >
                        <Send className="h-3 w-3 mr-1" />
                        Send
                      </Button>
                      
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => copyToClipboard(key)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    
                    {key === 'completion' && (
                      <Badge variant="secondary" className="text-xs">
                        <Star className="h-3 w-3 mr-1" />
                        Includes Google Review Link
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Message Preview */}
          {selectedTemplate && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Message Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-4 rounded-lg border text-sm whitespace-pre-line">
                  {messageTemplates[selectedTemplate as keyof typeof messageTemplates].message}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Custom Message */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Custom Message</CardTitle>
              <CardDescription>Write a personalized message</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Textarea
                placeholder={`Hi ${job.clientName}, this is ${technicianName} from Kimberley Handyman...`}
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                rows={4}
              />
              
              <div className="flex space-x-2">
                <Button 
                  onClick={sendCustomMessage}
                  disabled={!customMessage.trim()}
                  className="flex-1"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Send Custom Message
                </Button>
                
                <Button 
                  variant="outline"
                  onClick={() => navigator.clipboard.writeText(customMessage)}
                  disabled={!customMessage.trim()}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="flex space-x-2 pt-4 border-t">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => window.open(`tel:${job.clientPhone}`)}
            >
              <Phone className="h-4 w-4 mr-2" />
              Call Client
            </Button>
            
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => window.open('https://g.page/r/kimberley-handyman/review')}
            >
              <Star className="h-4 w-4 mr-2" />
              Google Reviews
            </Button>
          </div>

          {/* Professional Note */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <ThumbsUp className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-blue-900">Professional Communication Tips</p>
                <ul className="text-xs text-blue-700 mt-2 space-y-1">
                  <li>• Always include your name and company</li>
                  <li>• Be specific about the work completed</li>
                  <li>• Request reviews only after excellent service</li>
                  <li>• Maintain friendly, professional tone</li>
                  <li>• Always offer continued support</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
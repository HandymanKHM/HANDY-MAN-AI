import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface HeadingProps {
  as?: "h1" | "h2" | "h3" | "h4" | "h5" | "h6";
  children: ReactNode;
  className?: string;
}

export function Heading({ as = "h2", children, className }: HeadingProps) {
  const Component = as;
  
  const baseStyles = "font-heading font-bold";
  
  const sizes = {
    h1: "text-3xl md:text-4xl",
    h2: "text-2xl md:text-3xl",
    h3: "text-xl md:text-2xl",
    h4: "text-lg md:text-xl",
    h5: "text-base md:text-lg",
    h6: "text-sm md:text-base",
  };
  
  return (
    <Component className={cn(baseStyles, sizes[as], className)}>
      {children}
    </Component>
  );
}

export function PageHeading({ children, className }: Omit<HeadingProps, "as">) {
  return (
    <Heading as="h1" className={cn("mb-6", className)}>
      {children}
    </Heading>
  );
}

export function SectionHeading({ children, className }: Omit<HeadingProps, "as">) {
  return (
    <Heading as="h2" className={cn("mb-4", className)}>
      {children}
    </Heading>
  );
}

export function CardHeading({ children, className }: Omit<HeadingProps, "as">) {
  return (
    <Heading as="h3" className={cn("text-gray-800", className)}>
      {children}
    </Heading>
  );
}

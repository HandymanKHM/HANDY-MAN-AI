interface EmailMonitoringProps {
  status: string;
  email: string;
  lastChecked: string;
  processed: number;
}

const EmailMonitoringStatus = ({ status, email, lastChecked, processed }: EmailMonitoringProps) => {
  return (
    <div className="bg-white rounded-lg shadow p-5 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-gray-800 font-heading">Email Monitoring Status</h3>
        <span 
          className={`px-3 py-1 text-xs font-medium rounded-full ${
            status === 'active' 
              ? 'bg-green-100 text-success' 
              : 'bg-red-100 text-error'
          }`}
        >
          {status === 'active' ? 'Active' : 'Inactive'}
        </span>
      </div>
      <div className="flex flex-col md:flex-row md:items-center text-sm text-gray-600">
        <div className="flex items-center mb-2 md:mb-0 md:mr-6">
          <span className="material-icons text-primary mr-2">email</span>
          <span>{email}</span>
        </div>
        <div className="flex items-center mb-2 md:mb-0 md:mr-6">
          <span className="material-icons text-gray-500 mr-2">schedule</span>
          <span>Last checked: {lastChecked}</span>
        </div>
        <div className="flex items-center">
          <span className="material-icons text-success mr-2">inventory</span>
          <span>Processed today: {processed}</span>
        </div>
      </div>
    </div>
  );
};

export default EmailMonitoringStatus;

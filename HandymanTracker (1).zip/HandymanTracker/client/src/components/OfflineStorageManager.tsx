import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  Download, 
  Upload, 
  Wifi, 
  WifiOff, 
  Database, 
  Sync, 
  Clock,
  CheckCircle,
  AlertTriangle,
  HardDrive
} from 'lucide-react';

interface OfflineJob {
  id: number;
  claimId: string;
  clientName: string;
  status: string;
  lastModified: Date;
  hasChanges: boolean;
  photoCount: number;
  notes: string;
}

interface OfflineCapability {
  isOnline: boolean;
  lastSync: Date | null;
  pendingUploads: number;
  storageUsed: number;
  maxStorage: number;
  syncProgress: number;
  offlineJobs: OfflineJob[];
}

export default function OfflineStorageManager() {
  const [offlineData, setOfflineData] = useState<OfflineCapability>({
    isOnline: navigator.onLine,
    lastSync: new Date(),
    pendingUploads: 3,
    storageUsed: 45,
    maxStorage: 100,
    syncProgress: 0,
    offlineJobs: [
      {
        id: 1,
        claimId: 'KH-2024-001',
        clientName: 'Sarah Johnson',
        status: 'in_progress',
        lastModified: new Date(),
        hasChanges: true,
        photoCount: 2,
        notes: 'Kitchen faucet repair completed'
      },
      {
        id: 2,
        claimId: 'KH-2024-002',
        clientName: 'Michael Chen',
        status: 'completed',
        lastModified: new Date(Date.now() - 30000),
        hasChanges: true,
        photoCount: 4,
        notes: 'Ceiling fan installation finished'
      }
    ]
  });

  const { toast } = useToast();

  // Initialize offline storage
  useEffect(() => {
    initializeOfflineStorage();
    
    // Monitor online/offline status
    const handleOnline = () => {
      setOfflineData(prev => ({ ...prev, isOnline: true }));
      toast({
        title: 'Back Online',
        description: 'Automatically syncing your work...',
      });
      syncOfflineData();
    };

    const handleOffline = () => {
      setOfflineData(prev => ({ ...prev, isOnline: false }));
      toast({
        title: 'Working Offline',
        description: 'Your work is saved locally and will sync when reconnected.',
        variant: 'destructive'
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [toast]);

  const initializeOfflineStorage = async () => {
    try {
      // Initialize IndexedDB for offline storage
      const dbName = 'KimberleyHandymanTech';
      const request = indexedDB.open(dbName, 1);
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        if (!db.objectStoreNames.contains('jobs')) {
          const jobStore = db.createObjectStore('jobs', { keyPath: 'id' });
          jobStore.createIndex('status', 'status');
        }
        
        if (!db.objectStoreNames.contains('photos')) {
          const photoStore = db.createObjectStore('photos', { keyPath: 'id' });
          photoStore.createIndex('jobId', 'jobId');
        }
        
        if (!db.objectStoreNames.contains('syncQueue')) {
          db.createObjectStore('syncQueue', { keyPath: 'id' });
        }
      };
      
      request.onsuccess = () => {
        console.log('✅ Offline storage initialized');
        updateStorageUsage();
      };
      
    } catch (error) {
      console.error('❌ Failed to initialize offline storage:', error);
    }
  };

  const updateStorageUsage = async () => {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      try {
        const estimate = await navigator.storage.estimate();
        const used = Math.round((estimate.usage || 0) / (1024 * 1024));
        const available = Math.round((estimate.quota || 0) / (1024 * 1024));
        
        setOfflineData(prev => ({
          ...prev,
          storageUsed: used,
          maxStorage: available
        }));
      } catch (error) {
        console.warn('Storage estimate not available');
      }
    }
  };

  const syncOfflineData = async () => {
    if (!offlineData.isOnline) {
      toast({
        title: 'No Connection',
        description: 'Please check your internet connection to sync.',
        variant: 'destructive'
      });
      return;
    }

    setOfflineData(prev => ({ ...prev, syncProgress: 0 }));
    
    try {
      // Simulate sync progress
      for (let i = 0; i <= 100; i += 10) {
        setTimeout(() => {
          setOfflineData(prev => ({ ...prev, syncProgress: i }));
        }, i * 50);
      }

      // Simulate successful sync
      setTimeout(() => {
        setOfflineData(prev => ({
          ...prev,
          lastSync: new Date(),
          pendingUploads: 0,
          syncProgress: 100,
          offlineJobs: prev.offlineJobs.map(job => ({
            ...job,
            hasChanges: false
          }))
        }));
        
        toast({
          title: 'Sync Complete',
          description: 'All your work has been successfully uploaded.',
        });
      }, 5000);
      
    } catch (error) {
      toast({
        title: 'Sync Failed',
        description: 'Failed to sync data. Will retry automatically.',
        variant: 'destructive'
      });
    }
  };

  const downloadJobsForOffline = async () => {
    toast({
      title: 'Downloading Jobs',
      description: 'Preparing jobs for offline access...',
    });

    // Simulate download
    setTimeout(() => {
      toast({
        title: 'Download Complete',
        description: 'Jobs are now available offline.',
      });
    }, 2000);
  };

  const clearOfflineData = async () => {
    try {
      const dbName = 'KimberleyHandymanTech';
      const deleteRequest = indexedDB.deleteDatabase(dbName);
      
      deleteRequest.onsuccess = () => {
        setOfflineData(prev => ({
          ...prev,
          storageUsed: 0,
          pendingUploads: 0,
          offlineJobs: []
        }));
        
        toast({
          title: 'Data Cleared',
          description: 'All offline data has been removed.',
        });
      };
    } catch (error) {
      toast({
        title: 'Clear Failed',
        description: 'Could not clear offline data.',
        variant: 'destructive'
      });
    }
  };

  const getStatusColor = (hasChanges: boolean) => {
    return hasChanges ? 'destructive' : 'default';
  };

  const getConnectionStatus = () => {
    if (offlineData.isOnline) {
      return (
        <div className="flex items-center space-x-2 text-green-600">
          <Wifi className="h-4 w-4" />
          <span className="text-sm font-medium">Online</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center space-x-2 text-red-600">
          <WifiOff className="h-4 w-4" />
          <span className="text-sm font-medium">Offline</span>
        </div>
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Offline Storage Manager</CardTitle>
              <CardDescription>Manage your offline work and sync status</CardDescription>
            </div>
            {getConnectionStatus()}
          </div>
        </CardHeader>
      </Card>

      {/* Storage Status */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <HardDrive className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium">Storage Used</p>
                <p className="text-2xl font-bold">{offlineData.storageUsed}MB</p>
                <p className="text-xs text-muted-foreground">of {offlineData.maxStorage}MB</p>
              </div>
            </div>
            <Progress 
              value={(offlineData.storageUsed / offlineData.maxStorage) * 100} 
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Upload className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-sm font-medium">Pending Uploads</p>
                <p className="text-2xl font-bold">{offlineData.pendingUploads}</p>
                <p className="text-xs text-muted-foreground">items to sync</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium">Last Sync</p>
                <p className="text-sm font-bold">
                  {offlineData.lastSync ? offlineData.lastSync.toLocaleTimeString() : 'Never'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {offlineData.lastSync ? offlineData.lastSync.toLocaleDateString() : 'No sync yet'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sync Progress */}
      {offlineData.syncProgress > 0 && offlineData.syncProgress < 100 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Syncing Data...</span>
              <span className="text-sm text-muted-foreground">{offlineData.syncProgress}%</span>
            </div>
            <Progress value={offlineData.syncProgress} className="h-2" />
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 md:grid-cols-2">
            <Button
              onClick={syncOfflineData}
              disabled={!offlineData.isOnline || offlineData.syncProgress > 0}
              className="w-full"
            >
              <Sync className="h-4 w-4 mr-2" />
              Sync Now
            </Button>
            
            <Button
              variant="outline"
              onClick={downloadJobsForOffline}
              disabled={!offlineData.isOnline}
              className="w-full"
            >
              <Download className="h-4 w-4 mr-2" />
              Download Jobs
            </Button>
          </div>
          
          <Button
            variant="destructive"
            onClick={clearOfflineData}
            className="w-full"
          >
            <Database className="h-4 w-4 mr-2" />
            Clear Offline Data
          </Button>
        </CardContent>
      </Card>

      {/* Offline Jobs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Offline Jobs</CardTitle>
          <CardDescription>Jobs available for offline work</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {offlineData.offlineJobs.length > 0 ? (
            offlineData.offlineJobs.map((job) => (
              <div key={job.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <p className="font-medium">{job.claimId}</p>
                    <Badge variant={getStatusColor(job.hasChanges)}>
                      {job.hasChanges ? 'Modified' : 'Synced'}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{job.clientName}</p>
                  <p className="text-xs text-muted-foreground">
                    {job.photoCount} photos • Modified {job.lastModified.toLocaleTimeString()}
                  </p>
                </div>
                
                <div className="flex items-center space-x-2">
                  {job.hasChanges ? (
                    <AlertTriangle className="h-4 w-4 text-orange-500" />
                  ) : (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  )}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <Database className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No offline jobs available</p>
              <p className="text-sm text-gray-500 mt-1">
                Download jobs when online to work offline
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* PWA Installation Prompt */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Mobile App</CardTitle>
          <CardDescription>Install for better offline experience</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Install this app on your mobile device for:
            </p>
            <ul className="text-sm space-y-1 ml-4">
              <li>• Offline job management</li>
              <li>• Camera integration</li>
              <li>• GPS location tracking</li>
              <li>• Push notifications</li>
            </ul>
            <Button variant="outline" className="w-full">
              <Download className="h-4 w-4 mr-2" />
              Install Mobile App
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
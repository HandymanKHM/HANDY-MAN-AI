import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { JobWithClient, AssignJobData } from "@/lib/types";

interface AssignJobModalProps {
  job: JobWithClient | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: AssignJobData) => Promise<void>;
  isLoading: boolean;
}

const AssignJobModal = ({ job, isOpen, onClose, onConfirm, isLoading }: AssignJobModalProps) => {
  const [technician, setTechnician] = useState("");
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");
  const [notes, setNotes] = useState("");

  if (!isOpen || !job) return null;

  const handleSubmit = async () => {
    if (!technician || !scheduleDate || !scheduleTime) return;
    
    const data: AssignJobData = {
      jobId: job.id,
      claimId: job.claimId,
      technicianId: parseInt(technician),
      scheduleDate,
      scheduleTime,
      notes
    };
    
    await onConfirm(data);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
          <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
            <div className="sm:flex sm:items-start">
              <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                <span className="material-icons text-primary">assignment_ind</span>
              </div>
              <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                <h3 className="text-lg leading-6 font-medium text-gray-900 font-heading">
                  Assign Job {job.claimId}
                </h3>
                <div className="mt-4 space-y-4">
                  <div>
                    <label htmlFor="modal-technician" className="block text-sm font-medium text-gray-700">Select Technician</label>
                    <select 
                      id="modal-technician"
                      value={technician}
                      onChange={(e) => setTechnician(e.target.value)}
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
                    >
                      <option value="" disabled>Select a technician</option>
                      <option value="1">David Miller - Plumbing</option>
                      <option value="2">Robert Johnson - Plumbing</option>
                      <option value="3">Sarah Adams - Construction</option>
                      <option value="4">Michael Thompson - Construction</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="modal-date" className="block text-sm font-medium text-gray-700">Schedule Date</label>
                    <input 
                      type="date" 
                      id="modal-date"
                      value={scheduleDate}
                      onChange={(e) => setScheduleDate(e.target.value)}
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
                    />
                  </div>
                  <div>
                    <label htmlFor="modal-time" className="block text-sm font-medium text-gray-700">Schedule Time</label>
                    <select 
                      id="modal-time"
                      value={scheduleTime}
                      onChange={(e) => setScheduleTime(e.target.value)}
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
                    >
                      <option value="">Select a time slot</option>
                      <option value="08:00 - 10:00">08:00 - 10:00</option>
                      <option value="10:00 - 12:00">10:00 - 12:00</option>
                      <option value="12:00 - 14:00">12:00 - 14:00</option>
                      <option value="14:00 - 16:00">14:00 - 16:00</option>
                      <option value="16:00 - 18:00">16:00 - 18:00</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="modal-notes" className="block text-sm font-medium text-gray-700">Notes for Technician</label>
                    <textarea 
                      id="modal-notes" 
                      rows={3}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
                      placeholder="Add any special instructions..."
                    ></textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
            <Button
              type="button"
              disabled={isLoading || !technician || !scheduleDate || !scheduleTime}
              onClick={handleSubmit}
              className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-primary text-base font-medium text-white hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:ml-3 sm:w-auto sm:text-sm"
            >
              {isLoading ? "Assigning..." : "Assign"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
            >
              Cancel
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssignJobModal;

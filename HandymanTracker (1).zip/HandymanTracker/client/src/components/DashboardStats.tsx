import { DashboardStats as DashboardStatsType } from "@/lib/types";

interface DashboardStatsProps {
  stats: DashboardStatsType;
  isLoading: boolean;
}

const DashboardStats = ({ stats, isLoading }: DashboardStatsProps) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg shadow p-5">
            <div className="animate-pulse flex space-x-4">
              <div className="flex-1 space-y-4 py-1">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
              </div>
              <div className="rounded-full bg-gray-200 h-12 w-12"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {/* Stats Card: New Jobs */}
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">New Jobs</p>
            <h2 className="text-2xl font-bold text-gray-800">{stats.newJobs}</h2>
          </div>
          <div className="p-3 rounded-full bg-blue-100 text-primary">
            <span className="material-icons">fiber_new</span>
          </div>
        </div>
        <div className="flex items-center mt-4 text-xs">
          <span className="flex items-center text-success">
            <span className="material-icons text-sm mr-1">arrow_upward</span>
            16%
          </span>
          <span className="ml-2 text-gray-500">from last week</span>
        </div>
      </div>

      {/* Stats Card: In Progress */}
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">In Progress</p>
            <h2 className="text-2xl font-bold text-gray-800">{stats.inProgress}</h2>
          </div>
          <div className="p-3 rounded-full bg-orange-100 text-warning">
            <span className="material-icons">loop</span>
          </div>
        </div>
        <div className="flex items-center mt-4 text-xs">
          <span className="flex items-center text-error">
            <span className="material-icons text-sm mr-1">arrow_downward</span>
            3%
          </span>
          <span className="ml-2 text-gray-500">from last week</span>
        </div>
      </div>

      {/* Stats Card: Completed */}
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">Completed</p>
            <h2 className="text-2xl font-bold text-gray-800">{stats.completed}</h2>
          </div>
          <div className="p-3 rounded-full bg-green-100 text-success">
            <span className="material-icons">check_circle</span>
          </div>
        </div>
        <div className="flex items-center mt-4 text-xs">
          <span className="flex items-center text-success">
            <span className="material-icons text-sm mr-1">arrow_upward</span>
            12%
          </span>
          <span className="ml-2 text-gray-500">from last week</span>
        </div>
      </div>

      {/* Stats Card: Issues */}
      <div className="bg-white rounded-lg shadow p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-500 text-sm">Issues</p>
            <h2 className="text-2xl font-bold text-gray-800">{stats.issues}</h2>
          </div>
          <div className="p-3 rounded-full bg-red-100 text-error">
            <span className="material-icons">warning</span>
          </div>
        </div>
        <div className="flex items-center mt-4 text-xs">
          <span className="flex items-center text-error">
            <span className="material-icons text-sm mr-1">arrow_upward</span>
            8%
          </span>
          <span className="ml-2 text-gray-500">from last week</span>
        </div>
      </div>
    </div>
  );
};

export default DashboardStats;

import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Camera, Upload, Zap, AlertTriangle, CheckCircle, DollarSign } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface PhotoDiagnosis {
  problem: string;
  severity: 'minor' | 'moderate' | 'major' | 'emergency';
  urgency: 'immediate' | 'within_24h' | 'within_week' | 'routine';
  solutions: string[];
  preventiveMeasures: string[];
  estimatedCost: number;
}

const PhotoDiagnosis = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [description, setDescription] = useState("");
  const [diagnosis, setDiagnosis] = useState<PhotoDiagnosis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const analyzePhoto = async () => {
    if (!selectedFile) return;
    
    setIsAnalyzing(true);
    try {
      const formData = new FormData();
      formData.append('photo', selectedFile);
      if (description.trim()) {
        formData.append('description', description);
      }

      const result = await fetch('/api/ai/analyze-photo', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      if (!result.ok) {
        throw new Error('Analysis failed');
      }

      const diagnosisResult = await result.json();
      setDiagnosis(diagnosisResult);
    } catch (error) {
      console.error("Photo analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'emergency': return 'bg-red-500 text-white';
      case 'major': return 'bg-orange-500 text-white';
      case 'moderate': return 'bg-yellow-500 text-black';
      case 'minor': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'immediate': return 'bg-red-500 text-white';
      case 'within_24h': return 'bg-orange-500 text-white';
      case 'within_week': return 'bg-yellow-500 text-black';
      case 'routine': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Camera className="h-5 w-5 text-primary" />
            AI Photo Diagnosis
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Upload a photo to get instant AI-powered problem diagnosis and solutions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Upload Photo
                </label>
                <div
                  className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {previewUrl ? (
                    <img
                      src={previewUrl}
                      alt="Preview"
                      className="max-w-full h-40 object-cover mx-auto rounded-lg"
                    />
                  ) : (
                    <div className="space-y-2">
                      <Upload className="h-8 w-8 text-muted-foreground mx-auto" />
                      <p className="text-sm text-muted-foreground">
                        Click to upload photo or drag and drop
                      </p>
                    </div>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Additional Description (Optional)
                </label>
                <Input
                  placeholder="Any additional context about the issue..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="bg-background border-border text-foreground"
                />
              </div>

              <Button 
                onClick={analyzePhoto}
                disabled={isAnalyzing || !selectedFile}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                {isAnalyzing ? (
                  <>
                    <Zap className="h-4 w-4 mr-2 animate-spin" />
                    Analyzing Photo...
                  </>
                ) : (
                  <>
                    <Camera className="h-4 w-4 mr-2" />
                    Diagnose Problem
                  </>
                )}
              </Button>
            </div>

            {diagnosis && (
              <div className="space-y-4">
                <h3 className="font-semibold text-foreground">AI Diagnosis Results</h3>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="text-center">
                    <Badge className={getSeverityColor(diagnosis.severity)}>
                      {diagnosis.severity.toUpperCase()}
                    </Badge>
                    <p className="text-xs text-muted-foreground mt-1">Severity</p>
                  </div>
                  <div className="text-center">
                    <Badge className={getUrgencyColor(diagnosis.urgency)}>
                      {diagnosis.urgency.replace('_', ' ').toUpperCase()}
                    </Badge>
                    <p className="text-xs text-muted-foreground mt-1">Urgency</p>
                  </div>
                </div>

                <div className="bg-muted p-3 rounded-lg">
                  <h4 className="font-medium text-foreground mb-2">Problem Identified</h4>
                  <p className="text-sm text-muted-foreground">{diagnosis.problem}</p>
                </div>

                <div className="text-center bg-primary/10 p-3 rounded-lg border border-primary">
                  <div className="flex items-center justify-center gap-1 text-primary">
                    <DollarSign className="h-4 w-4" />
                    <span className="text-lg font-bold">${diagnosis.estimatedCost}</span>
                  </div>
                  <p className="text-xs text-primary">Estimated Cost</p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {diagnosis && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <CheckCircle className="h-5 w-5 text-green-500" />
                Recommended Solutions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {diagnosis.solutions.map((solution, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <span className="text-primary font-bold">{index + 1}.</span>
                    <span className="text-foreground">{solution}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                Preventive Measures
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {diagnosis.preventiveMeasures.map((measure, index) => (
                  <li key={index} className="flex items-start gap-2 text-sm">
                    <span className="text-yellow-500">•</span>
                    <span className="text-foreground">{measure}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default PhotoDiagnosis;
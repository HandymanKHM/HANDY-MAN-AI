import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface MFASectionProps {
  mfaCode: string;
  setMfaCode: (code: string) => void;
  onVerify: () => void;
  isLoading: boolean;
}

const MFASection = ({ mfaCode, setMfaCode, onVerify, isLoading }: MFASectionProps) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Only allow numbers and max 6 digits
    if (/^\d*$/.test(value) && value.length <= 6) {
      setMfaCode(value);
    }
  };

  return (
    <div className="mt-6 p-6 border border-border rounded-lg bg-secondary/50 backdrop-blur-sm">
      <h3 className="text-base font-medium text-foreground mb-2">🔐 Two-factor Authentication</h3>
      <p className="text-sm text-muted-foreground mb-4">
        Enter your 6-digit verification code from your authenticator app
      </p>
      <div className="flex gap-3">
        <Input
          type="text"
          maxLength={6}
          aria-label="Authentication code"
          className="block w-full px-4 py-3 border border-input rounded-lg shadow-sm placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary bg-background/50 backdrop-blur-sm transition-all duration-300 text-base hover:bg-background/70"
          placeholder="000000"
          value={mfaCode}
          onChange={handleInputChange}
        />
        <Button
          type="button"
          onClick={onVerify}
          disabled={isLoading || mfaCode.length !== 6}
          className="inline-flex items-center px-5 py-3 border border-transparent text-base font-medium tracking-wide rounded-lg text-primary-foreground bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg hover:shadow-xl transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2 focus:ring-offset-background"
        >
          {isLoading ? "Verifying..." : "Verify"}
        </Button>
      </div>
    </div>
  );
};

export default MFASection;

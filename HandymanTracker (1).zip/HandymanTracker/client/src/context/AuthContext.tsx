import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useToast } from "@/hooks/use-toast";
import { AuthUser } from '@/lib/types';
import { apiRequest } from '@/lib/queryClient';

interface AuthContextType {
  user: AuthUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isVerifyingMFA: boolean;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<boolean>;
  verifyMFA: (token: string) => Promise<boolean>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isVerifyingMFA, setIsVerifyingMFA] = useState<boolean>(false);
  const [pendingEmail, setPendingEmail] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      // Check for regular auth first
      const res = await fetch('/api/auth/me', { 
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (res.ok) {
        const userData = await res.json();
        setUser(userData);
        return;
      }

      // If regular auth fails, check for Replit auth
      try {
        const replitUserResponse = await fetch('/__replauthuser', {
          credentials: 'include'
        });
        
        if (replitUserResponse.ok) {
          const replitUser = await replitUserResponse.json();
          if (replitUser && replitUser.id) {
            // Trigger a page reload to let the Replit auth middleware handle it
            window.location.reload();
            return;
          }
        }
      } catch (replitError) {
        // Replit auth not available, that's fine
      }

      // No authentication available
      setUser(null);
    } catch (error) {
      setUser(null);
      console.error("Authentication check failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string, rememberMe = false): Promise<boolean> => {
    try {
      setIsLoading(true);
      const res = await apiRequest('POST', '/api/auth/login', { email, password, rememberMe });

      const data = await res.json();

      if (data.requireMFA) {
        setIsVerifyingMFA(true);
        setPendingEmail(email);
        return false;
      }

      setUser(data.user);
      return true;
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const verifyMFA = async (token: string): Promise<boolean> => {
    if (!pendingEmail) return false;

    try {
      setIsLoading(true);
      const res = await apiRequest('POST', '/api/auth/verify-mfa', { 
        email: pendingEmail,
        token
      });

      const data = await res.json();
      setUser(data.user);
      setIsVerifyingMFA(false);
      setPendingEmail(null);
      return true;
    } catch (error: any) {
      toast({
        title: "MFA Verification Failed",
        description: error.message || "Invalid verification code. Please try again.",
        variant: "destructive"
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', {});
      setUser(null);
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isLoading, 
      isAuthenticated: !!user,
      isVerifyingMFA,
      login, 
      verifyMFA,
      logout,
      checkAuth
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useSocket } from '@/hooks/useSocket';
import { DashboardStats, JobWithClient, WebSocketMessage, AssignJobData } from '@/lib/types';
import { apiRequest } from '@/lib/queryClient';
// Removed auth dependency

interface JobContextType {
  jobs: JobWithClient[];
  activities: any[];
  emailMonitoring: {
    status: string;
    lastChecked: string;
    email: string;
    processed: number;
  };
  stats: DashboardStats;
  isLoading: boolean;
  selectedJob: JobWithClient | null;
  assignJobModalOpen: boolean;
  jobDetailModalOpen: boolean;
  
  // Actions
  fetchJobs: () => Promise<void>;
  viewJobDetails: (jobId: number) => void;
  closeJobDetails: () => void;
  openAssignJobModal: (jobId: number) => void;
  closeAssignJobModal: () => void;
  assignJob: (data: AssignJobData) => Promise<boolean>;
}

const defaultStats: DashboardStats = {
  newJobs: 0,
  inProgress: 0,
  completed: 0,
  issues: 0
};

const defaultEmailMonitoring = {
  status: 'active',
  lastChecked: '1 minute ago',
  email: 'info@kimberleyhandyman.co.za',
  processed: 0
};

const JobContext = createContext<JobContextType | undefined>(undefined);

export const JobProvider = ({ children }: { children: ReactNode }) => {
  const [jobs, setJobs] = useState<JobWithClient[]>([]);
  const [activities, setActivities] = useState<any[]>([]);
  const [stats, setStats] = useState<DashboardStats>(defaultStats);
  const [emailMonitoring, setEmailMonitoring] = useState(defaultEmailMonitoring);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedJob, setSelectedJob] = useState<JobWithClient | null>(null);
  const [assignJobModalOpen, setAssignJobModalOpen] = useState<boolean>(false);
  const [jobDetailModalOpen, setJobDetailModalOpen] = useState<boolean>(false);
  
  const { toast } = useToast();
  const { socket } = useSocket();
  const isAuthenticated = true; // Removed auth check

  useEffect(() => {
    if (isAuthenticated) {
      fetchJobs();
      fetchActivities();
      fetchEmailMonitoring();
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (!socket) return;
    
    socket.addEventListener('message', (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        
        switch (message.type) {
          case 'newJob':
            handleNewJob(message.data);
            break;
          case 'jobUpdate':
            handleJobUpdate(message.data);
            break;
          case 'activityUpdate':
            handleActivityUpdate(message.data);
            break;
          case 'emailMonitoring':
            handleEmailMonitoringUpdate(message.data);
            break;
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    return () => {
      socket.removeEventListener('message', () => {});
    };
  }, [socket]);

  // Calculate stats based on jobs
  useEffect(() => {
    if (jobs.length === 0) return;
    
    const newStats = {
      newJobs: jobs.filter(job => job.status === 'new').length,
      inProgress: jobs.filter(job => job.status === 'in-progress' || job.status === 'assigned').length,
      completed: jobs.filter(job => job.status === 'completed').length,
      issues: jobs.filter(job => job.status === 'issue').length
    };
    
    setStats(newStats);
  }, [jobs]);

  const fetchJobs = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/jobs', { credentials: 'include' });
      
      if (res.ok) {
        const data = await res.json();
        setJobs(data);
      } else {
        throw new Error('Failed to fetch jobs');
      }
    } catch (error) {
      console.error("Error fetching jobs:", error);
      toast({
        title: "Error",
        description: "Failed to load jobs. Please refresh the page.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchActivities = async () => {
    try {
      const res = await fetch('/api/activities', { credentials: 'include' });
      
      if (res.ok) {
        const data = await res.json();
        setActivities(data);
      }
    } catch (error) {
      console.error("Error fetching activities:", error);
    }
  };

  const fetchEmailMonitoring = async () => {
    try {
      const res = await fetch('/api/email-monitoring', { credentials: 'include' });
      
      if (res.ok) {
        const data = await res.json();
        setEmailMonitoring({
          status: data.status,
          lastChecked: data.lastCheckedFormatted,
          email: 'info@kimberleyhandyman.co.za',
          processed: data.processedCount
        });
      }
    } catch (error) {
      console.error("Error fetching email monitoring status:", error);
    }
  };

  const handleNewJob = (job: JobWithClient) => {
    setJobs(prevJobs => {
      // Check if job already exists
      const exists = prevJobs.some(j => j.id === job.id);
      if (exists) return prevJobs;
      
      return [job, ...prevJobs];
    });
    
    toast({
      title: "New Job Request",
      description: `Claim #${job.claimId} received from ${job.client.insurer}`,
    });
  };

  const handleJobUpdate = (updatedJob: JobWithClient) => {
    setJobs(prevJobs => 
      prevJobs.map(job => job.id === updatedJob.id ? updatedJob : job)
    );
    
    // If the updated job is the selected one, update it
    if (selectedJob && selectedJob.id === updatedJob.id) {
      setSelectedJob(updatedJob);
    }
  };

  const handleActivityUpdate = (activity: any) => {
    setActivities(prevActivities => [activity, ...prevActivities]);
  };

  const handleEmailMonitoringUpdate = (data: any) => {
    setEmailMonitoring({
      status: data.status,
      lastChecked: data.lastCheckedFormatted,
      email: 'info@kimberleyhandyman.co.za',
      processed: data.processedCount
    });
  };

  const viewJobDetails = (jobId: number) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setSelectedJob(job);
      setJobDetailModalOpen(true);
    }
  };

  const closeJobDetails = () => {
    setJobDetailModalOpen(false);
  };

  const openAssignJobModal = (jobId: number) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      setSelectedJob(job);
      setAssignJobModalOpen(true);
    }
  };

  const closeAssignJobModal = () => {
    setAssignJobModalOpen(false);
  };

  const assignJob = async (data: AssignJobData): Promise<boolean> => {
    try {
      const res = await apiRequest('POST', '/api/jobs/assign', data);
      
      if (res.ok) {
        const updatedJob = await res.json();
        
        // Update jobs list
        setJobs(prevJobs => 
          prevJobs.map(job => job.id === updatedJob.id ? { ...job, ...updatedJob } : job)
        );
        
        toast({
          title: "Job Assigned",
          description: `Job ${data.claimId} has been successfully assigned.`,
        });
        
        return true;
      }
      
      return false;
    } catch (error: any) {
      toast({
        title: "Assignment Failed",
        description: error.message || "Failed to assign job. Please try again.",
        variant: "destructive"
      });
      return false;
    }
  };

  return (
    <JobContext.Provider value={{
      jobs,
      activities,
      emailMonitoring,
      stats,
      isLoading,
      selectedJob,
      assignJobModalOpen,
      jobDetailModalOpen,
      fetchJobs,
      viewJobDetails,
      closeJobDetails,
      openAssignJobModal,
      closeAssignJobModal,
      assignJob
    }}>
      {children}
    </JobContext.Provider>
  );
};

export const useJobs = () => {
  const context = useContext(JobContext);
  if (context === undefined) {
    throw new Error("useJobs must be used within a JobProvider");
  }
  return context;
};

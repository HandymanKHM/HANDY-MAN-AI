import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import TechnicianGuide from '@/components/TechnicianGuide';
import ClientCommunication from '@/components/ClientCommunication';
import { 
  Smartphone, 
  Wifi, 
  WifiOff, 
  Download, 
  Upload, 
  MapPin, 
  Camera, 
  FileText, 
  Clock,
  CheckCircle,
  AlertTriangle,
  User,
  Wrench,
  Navigation,
  Battery,
  Signal,
  RotateCcw,
  PhoneCall,
  MessageSquare,
  Calendar,
  Settings,
  HelpCircle,
  Star,
  Zap
} from 'lucide-react';

interface TechnicianJob {
  id: number;
  claimId: string;
  clientName: string;
  clientAddress: string;
  clientPhone: string;
  serviceType: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'assigned' | 'in_progress' | 'completed' | 'on_hold';
  scheduledDate: Date;
  estimatedDuration: number;
  materials: string[];
  photos: string[];
  notes: string;
  lastSynced?: Date;
  offlineChanges?: boolean;
}

interface OfflineCapability {
  isOnline: boolean;
  lastSync: Date | null;
  pendingUploads: number;
  storageUsed: number;
  maxStorage: number;
  syncProgress: number;
}

interface LocationData {
  latitude: number;
  longitude: number;
  timestamp: Date;
  accuracy: number;
}

export default function TechnicianMobileApp() {
  const [activeTab, setActiveTab] = useState('jobs');
  const [selectedJob, setSelectedJob] = useState<TechnicianJob | null>(null);
  const [isJobModalOpen, setIsJobModalOpen] = useState(false);
  const [offlineMode, setOfflineMode] = useState(false);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [jobNotes, setJobNotes] = useState('');
  const [jobStatus, setJobStatus] = useState('in_progress');
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([]);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const [showWelcomeGuide, setShowWelcomeGuide] = useState(false);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Simulate offline capability data
  const [offlineCapability, setOfflineCapability] = useState<OfflineCapability>({
    isOnline: navigator.onLine,
    lastSync: new Date(),
    pendingUploads: 0,
    storageUsed: 45,
    maxStorage: 100,
    syncProgress: 0
  });

  // Simulated technician jobs data
  const technicianJobs: TechnicianJob[] = [
    {
      id: 1,
      claimId: 'KH-2024-001',
      clientName: 'Sarah Johnson',
      clientAddress: '123 Main Street, Broome WA 6725',
      clientPhone: '+61 8 9192 1234',
      serviceType: 'Plumbing',
      description: 'Leaking kitchen faucet - requires immediate attention',
      priority: 'high',
      status: 'assigned',
      scheduledDate: new Date(),
      estimatedDuration: 2,
      materials: ['Faucet cartridge', 'Plumber\'s tape', 'O-rings'],
      photos: [],
      notes: '',
      lastSynced: new Date(),
      offlineChanges: false
    },
    {
      id: 2,
      claimId: 'KH-2024-002',
      clientName: 'Michael Chen',
      clientAddress: '456 Ocean Drive, Cable Beach WA 6726',
      clientPhone: '+61 8 9193 5678',
      serviceType: 'Electrical',
      description: 'Install ceiling fan in master bedroom',
      priority: 'medium',
      status: 'in_progress',
      scheduledDate: new Date(),
      estimatedDuration: 3,
      materials: ['Ceiling fan', 'Mounting bracket', 'Electrical wire'],
      photos: ['photo1.jpg'],
      notes: 'Customer prefers white fan. Existing wiring is adequate.',
      lastSynced: new Date(Date.now() - 30000),
      offlineChanges: true
    },
    {
      id: 3,
      claimId: 'KH-2024-003',
      clientName: 'Emma Thompson',
      clientAddress: '789 Sunset Boulevard, Broome WA 6725',
      clientPhone: '+61 8 9194 9012',
      serviceType: 'General Maintenance',
      description: 'Deck repair and staining',
      priority: 'low',
      status: 'completed',
      scheduledDate: new Date(Date.now() - 86400000),
      estimatedDuration: 6,
      materials: ['Deck stain', 'Sandpaper', 'Brushes', 'Wood filler'],
      photos: ['before.jpg', 'after.jpg'],
      notes: 'Completed ahead of schedule. Customer very satisfied.',
      lastSynced: new Date(),
      offlineChanges: false
    }
  ];

  // Monitor online/offline status and check for first-time users
  useEffect(() => {
    // Check if this is a first-time user
    const hasVisited = localStorage.getItem('technicianAppVisited');
    if (!hasVisited) {
      setShowWelcomeGuide(true);
      localStorage.setItem('technicianAppVisited', 'true');
    }

    const handleOnline = () => {
      setOfflineCapability(prev => ({ ...prev, isOnline: true }));
      toast({
        title: 'Back Online',
        description: 'Syncing your data now...',
      });
      // Trigger sync
      syncOfflineData();
    };

    const handleOffline = () => {
      setOfflineCapability(prev => ({ ...prev, isOnline: false }));
      toast({
        title: 'Offline Mode',
        description: 'Working offline. Changes will sync when reconnected.',
        variant: 'destructive'
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [toast]);

  // Get current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            timestamp: new Date(),
            accuracy: position.coords.accuracy
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
      );
    }
  }, []);

  const syncOfflineData = async () => {
    setOfflineCapability(prev => ({ ...prev, syncProgress: 0 }));
    
    // Simulate sync progress
    for (let i = 0; i <= 100; i += 10) {
      setTimeout(() => {
        setOfflineCapability(prev => ({ ...prev, syncProgress: i }));
      }, i * 20);
    }

    setTimeout(() => {
      setOfflineCapability(prev => ({
        ...prev,
        lastSync: new Date(),
        pendingUploads: 0,
        syncProgress: 100
      }));
      
      toast({
        title: 'Sync Complete',
        description: 'All offline changes have been synchronized.',
      });
    }, 2000);
  };

  const updateJobStatus = (jobId: number, status: string, notes: string) => {
    // In a real app, this would update local storage and queue for sync
    toast({
      title: 'Job Updated',
      description: `Job status changed to ${status}. ${offlineCapability.isOnline ? 'Synced to server.' : 'Saved locally for sync.'}`,
    });

    if (!offlineCapability.isOnline) {
      setOfflineCapability(prev => ({ 
        ...prev, 
        pendingUploads: prev.pendingUploads + 1 
      }));
    }
  };

  const capturePhoto = () => {
    // Simulate photo capture
    const photoId = `photo_${Date.now()}.jpg`;
    setCapturedPhotos(prev => [...prev, photoId]);
    
    toast({
      title: 'Photo Captured',
      description: `Photo saved ${offlineCapability.isOnline ? 'and uploaded' : 'locally for upload when online'}.`,
    });

    if (!offlineCapability.isOnline) {
      setOfflineCapability(prev => ({ 
        ...prev, 
        pendingUploads: prev.pendingUploads + 1,
        storageUsed: prev.storageUsed + 2
      }));
    }
  };

  const makePhoneCall = (phoneNumber: string) => {
    if ('serviceWorker' in navigator) {
      // In a real mobile app, this would initiate a phone call
      window.open(`tel:${phoneNumber}`);
    }
  };

  const openMaps = (address: string) => {
    const encodedAddress = encodeURIComponent(address);
    if (location) {
      // Use current location for navigation
      window.open(`https://maps.google.com/maps?saddr=${location.latitude},${location.longitude}&daddr=${encodedAddress}`);
    } else {
      // Just open address in maps
      window.open(`https://maps.google.com/maps?q=${encodedAddress}`);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'destructive';
      case 'high': return 'secondary';
      case 'medium': return 'outline';
      case 'low': return 'default';
      default: return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'in_progress': return 'bg-blue-500';
      case 'assigned': return 'bg-yellow-500';
      case 'on_hold': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4 max-w-md mx-auto">
      {/* Mobile Header */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Smartphone className="h-6 w-6 text-blue-600" />
            <div>
              <h1 className="text-lg font-bold">Technician App</h1>
              <p className="text-xs text-gray-500">Kimberley Handyman</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {offlineCapability.isOnline ? (
              <div className="flex items-center space-x-1 text-green-600">
                <Wifi className="h-4 w-4" />
                <Signal className="h-4 w-4" />
              </div>
            ) : (
              <div className="flex items-center space-x-1 text-red-600">
                <WifiOff className="h-4 w-4" />
                <span className="text-xs">Offline</span>
              </div>
            )}
            <Battery className="h-4 w-4 text-gray-600" />
          </div>
        </div>

        {/* Sync Status */}
        {!offlineCapability.isOnline && offlineCapability.pendingUploads > 0 && (
          <div className="mt-3 p-2 bg-yellow-50 rounded border border-yellow-200">
            <div className="flex items-center space-x-2">
              <Upload className="h-4 w-4 text-yellow-600" />
              <span className="text-sm text-yellow-700">
                {offlineCapability.pendingUploads} items pending sync
              </span>
            </div>
          </div>
        )}

        {offlineCapability.syncProgress > 0 && offlineCapability.syncProgress < 100 && (
          <div className="mt-3">
            <div className="flex items-center justify-between text-sm mb-1">
              <span>Syncing...</span>
              <span>{offlineCapability.syncProgress}%</span>
            </div>
            <Progress value={offlineCapability.syncProgress} className="h-2" />
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <Button 
          variant="outline" 
          className="h-16 flex flex-col items-center justify-center"
          onClick={() => setActiveTab('jobs')}
        >
          <Tool className="h-5 w-5 mb-1" />
          <span className="text-xs">My Jobs</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="h-16 flex flex-col items-center justify-center"
          onClick={syncOfflineData}
          disabled={!offlineCapability.isOnline}
        >
          <Sync className="h-5 w-5 mb-1" />
          <span className="text-xs">Sync Data</span>
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="jobs">Jobs</TabsTrigger>
          <TabsTrigger value="tools">Tools</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="jobs" className="space-y-3">
          {technicianJobs.map((job) => (
            <Card key={job.id} className="relative">
              {job.offlineChanges && (
                <div className="absolute top-2 right-2">
                  <Badge variant="outline" className="text-xs">
                    <Upload className="h-3 w-3 mr-1" />
                    Sync pending
                  </Badge>
                </div>
              )}
              
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{job.claimId}</CardTitle>
                    <CardDescription className="text-sm">{job.clientName}</CardDescription>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(job.status)}`} />
                </div>
                
                <div className="flex items-center space-x-2">
                  <Badge variant={getPriorityColor(job.priority)}>{job.priority}</Badge>
                  <Badge variant="outline">{job.serviceType}</Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-3">
                <p className="text-sm text-gray-600">{job.description}</p>
                
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <MapPin className="h-4 w-4" />
                  <span className="flex-1 truncate">{job.clientAddress}</span>
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Clock className="h-4 w-4" />
                  <span>Est. {job.estimatedDuration}h</span>
                  {job.photos.length > 0 && (
                    <>
                      <Camera className="h-4 w-4 ml-2" />
                      <span>{job.photos.length}</span>
                    </>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        setSelectedJob(job);
                        setJobNotes(job.notes);
                        setJobStatus(job.status);
                        setIsJobModalOpen(true);
                      }}
                    >
                      <Wrench className="h-4 w-4 mr-1" />
                      Work
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => makePhoneCall(job.clientPhone)}
                    >
                      <PhoneCall className="h-4 w-4" />
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openMaps(job.clientAddress)}
                    >
                      <Navigation className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Smart Client Communication */}
                  <ClientCommunication 
                    job={{
                      id: job.id,
                      claimId: job.claimId,
                      clientName: job.clientName,
                      clientPhone: job.clientPhone,
                      serviceType: job.serviceType,
                      description: job.description,
                      status: job.status
                    }}
                    technicianName="Your Kimberley Handyman Technician"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="tools" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quick Tools</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="h-16 flex flex-col" onClick={capturePhoto}>
                <Camera className="h-5 w-5 mb-1" />
                <span className="text-xs">Take Photo</span>
              </Button>
              
              <Button variant="outline" className="h-16 flex flex-col">
                <FileText className="h-5 w-5 mb-1" />
                <span className="text-xs">Notes</span>
              </Button>
              
              <Button variant="outline" className="h-16 flex flex-col">
                <MessageSquare className="h-5 w-5 mb-1" />
                <span className="text-xs">Messages</span>
              </Button>
              
              <Button variant="outline" className="h-16 flex flex-col">
                <Calendar className="h-5 w-5 mb-1" />
                <span className="text-xs">Schedule</span>
              </Button>
            </CardContent>
          </Card>

          {capturedPhotos.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Photos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2">
                  {capturedPhotos.map((photo, index) => (
                    <div key={index} className="aspect-square bg-gray-200 rounded-lg flex items-center justify-center">
                      <Camera className="h-6 w-6 text-gray-400" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          {/* Smart Help & Guide */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                <HelpCircle className="h-5 w-5 mr-2 text-blue-600" />
                Smart Help & Training
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => setIsGuideOpen(true)}
              >
                <Star className="h-4 w-4 mr-2" />
                Interactive App Guide
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => setShowWelcomeGuide(true)}
              >
                <Zap className="h-4 w-4 mr-2" />
                Welcome Tutorial
              </Button>
              
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-800">
                  💡 <strong>Pro Tip:</strong> Tap the help button anytime you need guidance on using any feature!
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Offline Storage</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Storage Used</span>
                <span>{offlineCapability.storageUsed}MB / {offlineCapability.maxStorage}MB</span>
              </div>
              <Progress value={(offlineCapability.storageUsed / offlineCapability.maxStorage) * 100} />
              
              <div className="flex justify-between text-sm">
                <span>Last Sync</span>
                <span>{offlineCapability.lastSync?.toLocaleTimeString()}</span>
              </div>
              
              <Button 
                size="sm" 
                variant="outline" 
                className="w-full"
                onClick={syncOfflineData}
                disabled={!offlineCapability.isOnline}
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Force Sync
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Location Services</CardTitle>
            </CardHeader>
            <CardContent>
              {location ? (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Latitude</span>
                    <span>{location.latitude.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Longitude</span>
                    <span>{location.longitude.toFixed(6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Accuracy</span>
                    <span>{location.accuracy.toFixed(0)}m</span>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-gray-500">Location access not available</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Job Detail Modal */}
      <Dialog open={isJobModalOpen} onOpenChange={setIsJobModalOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{selectedJob?.claimId}</DialogTitle>
            <DialogDescription>{selectedJob?.clientName}</DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Status</label>
              <Select value={jobStatus} onValueChange={setJobStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="on_hold">On Hold</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">Notes</label>
              <Textarea
                placeholder="Add job notes..."
                value={jobNotes}
                onChange={(e) => setJobNotes(e.target.value)}
                rows={3}
              />
            </div>

            <div className="flex space-x-2">
              <Button 
                className="flex-1"
                onClick={() => {
                  if (selectedJob) {
                    updateJobStatus(selectedJob.id, jobStatus, jobNotes);
                    setIsJobModalOpen(false);
                  }
                }}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Update Job
              </Button>
              
              <Button variant="outline" onClick={capturePhoto}>
                <Camera className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Interactive Guide System */}
      <TechnicianGuide 
        isOpen={isGuideOpen || showWelcomeGuide}
        onClose={() => {
          setIsGuideOpen(false);
          setShowWelcomeGuide(false);
        }}
        activeFeature={activeTab}
      />
    </div>
  );
}
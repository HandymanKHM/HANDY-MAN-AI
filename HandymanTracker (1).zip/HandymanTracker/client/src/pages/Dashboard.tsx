import { useState, useEffect } from "react";
import { useJobs } from "@/context/JobContext";
import Sidebar from "@/components/Sidebar";
import Topbar from "@/components/Topbar";
import DashboardStats from "@/components/DashboardStats";
import EmailMonitoringStatus from "@/components/EmailMonitoringStatus";
import JobTable from "@/components/JobTable";
import RecentActivity from "@/components/RecentActivity";
import JobDetailModal from "@/components/JobDetailModal";
import AssignJobModal from "@/components/AssignJobModal";
import Toast from "@/components/ui/toast-simple";

const Dashboard = () => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState({ title: "", message: "" });
  
  const { 
    jobs, 
    activities, 
    emailMonitoring, 
    stats, 
    isLoading,
    selectedJob,
    assignJobModalOpen,
    jobDetailModalOpen,
    viewJobDetails,
    closeJobDetails,
    openAssignJobModal,
    closeAssignJobModal,
    assignJob
  } = useJobs();

  const toggleSidebar = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  const handleViewJobDetails = (jobId: number) => {
    viewJobDetails(jobId);
  };

  const handleAssignJob = (jobId: number) => {
    openAssignJobModal(jobId);
  };

  const handleAssignJobFromDetails = () => {
    if (selectedJob) {
      closeJobDetails();
      openAssignJobModal(selectedJob.id);
    }
  };

  const handleConfirmAssignment = async (data: any) => {
    const success = await assignJob(data);
    
    if (success) {
      closeAssignJobModal();
      setToastMessage({
        title: "Job Assigned",
        message: `Job ${data.claimId} has been successfully assigned.`
      });
      setShowToast(true);
    }
  };

  return (
    <div className="h-screen flex overflow-hidden bg-neutral-light" data-component="DashboardLayout">
      <Sidebar isMobileOpen={isMobileOpen} setIsMobileOpen={setIsMobileOpen} />
      
      <div className="flex-1 overflow-auto">
        <Topbar toggleSidebar={toggleSidebar} />
        
        <div className="p-6">
          <DashboardStats stats={stats} isLoading={isLoading} />
          
          <EmailMonitoringStatus 
            status={emailMonitoring.status}
            email={emailMonitoring.email}
            lastChecked={emailMonitoring.lastChecked}
            processed={emailMonitoring.processed}
          />
          
          <JobTable 
            jobs={jobs}
            isLoading={isLoading}
            onViewDetails={handleViewJobDetails}
            onAssignJob={handleAssignJob}
          />
          
          <RecentActivity activities={activities} isLoading={isLoading} />
        </div>
      </div>
      
      <JobDetailModal 
        job={selectedJob}
        isOpen={jobDetailModalOpen}
        onClose={closeJobDetails}
        onAssign={handleAssignJobFromDetails}
      />
      
      <AssignJobModal 
        job={selectedJob}
        isOpen={assignJobModalOpen}
        onClose={closeAssignJobModal}
        onConfirm={handleConfirmAssignment}
        isLoading={false}
      />
      
      {showToast && (
        <Toast 
          title={toastMessage.title}
          message={toastMessage.message}
          onClose={() => setShowToast(false)}
        />
      )}
    </div>
  );
};

export default Dashboard;

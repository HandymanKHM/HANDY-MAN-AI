import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";

const HomePage = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading) {
      if (isAuthenticated) {
        setLocation("/dashboard");
      } else {
        setLocation("/auth");
      }
    }
  }, [isAuthenticated, isLoading, setLocation]);

  return (
    <Layout>
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse">
          <svg 
            className="h-16 w-auto mx-auto" 
            viewBox="0 0 24 24" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg">
            <rect width="24" height="24" rx="4" fill="#1E4D8C"/>
            <path d="M7 12H8.5M12 7V8.5M17 12H15.5M12 17V15.5M9 9L10.5 10.5M15 9L13.5 10.5M15 15L13.5 13.5M9 15L10.5 13.5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
            <circle cx="12" cy="12" r="3" stroke="white" strokeWidth="1.5"/>
          </svg>
          <h2 className="mt-6 text-3xl font-extrabold text-center text-neutral-dark font-heading">
            Kimberley Handyman
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Field Service Management System
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Camera, MessageSquare, TrendingUp, Zap, Bot } from "lucide-react";
import AIJobAnalyzer from "@/components/AIJobAnalyzer";
import PhotoDiagnosis from "@/components/PhotoDiagnosis";

const AIAutomation = () => {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-4 mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="p-3 bg-primary/10 rounded-full">
            <Bot className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-4xl font-light tracking-tight text-foreground">
            AI Automation Center
          </h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Harness the power of artificial intelligence to transform your handyman operations with intelligent analysis, automated quotes, and predictive insights.
        </p>
        <div className="flex items-center justify-center gap-2 text-sm text-primary">
          <Zap className="h-4 w-4" />
          <span>Powered by GPT-4o Advanced AI</span>
        </div>
      </div>

      <Tabs defaultValue="analyzer" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="analyzer" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Job Analyzer
          </TabsTrigger>
          <TabsTrigger value="photo" className="flex items-center gap-2">
            <Camera className="h-4 w-4" />
            Photo Diagnosis
          </TabsTrigger>
          <TabsTrigger value="communication" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            Auto Messages
          </TabsTrigger>
          <TabsTrigger value="predictive" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Predictive
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analyzer">
          <AIJobAnalyzer />
        </TabsContent>

        <TabsContent value="photo">
          <PhotoDiagnosis />
        </TabsContent>

        <TabsContent value="communication">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Bot className="h-5 w-5 text-primary" />
                Kimberley Handyman Admin Assistant
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                Your intelligent AI helper powered by Google's Gemini 2.0 Flash
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="p-3 bg-primary/10 rounded-full">
                    <Bot className="h-8 w-8 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-foreground">AI Assistant Available</h3>
                    <p className="text-sm text-muted-foreground">Powered by Google Gemini 2.0 Flash</p>
                  </div>
                </div>
                <p className="text-muted-foreground max-w-md mx-auto mb-6">
                  Your personal AI guide to mastering every feature of the Field Service Management System. 
                  Get instant help with workflows, features, and best practices.
                </p>
                <Button 
                  onClick={() => window.open('/assistant', '_blank')}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Open Admin Assistant
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictive">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <TrendingUp className="h-5 w-5 text-primary" />
                Predictive Maintenance Analytics
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                AI-powered insights to predict and prevent future maintenance issues
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">Advanced Analytics</h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Predictive maintenance analysis will help identify potential issues before they become 
                  costly emergencies, saving your clients time and money.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AIAutomation;
import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Bot, 
  Brain, 
  FileText, 
  MessageSquare, 
  Shield, 
  Zap, 
  Eye,
  User,
  Settings,
  Download,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Activity
} from 'lucide-react';

interface Agent {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'error';
  uptime: string;
}

interface AgentResponse {
  response: string;
  agentsInvolved: string[];
  recommendations: string[];
  nextActions: string[];
}

interface UserFeedback {
  feedbackType: 'error' | 'enhancement' | 'bug' | 'feature_request' | 'performance';
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  context: {
    page: string;
    action: string;
    reproductionSteps?: string[];
  };
}

export default function AIAgentDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [agentRequest, setAgentRequest] = useState('');
  const [feedbackForm, setFeedbackForm] = useState<UserFeedback>({
    feedbackType: 'error',
    description: '',
    severity: 'medium',
    context: {
      page: '',
      action: ''
    }
  });
  const [reproductionSteps, setReproductionSteps] = useState(['']);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch agent status
  const { data: agentStatus } = useQuery({
    queryKey: ['/api/agents/status'],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Fetch system report
  const { data: systemReport } = useQuery({
    queryKey: ['/api/agents/system-report'],
    enabled: activeTab === 'reports'
  });

  // Process agent request mutation
  const processRequestMutation = useMutation({
    mutationFn: (data: { request: string; context: any }) => 
      apiRequest('/api/agents/process', 'POST', data),
    onSuccess: () => {
      toast({
        title: 'Request Processed',
        description: 'AI agents have successfully processed your request',
      });
    }
  });

  // Submit feedback mutation
  const submitFeedbackMutation = useMutation({
    mutationFn: (data: UserFeedback) => 
      apiRequest('/api/agents/feedback', 'POST', data),
    onSuccess: () => {
      toast({
        title: 'Feedback Submitted',
        description: 'Your feedback has been analyzed by our AI agents',
      });
      setFeedbackForm({
        feedbackType: 'error',
        description: '',
        severity: 'medium',
        context: { page: '', action: '' }
      });
      setReproductionSteps(['']);
    }
  });

  // Export system data mutation
  const exportDataMutation = useMutation({
    mutationFn: () => apiRequest('/api/agents/export-data', 'POST'),
    onSuccess: (data) => {
      toast({
        title: 'System Data Exported',
        description: 'Comprehensive analysis report has been generated',
      });
      // Trigger download
      const link = document.createElement('a');
      link.href = data.uploadUrl;
      link.download = data.filename;
      link.click();
    }
  });

  const handleProcessRequest = () => {
    if (!agentRequest.trim()) return;
    
    processRequestMutation.mutate({
      request: agentRequest,
      context: {
        page: 'ai-agent-dashboard',
        timestamp: new Date(),
        userAction: 'manual_request'
      }
    });
  };

  const handleSubmitFeedback = () => {
    const feedbackData = {
      ...feedbackForm,
      context: {
        ...feedbackForm.context,
        reproductionSteps: reproductionSteps.filter(step => step.trim())
      }
    };
    
    submitFeedbackMutation.mutate(feedbackData);
  };

  const addReproductionStep = () => {
    setReproductionSteps([...reproductionSteps, '']);
  };

  const updateReproductionStep = (index: number, value: string) => {
    const newSteps = [...reproductionSteps];
    newSteps[index] = value;
    setReproductionSteps(newSteps);
  };

  const removeReproductionStep = (index: number) => {
    setReproductionSteps(reproductionSteps.filter((_, i) => i !== index));
  };

  const getAgentIcon = (agentId: string) => {
    switch (agentId) {
      case 'orchestrator': return <Bot className="h-5 w-5" />;
      case 'document_manager': return <FileText className="h-5 w-5" />;
      case 'feedback_analyzer': return <MessageSquare className="h-5 w-5" />;
      case 'system_optimizer': return <Zap className="h-5 w-5" />;
      case 'user_experience': return <User className="h-5 w-5" />;
      case 'performance_monitor': return <Activity className="h-5 w-5" />;
      case 'security_guardian': return <Shield className="h-5 w-5" />;
      default: return <Brain className="h-5 w-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'inactive': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'secondary';
      case 'medium': return 'outline';
      case 'low': return 'default';
      default: return 'default';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">AI Agent Dashboard</h1>
          <p className="text-muted-foreground">
            Intelligent automation and analysis for Kimberley Handyman operations
          </p>
        </div>
        <Button 
          onClick={() => exportDataMutation.mutate()}
          disabled={exportDataMutation.isPending}
          variant="outline"
        >
          <Download className="h-4 w-4 mr-2" />
          {exportDataMutation.isPending ? 'Exporting...' : 'Export System Data'}
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="interact">Interact</TabsTrigger>
          <TabsTrigger value="feedback">Feedback</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Agents</CardTitle>
                <Bot className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {agentStatus?.agents?.filter((a: Agent) => a.status === 'active').length || 7}
                </div>
                <p className="text-xs text-muted-foreground">
                  Specialized AI agents running
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">System Health</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {agentStatus?.systemHealth || 'Excellent'}
                </div>
                <p className="text-xs text-muted-foreground">
                  Overall system performance
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Last Update</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Just now</div>
                <p className="text-xs text-muted-foreground">
                  Real-time monitoring active
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>AI Agent Status</CardTitle>
              <CardDescription>
                Monitor the status and performance of all specialized AI agents
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {agentStatus?.agents?.map((agent: Agent) => (
                  <div key={agent.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                    <div className="flex items-center space-x-2">
                      {getAgentIcon(agent.id)}
                      <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{agent.name}</p>
                      <p className="text-xs text-muted-foreground">Uptime: {agent.uptime}</p>
                    </div>
                  </div>
                )) || (
                  // Default agents display when data is loading
                  [
                    { id: 'orchestrator', name: 'AI Orchestrator Manager', status: 'active', uptime: '99.9%' },
                    { id: 'document_manager', name: 'Document Intelligence Manager', status: 'active', uptime: '99.8%' },
                    { id: 'feedback_analyzer', name: 'Feedback Intelligence Analyst', status: 'active', uptime: '99.7%' },
                    { id: 'system_optimizer', name: 'System Performance Optimizer', status: 'active', uptime: '99.9%' },
                    { id: 'user_experience', name: 'User Experience Specialist', status: 'active', uptime: '99.6%' },
                    { id: 'performance_monitor', name: 'Performance Monitor', status: 'active', uptime: '100%' },
                    { id: 'security_guardian', name: 'Security Guardian', status: 'active', uptime: '100%' }
                  ].map((agent) => (
                    <div key={agent.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                      <div className="flex items-center space-x-2">
                        {getAgentIcon(agent.id)}
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(agent.status)}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{agent.name}</p>
                        <p className="text-xs text-muted-foreground">Uptime: {agent.uptime}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="interact" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Interact with AI Agents</CardTitle>
              <CardDescription>
                Send requests to the AI orchestrator system for intelligent processing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Request</label>
                <Textarea
                  placeholder="Describe what you need help with... (e.g., 'Analyze system performance', 'Generate job optimization recommendations', 'Review recent user feedback')"
                  value={agentRequest}
                  onChange={(e) => setAgentRequest(e.target.value)}
                  rows={4}
                />
              </div>
              <Button 
                onClick={handleProcessRequest}
                disabled={processRequestMutation.isPending || !agentRequest.trim()}
                className="w-full"
              >
                <Brain className="h-4 w-4 mr-2" />
                {processRequestMutation.isPending ? 'Processing...' : 'Process with AI Agents'}
              </Button>

              {processRequestMutation.data && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-lg">AI Agent Response</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Response:</h4>
                      <p className="text-sm text-muted-foreground">
                        {processRequestMutation.data.response}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Agents Involved:</h4>
                      <div className="flex flex-wrap gap-2">
                        {processRequestMutation.data.agentsInvolved?.map((agentId: string) => (
                          <Badge key={agentId} variant="secondary">
                            {agentId.replace('_', ' ')}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {processRequestMutation.data.recommendations?.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Recommendations:</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {processRequestMutation.data.recommendations.map((rec: string, index: number) => (
                            <li key={index} className="flex items-start space-x-2">
                              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {processRequestMutation.data.nextActions?.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Next Actions:</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          {processRequestMutation.data.nextActions.map((action: string, index: number) => (
                            <li key={index} className="flex items-start space-x-2">
                              <TrendingUp className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                              <span>{action}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="feedback" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Submit Feedback</CardTitle>
              <CardDescription>
                Report issues, suggest improvements, or share your experience for AI analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Feedback Type</label>
                  <Select 
                    value={feedbackForm.feedbackType} 
                    onValueChange={(value: any) => setFeedbackForm({...feedbackForm, feedbackType: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="error">Error/Bug</SelectItem>
                      <SelectItem value="enhancement">Enhancement</SelectItem>
                      <SelectItem value="feature_request">Feature Request</SelectItem>
                      <SelectItem value="performance">Performance Issue</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Severity</label>
                  <Select 
                    value={feedbackForm.severity} 
                    onValueChange={(value: any) => setFeedbackForm({...feedbackForm, severity: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Page/Section</label>
                  <Input
                    placeholder="e.g., Dashboard, Job Management, Client Details"
                    value={feedbackForm.context.page}
                    onChange={(e) => setFeedbackForm({
                      ...feedbackForm,
                      context: {...feedbackForm.context, page: e.target.value}
                    })}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Action</label>
                  <Input
                    placeholder="e.g., Creating job, Uploading file, Logging in"
                    value={feedbackForm.context.action}
                    onChange={(e) => setFeedbackForm({
                      ...feedbackForm,
                      context: {...feedbackForm.context, action: e.target.value}
                    })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <Textarea
                  placeholder="Describe the issue, enhancement, or feedback in detail..."
                  value={feedbackForm.description}
                  onChange={(e) => setFeedbackForm({...feedbackForm, description: e.target.value})}
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Reproduction Steps (Optional)</label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addReproductionStep}
                  >
                    Add Step
                  </Button>
                </div>
                {reproductionSteps.map((step, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground min-w-[20px]">{index + 1}.</span>
                    <Input
                      placeholder="Describe this step..."
                      value={step}
                      onChange={(e) => updateReproductionStep(index, e.target.value)}
                    />
                    {reproductionSteps.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeReproductionStep(index)}
                      >
                        ×
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <Button 
                onClick={handleSubmitFeedback}
                disabled={submitFeedbackMutation.isPending || !feedbackForm.description.trim()}
                className="w-full"
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                {submitFeedbackMutation.isPending ? 'Submitting...' : 'Submit for AI Analysis'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Reports & Analytics</CardTitle>
              <CardDescription>
                Comprehensive system analysis and insights from AI agents
              </CardDescription>
            </CardHeader>
            <CardContent>
              {systemReport ? (
                <div className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold">{systemReport.feedbackSummary?.total || 0}</div>
                        <p className="text-xs text-muted-foreground">Total Feedback</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold text-red-600">
                          {systemReport.criticalIssues?.length || 0}
                        </div>
                        <p className="text-xs text-muted-foreground">Critical Issues</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold text-green-600">
                          {systemReport.recommendations?.length || 0}
                        </div>
                        <p className="text-xs text-muted-foreground">Recommendations</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold text-blue-600">99.9%</div>
                        <p className="text-xs text-muted-foreground">System Uptime</p>
                      </CardContent>
                    </Card>
                  </div>

                  {systemReport.recommendations?.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">AI Recommendations</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {systemReport.recommendations.map((rec: string, index: number) => (
                            <li key={index} className="flex items-start space-x-2">
                              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span className="text-sm">{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  )}

                  {systemReport.criticalIssues?.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Critical Issues</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {systemReport.criticalIssues.map((issue: any, index: number) => (
                            <div key={index} className="flex items-start space-x-3 p-3 border rounded-lg">
                              <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-1">
                                  <Badge variant={getSeverityColor(issue.severity)}>
                                    {issue.severity}
                                  </Badge>
                                  <span className="text-sm font-medium">{issue.feedbackType}</span>
                                </div>
                                <p className="text-sm text-muted-foreground">{issue.description}</p>
                                {issue.context?.page && (
                                  <p className="text-xs text-muted-foreground mt-1">
                                    Page: {issue.context.page} | Action: {issue.context.action}
                                  </p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Loading system reports...</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
# Google Cloud Service Account Setup

Your system needs Service Account credentials (not OAuth credentials) to work with Google Cloud services.

## Steps to Get Service Account Credentials:

1. Go to Google Cloud Console: https://console.cloud.google.com
2. Select your project: `apt-deployment-457300-f0`
3. Navigate to "IAM & Admin" → "Service Accounts"
4. Click "Create Service Account"
5. Give it a name like "kimberley-handyman-service"
6. Grant these roles:
   - Storage Admin
   - Document AI User
   - Firestore User
7. Click "Create and Continue"
8. Click "Done"
9. Click on the created service account
10. Go to "Keys" tab
11. Click "Add Key" → "Create New Key"
12. Select "JSON" format
13. Download the JSON file

The JSON file will contain:
- project_id
- client_email  
- private_key

These are the three values I need to configure your cloud services.

export class ServiceError extends Error {
  constructor(
    message: string,
    public service: string,
    public code: string,
    public statusCode: number = 500
  ) {
    super(message);
    this.name = 'ServiceError';
  }
}

export function handleServiceError(error: any, service: string): ServiceError {
  if (error instanceof ServiceError) {
    return error;
  }

  // Google Cloud specific errors
  if (error.code === 'ERR_OSSL_UNSUPPORTED') {
    return new ServiceError(
      'Google Cloud credentials are invalid or corrupted. Please check your private key format.',
      service,
      'INVALID_CREDENTIALS',
      401
    );
  }

  if (error.message?.includes('DECODER routines')) {
    return new ServiceError(
      'Private key format is incorrect. Please ensure proper line breaks and formatting.',
      service,
      'INVALID_KEY_FORMAT',
      401
    );
  }

  return new ServiceError(
    error.message || 'Unknown error occurred',
    service,
    'UNKNOWN_ERROR',
    500
  );
}

export function logServiceStatus(service: string, status: 'available' | 'unavailable', reason?: string) {
  const emoji = status === 'available' ? '✅' : '⚠️';
  console.log(`${emoji} ${service}: ${status}${reason ? ` - ${reason}` : ''}`);
}

import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import * as speakeasy from 'speakeasy';
import * as QRCode from 'qrcode';
import jwt from 'jsonwebtoken';
import { storage } from './storage';
import { loginSchema, mfaSchema } from '@shared/schema';
import { validationMiddleware } from './middleware';

// Enhanced Security Configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secure-jwt-secret-key-change-in-production';
const JWT_EXPIRATION = '15m'; // Short-lived tokens for maximum security
const REFRESH_TOKEN_EXPIRATION = '7d';
const SALT_ROUNDS = 12; // High bcrypt rounds for maximum password security
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME = 15 * 60 * 1000; // 15 minutes lockout

// Security tracking
const loginAttempts = new Map<string, { count: number; lastAttempt: Date; lockedUntil?: Date }>();
const activeTokens = new Set<string>(); // Track active tokens for invalidation

// Security helper functions
const isRateLimited = (ip: string, email: string): boolean => {
  const identifier = `${ip}:${email}`;
  const now = new Date();
  const attempts = loginAttempts.get(identifier);

  if (!attempts) {
    loginAttempts.set(identifier, { count: 1, lastAttempt: now });
    return false;
  }

  // Check if still locked out
  if (attempts.lockedUntil && now < attempts.lockedUntil) {
    return true;
  }

  // Reset if lockout period has passed
  if (attempts.lockedUntil && now >= attempts.lockedUntil) {
    loginAttempts.set(identifier, { count: 1, lastAttempt: now });
    return false;
  }

  // Increment attempts
  attempts.count++;
  attempts.lastAttempt = now;

  // Lock if too many attempts
  if (attempts.count >= MAX_LOGIN_ATTEMPTS) {
    attempts.lockedUntil = new Date(now.getTime() + LOCKOUT_TIME);
    return true;
  }

  return false;
};

const resetLoginAttempts = (ip: string, email: string): void => {
  const identifier = `${ip}:${email}`;
  loginAttempts.delete(identifier);
};

// Generate a JWT token
const generateToken = (userId: number): string => {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRATION });
};

// Verify JWT token
export const verifyToken = (token: string): { userId: number } | null => {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: number };
    return decoded;
  } catch (error) {
    return null;
  }
};

// Check if the user is authenticated
export const isAuthenticated = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Check for token in auth_token cookie
    const token = req.cookies?.auth_token;
    if (!token) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    // Verify token
    const decoded = verifyToken(token);
    if (!decoded) {
      return res.status(401).json({ message: 'Invalid or expired token' });
    }

    // Get user from storage
    const user = await storage.getUser(decoded.userId);
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    // Attach user to request object
    req.user = user;
    next();
  } catch (error) {
    res.status(500).json({ message: 'Authentication error' });
  }
};

// Check if the user has a specific role
export const hasRole = (roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }

    next();
  };
};

// Login handler with enhanced security
export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    // Standard authentication logic
    const clientIp = req.ip || req.connection.remoteAddress || 'unknown';

    // Check rate limiting
    if (isRateLimited(clientIp, email)) {
      return res.status(429).json({ 
        message: 'Too many login attempts. Account temporarily locked for security.',
        lockoutTime: LOCKOUT_TIME / 60000
      });
    }

    // Find user by email
    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Validate password exists
    if (!user.password || !password) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check password with enhanced bcrypt security
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Reset login attempts on successful authentication
    resetLoginAttempts(clientIp, email);

    // Check if MFA is enabled
    if (user.mfaEnabled) {
      return res.status(200).json({
        requireMFA: true,
        message: 'MFA verification required'
      });
    }

    // Generate token
    const token = generateToken(user.id);
    const rememberMe = req.body.rememberMe || false;

    // Set cookie options
    const cookieOptions = {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict' as const,
      maxAge: rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000 // 30 days or 1 day
    };

    // Set token cookie
    res.cookie('auth_token', token, cookieOptions);

    // Return user info (excluding password)
    const { password: _, mfaSecret: __, ...userInfo } = user;
    res.status(200).json({ user: userInfo });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Authentication error' });
  }
};

// MFA verification handler
export const verifyMFA = async (req: Request, res: Response) => {
  try {
    // Validate request body
    const result = mfaSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ message: 'Invalid input data' });
    }

    const { email, token } = result.data;

    // Find user by email
    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    // Verify MFA token
    const isValid = speakeasy.totp.verify({
      secret: user.mfaSecret || '',
      encoding: 'base32',
      token,
      window: 1 // Allow 1 time step before/after for clock skew
    });

    if (!isValid) {
      return res.status(401).json({ message: 'Invalid verification code' });
    }

    // Generate token
    const jwtToken = generateToken(user.id);

    // Set cookie
    res.cookie('token', jwtToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000 // 1 day
    });

    // Return user info (excluding password and MFA secret)
    const { password: _, mfaSecret: __, ...userInfo } = user;
    res.status(200).json({ user: userInfo });
  } catch (error) {
    console.error('MFA verification error:', error);
    res.status(500).json({ message: 'MFA verification error' });
  }
};

// Logout handler
export const logout = (req: Request, res: Response) => {
  // Clear token cookie
  res.clearCookie('token');
  res.status(200).json({ message: 'Logged out successfully' });
};

// Get current user handler
export const getCurrentUser = async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }

    // Return user info (excluding password and MFA secret)
    const { password, mfaSecret, ...userInfo } = req.user;
    res.status(200).json(userInfo);
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Setup MFA for a user
export const setupMFA = async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }

    // Generate new MFA secret
    const secret = speakeasy.generateSecret({
      name: `FSM App:${req.user.email}`
    });

    // Update user with the new secret
    await storage.updateUser(req.user.id, {
      mfaSecret: secret.base32,
      mfaEnabled: false // Not enabled until verified
    });

    // Generate QR code
    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url || '');

    res.status(200).json({
      secret: secret.base32,
      qrCode: qrCodeUrl
    });
  } catch (error) {
    console.error('Setup MFA error:', error);
    res.status(500).json({ message: 'Failed to setup MFA' });
  }
};

// Verify and enable MFA for a user
export const enableMFA = async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }

    const { token } = req.body;

    // Validate token
    if (!token || typeof token !== 'string' || token.length !== 6) {
      return res.status(400).json({ message: 'Invalid verification code' });
    }

    // Get user with fresh data
    const user = await storage.getUser(req.user.id);
    if (!user || !user.mfaSecret) {
      return res.status(400).json({ message: 'MFA not set up for this user' });
    }

    // Verify token
    const isValid = speakeasy.totp.verify({
      secret: user.mfaSecret,
      encoding: 'base32',
      token,
      window: 1
    });

    if (!isValid) {
      return res.status(401).json({ message: 'Invalid verification code' });
    }

    // Enable MFA for the user
    await storage.updateUser(user.id, { mfaEnabled: true });

    res.status(200).json({ message: 'MFA enabled successfully' });
  } catch (error) {
    console.error('Enable MFA error:', error);
    res.status(500).json({ message: 'Failed to enable MFA' });
  }
};

// Disable MFA for a user
export const disableMFA = async (req: Request, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }

    // Update user to disable MFA
    await storage.updateUser(req.user.id, {
      mfaEnabled: false,
      mfaSecret: null
    });

    res.status(200).json({ message: 'MFA disabled successfully' });
  } catch (error) {
    console.error('Disable MFA error:', error);
    res.status(500).json({ message: 'Failed to disable MFA' });
  }
};

// Helper middleware for request validation
export const validate = validationMiddleware;
import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { emailEvents } from './mail';
import { verifyToken } from './auth';
import { parse } from 'cookie';
import { notificationSystem } from './notification-system';

export const setupWebSocketServer = (server: Server) => {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  // Store connected clients
  const clients = new Map<WebSocket, { userId?: number }>();

  wss.on('connection', (ws, req) => {
    console.log('WebSocket connection established');
    
    // Get cookies from request headers
    const cookies = parse(req.headers.cookie || '');
    const token = cookies.token;
    
    // Verify token if available
    if (token) {
      const decoded = verifyToken(token);
      if (decoded) {
        clients.set(ws, { userId: decoded.userId });
      } else {
        clients.set(ws, {});
      }
    } else {
      clients.set(ws, {});
    }
    
    // Handle connection close
    ws.on('close', () => {
      console.log('WebSocket connection closed');
      clients.delete(ws);
    });
    
    // Handle errors
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
    
    // Send initial message
    ws.send(JSON.stringify({ type: 'connected', message: 'Connected to WebSocket server' }));
  });
  
  // Handle incoming WebSocket messages for notification system
  wss.on('connection', (ws, req) => {
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'mark_notification_read':
            if (data.notificationId && data.userId) {
              notificationSystem.markNotificationAsRead(data.notificationId, data.userId);
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });
  });

  // Listen for notification system events
  notificationSystem.on('notification:new', (notification) => {
    broadcastToUser(notification.userId, {
      type: 'new_notification',
      notification
    });
  });

  notificationSystem.on('push:send', (data) => {
    broadcastToUser(data.userId, {
      type: 'push_notification',
      ...data.notification
    });
  });

  // Function to broadcast to specific user
  const broadcastToUser = (userId: number, message: any) => {
    const data = JSON.stringify(message);
    
    clients.forEach((client, ws) => {
      if (client.userId === userId && ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  };

  // Listen for email events and broadcast to clients
  emailEvents.on('newJob', (job) => {
    broadcast({ type: 'newJob', data: job });
    
    // Trigger notification system for new job
    if (job.id) {
      notificationSystem.triggerJobCreated(job.id, job.clientId || 0);
    }
  });
  
  emailEvents.on('emailMonitoringUpdate', (data) => {
    broadcast({ type: 'emailMonitoring', data });
  });
  
  emailEvents.on('newActivity', (activity) => {
    broadcast({ type: 'activityUpdate', data: activity });
  });
  
  emailEvents.on('jobUpdate', (job) => {
    broadcast({ type: 'jobUpdate', data: job });
    
    // Trigger notification for job status changes
    if (job.id && job.status) {
      notificationSystem.triggerJobStatusChanged(job.id, 'pending', job.status, job.assignedTo || 0);
    }
  });
  
  // Broadcast function to send messages to all connected clients
  const broadcast = (message: any) => {
    const data = JSON.stringify(message);
    
    clients.forEach((client, ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(data);
      }
    });
  };
  
  return wss;
};

import bcrypt from "bcrypt";
import { db } from "./db";
import { users } from "../shared/schema";
import { eq } from "drizzle-orm";

export async function createAdminUser() {
  return await createOwnerAccount();
}

export async function createOwnerAccount() {
  try {
    // Check if any admin users exist
    const existingAdmins = await db.select().from(users).where(eq(users.role, 'admin')).limit(1);

    if (existingAdmins.length > 0) {
      console.log('✅ Admin account already exists');
      console.log('📧 Admin email:', existingAdmins[0].email);
      console.log('🔐 Password hash exists:', !!existingAdmins[0].password);
      return;
    }

    // Create the owner account
    const hashedPassword = await bcrypt.hash('KimberleyAdmin2024!', 12);

    const [newUser] = await db.insert(users).values({
      username: 'admin',
      fullName: 'System Administrator',
      email: 'admin@kimberleyhandyman.co.za',
      role: 'admin',
      password: hashedPassword,
      mfaEnabled: false
    }).returning();

    console.log('✅ Owner account created successfully');
    console.log('📝 Login credentials:');
    console.log('   Username: admin');
    console.log('   Password: KimberleyAdmin2024!');
    console.log('⚠️  Please change the password after first login');

    return newUser;
  } catch (error) {
    console.error('❌ Error creating owner account:', error);
    throw error;
  }
}

// Create initial owner account with fallback credentials
async function ensureOwnerAccount() {
  try {
    const existingOwner = await db.select().from(users).where(eq(users.email, 'admin@kimberleyhandyman.co.za')).limit(1);
    if (existingOwner.length === 0) {
      await createOwnerAccount();
      console.log('✅ Owner account created successfully');
    } else {
      console.log('✅ Owner account already exists');
    }
  } catch (error) {
    console.error('❌ Error ensuring owner account:', error);
    // Try creating with simpler credentials as fallback
    try {
      const hashedPassword = await bcrypt.hash('Admin123!', 12);
      await db.insert(users).values({
        username: 'admin',
        email: 'admin@kimberleyhandyman.co.za',
        password: hashedPassword,
        fullName: 'System Administrator',
        role: 'admin',
        mfaEnabled: false
      });
      console.log('✅ Fallback owner account created');
       console.log('📝 Fallback Login credentials:');
       console.log('   Username: admin');
       console.log('   Password: Admin123!');
    } catch (fallbackError) {
      console.error('❌ Failed to create fallback owner account:', fallbackError);
    }
  }
}

// Execute on startup
ensureOwnerAccount();
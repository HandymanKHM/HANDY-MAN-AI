import { Request, Response, NextFunction } from 'express';
import { ZodSchema, z } from 'zod';
import { fromZodError } from 'zod-validation-error';

// Middleware for validating request body against a Zod schema
export const validationMiddleware = <T>(schema: ZodSchema<T>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = schema.safeParse(req.body);
      
      if (!result.success) {
        const validationError = fromZodError(result.error);
        return res.status(400).json({ 
          message: 'Validation failed',
          errors: validationError.details
        });
      }
      
      req.body = result.data;
      next();
    } catch (error) {
      console.error('Validation error:', error);
      res.status(500).json({ message: 'Internal server error during validation' });
    }
  };
};

// Middleware for handling async route errors
export const asyncHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

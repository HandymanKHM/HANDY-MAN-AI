import {
  users, clients, jobs, activities, emailMonitoring, files,
  type User, type InsertUser, type Client, type InsertClient,
  type Job, type InsertJob, type Activity, type InsertActivity,
  type EmailMonitoring, type InsertEmailMonitoring, type File, type InsertFile
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Storage interface for our application
export interface IStorage {
  // User related methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Client related methods
  getClient(id: number): Promise<Client | undefined>;
  getClientByEmail(email: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;

  // Job related methods
  getJob(id: number): Promise<Job | undefined>;
  getJobByClaimId(claimId: string): Promise<Job | undefined>;
  getJobs(status?: string): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, job: Partial<Job>): Promise<Job | undefined>;
  assignJob(id: number, userId: number, scheduledDate: Date): Promise<Job | undefined>;
  getJobsWithClients(): Promise<(Job & { client: Client, assignedToUser?: User })[]>;

  // Activity related methods
  getActivities(jobId?: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Email monitoring methods
  getEmailMonitoring(): Promise<EmailMonitoring | undefined>;
  updateEmailMonitoring(data: Partial<InsertEmailMonitoring>): Promise<EmailMonitoring | undefined>;

  // File management methods
  getFile(id: number): Promise<File | undefined>;
  getFileByFileId(fileId: string): Promise<File | undefined>;
  getFiles(category?: string, jobId?: number, clientId?: number): Promise<File[]>;
  createFile(file: InsertFile): Promise<File>;
  deleteFile(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    try {
      const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
      if (result.length > 0) {
        const user = result[0];
        return {
          id: user.id,
          username: user.username,
          email: user.email,
          password: user.password || '',
          fullName: user.fullName,
          role: user.role,
          mfaEnabled: user.mfaEnabled || false,
          mfaSecret: user.mfaSecret || null,
          createdAt: user.createdAt
        };
      }
      return undefined;
    } catch (error) {
      console.error('Error getting user:', error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
      if (result.length > 0) {
        const user = result[0];
        return {
          id: user.id,
          username: user.username,
          email: user.email,
          password: user.password || '',
          fullName: user.fullName,
          role: user.role,
          mfaEnabled: user.mfaEnabled || false,
          mfaSecret: user.mfaSecret || null,
          createdAt: user.createdAt
        };
      }
      return undefined;
    } catch (error) {
      console.error('Error getting user by email:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getClient(id: number): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client || undefined;
  }

  async getClientByEmail(email: string): Promise<Client | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.email, email));
    return client || undefined;
  }

  async createClient(insertClient: InsertClient): Promise<Client> {
    const [client] = await db
      .insert(clients)
      .values(insertClient)
      .returning();
    return client;
  }

  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job || undefined;
  }

  async getJobByClaimId(claimId: string): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.claimId, claimId));
    return job || undefined;
  }

  async getJobs(status?: string): Promise<Job[]> {
    if (status) {
      return await db.select().from(jobs).where(eq(jobs.status, status));
    }
    return await db.select().from(jobs);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db
      .insert(jobs)
      .values(insertJob)
      .returning();
    return job;
  }

  async updateJob(id: number, jobData: Partial<Job>): Promise<Job | undefined> {
    const [job] = await db
      .update(jobs)
      .set({
        ...jobData,
        updatedAt: new Date()
      })
      .where(eq(jobs.id, id))
      .returning();
    return job || undefined;
  }

  async assignJob(id: number, userId: number, scheduledDate: Date): Promise<Job | undefined> {
    const [job] = await db
      .update(jobs)
      .set({
        assignedTo: userId,
        scheduledDate,
        status: 'assigned',
        updatedAt: new Date()
      })
      .where(eq(jobs.id, id))
      .returning();
    return job || undefined;
  }

  async getJobsWithClients(): Promise<(Job & { client: Client, assignedToUser?: User })[]> {
    const jobsWithClients = await db
      .select()
      .from(jobs)
      .leftJoin(clients, eq(jobs.clientId, clients.id))
      .leftJoin(users, eq(jobs.assignedTo, users.id));

    return jobsWithClients.map((row) => ({
      ...row.jobs,
      client: row.clients!,
      assignedToUser: row.users || undefined
    }));
  }

  async getActivities(jobId?: number): Promise<Activity[]> {
    if (jobId) {
      return await db.select().from(activities).where(eq(activities.jobId, jobId));
    }
    return await db.select().from(activities);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db
      .insert(activities)
      .values(insertActivity)
      .returning();
    return activity;
  }

  async getEmailMonitoring(): Promise<EmailMonitoring | undefined> {
    const [monitoring] = await db.select().from(emailMonitoring).limit(1);
    return monitoring || undefined;
  }

  async updateEmailMonitoring(data: Partial<InsertEmailMonitoring>): Promise<EmailMonitoring | undefined> {
    const existing = await this.getEmailMonitoring();
    
    if (existing) {
      const [monitoring] = await db
        .update(emailMonitoring)
        .set({ ...data, updatedAt: new Date() })
        .where(eq(emailMonitoring.id, existing.id))
        .returning();
      return monitoring || undefined;
    } else {
      const [monitoring] = await db
        .insert(emailMonitoring)
        .values(data)
        .returning();
      return monitoring;
    }
  }

  async getFile(id: number): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file || undefined;
  }

  async getFileByFileId(fileId: string): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.fileId, fileId));
    return file || undefined;
  }

  async getFiles(category?: string, jobId?: number, clientId?: number): Promise<File[]> {
    let query = db.select().from(files);
    
    // Add filters based on parameters
    if (category) {
      query = query.where(eq(files.category, category));
    }
    if (jobId) {
      query = query.where(eq(files.jobId, jobId));
    }
    if (clientId) {
      query = query.where(eq(files.clientId, clientId));
    }
    
    return await query;
  }

  async createFile(file: InsertFile): Promise<File> {
    const [newFile] = await db
      .insert(files)
      .values(file)
      .returning();
    return newFile;
  }

  async deleteFile(id: number): Promise<boolean> {
    const result = await db.delete(files).where(eq(files.id, id));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
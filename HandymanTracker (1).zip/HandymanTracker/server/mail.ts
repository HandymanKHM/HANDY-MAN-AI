import { storage } from './storage';
import { EventEmitter } from 'events';
import { insertClientSchema, insertJobSchema } from '@shared/schema';

// Email monitoring event emitter
export const emailEvents = new EventEmitter();

// Mock function for monitoring emails - in a real implementation, this would use IMAP IDLE or a webhook
export const startEmailMonitoring = async () => {
  console.log('Starting email monitoring service for info@kimberleyhandyman.co.za');
  
  // Initialize or update the email monitoring status
  let monitoring = await storage.getEmailMonitoring();
  if (!monitoring) {
    monitoring = await storage.updateEmailMonitoring({
      status: 'active',
      processedCount: 0
    });
  }
  
  // In a real implementation, this would be a continuous service
  // For this demo, we'll simulate receiving emails periodically
  
  // Update monitoring status every minute
  setInterval(async () => {
    await storage.updateEmailMonitoring({
      lastChecked: new Date()
    });
    
    // Emit event for websocket to broadcast
    const updatedMonitoring = await storage.getEmailMonitoring();
    if (updatedMonitoring) {
      emailEvents.emit('emailMonitoringUpdate', formatEmailMonitoring(updatedMonitoring));
    }
  }, 60000);
  
  // Simulate receiving an email every 5 minutes
  setInterval(async () => {
    try {
      // Check if monitoring is active
      const currentMonitoring = await storage.getEmailMonitoring();
      if (!currentMonitoring || currentMonitoring.status !== 'active') {
        return;
      }
      
      // Create a simulated job from an email
      const newJob = await processNewEmail();
      
      // Update processed count
      await storage.updateEmailMonitoring({
        processedCount: (currentMonitoring.processedCount || 0) + 1
      });
      
      // Emit event for real-time updates
      emailEvents.emit('newJob', newJob);
      
      // Create an activity record
      const activity = await storage.createActivity({
        jobId: newJob.id,
        userId: 1, // System user
        activityType: 'new_job',
        description: `New job request received from ${newJob.client.insurer}`
      });
      
      emailEvents.emit('newActivity', activity);
    } catch (error) {
      console.error('Error processing simulated email:', error);
    }
  }, 300000); // 5 minutes
  
  // Return monitoring status
  return monitoring;
};

// Parse and process a new email
const processNewEmail = async () => {
  // In a real implementation, this would extract data from the email
  // For this demo, we'll create a job with random data
  
  // Sample insurers
  const insurers = ['ABSA Insurance', 'SA Home Loans', 'DIGICALL Group', 'Standard Bank Insurance'];
  const insurer = insurers[Math.floor(Math.random() * insurers.length)];
  
  // Sample service types
  const serviceTypes = ['plumbing', 'construction'];
  const serviceType = serviceTypes[Math.floor(Math.random() * serviceTypes.length)];
  
  // Generate a claim ID
  const year = new Date().getFullYear();
  const randomNum = Math.floor(1000 + Math.random() * 9000);
  const claimId = `CL-${year}-${randomNum}`;
  
  // First name pool
  const firstNames = ['James', 'Robert', 'John', 'Michael', 'William', 'David', 'Richard', 'Joseph', 'Thomas', 'Charles', 'Mary', 'Patricia', 'Jennifer', 'Linda', 'Elizabeth', 'Barbara', 'Susan', 'Jessica', 'Sarah', 'Karen'];
  
  // Last name pool
  const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Garcia', 'Rodriguez', 'Wilson', 'Martinez', 'Anderson', 'Taylor', 'Thomas', 'Hernandez', 'Moore', 'Martin', 'Jackson', 'Thompson', 'White'];
  
  // Generate random name
  const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
  const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
  const name = `${firstName} ${lastName}`;
  
  // Generate random policy number
  const policyPrefix = insurer.split(' ')[0].toUpperCase();
  const policyNum = Math.floor(10000 + Math.random() * 90000);
  const policyNumber = `${policyPrefix}-POL-${policyNum}`;
  
  // Create or get client
  const client = await storage.createClient({
    name,
    email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@example.com`,
    phone: `+27 7${Math.floor(Math.random() * 10)} ${Math.floor(100 + Math.random() * 900)} ${Math.floor(1000 + Math.random() * 9000)}`,
    address: `${Math.floor(1 + Math.random() * 100)} Diamond Street, Kimberley, Northern Cape, 8301`,
    insurer,
    policyNumber
  });
  
  // Description templates
  const descriptions = [
    `Client reported a water leak from the ceiling in the main bathroom. Urgent inspection required to determine the source of the leak and prevent further water damage. Initial assessment suggests it might be a burst pipe in the ceiling cavity.`,
    `Roof damage reported after recent storm. Multiple leaks have been identified in the living room and main bedroom. Temporary measures have been taken to catch the water, but permanent repairs are needed.`,
    `Bathroom renovation needed due to water damage from leaking shower. Tiles have become loose, and there's evidence of mold growth. Insurance has approved replacement of affected areas.`,
    `Kitchen sink pipe has burst causing water damage to cabinets and flooring. Emergency plumber applied temporary fix, but permanent repairs and cabinet replacement required.`,
    `Ceiling collapse in the hallway due to water damage from leaking roof. Temporary supports have been installed, but full reconstruction is needed. Electrical wiring may also be affected.`
  ];
  
  // Create job
  const job = await storage.createJob({
    claimId,
    clientId: client.id,
    serviceType,
    status: 'new',
    description: descriptions[Math.floor(Math.random() * descriptions.length)],
    location: client.address || '',
    priority: 'medium',
    emailData: {
      subject: `New Claim: ${claimId} - ${serviceType} services required`,
      receivedAt: new Date().toISOString(),
      sender: `claims@${insurer.toLowerCase().replace(/\s+/g, '')}.co.za`
    }
  });
  
  // Return the job with client info
  return {
    ...job,
    client
  };
};

// Format email monitoring for frontend
const formatEmailMonitoring = (monitoring: any) => {
  const lastChecked = new Date(monitoring.lastChecked);
  const now = new Date();
  const diffMs = now.getTime() - lastChecked.getTime();
  const diffMins = Math.round(diffMs / 60000);
  
  let lastCheckedFormatted = '';
  if (diffMins < 1) {
    lastCheckedFormatted = 'just now';
  } else if (diffMins === 1) {
    lastCheckedFormatted = '1 minute ago';
  } else if (diffMins < 60) {
    lastCheckedFormatted = `${diffMins} minutes ago`;
  } else if (diffMins < 120) {
    lastCheckedFormatted = '1 hour ago';
  } else {
    lastCheckedFormatted = `${Math.floor(diffMins / 60)} hours ago`;
  }
  
  return {
    ...monitoring,
    lastCheckedFormatted
  };
};

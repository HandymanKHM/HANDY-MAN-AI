import { Storage } from '@google-cloud/storage';
import { DocumentProcessorServiceClient } from '@google-cloud/documentai';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';

// Initialize Google Cloud Storage
let storageClient: Storage | null = null;
let storageInitialized = false;

function initializeStorage() {
  if (storageInitialized) {
    return storageClient;
  }

  try {
    // Check if we have proper credentials
    const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID;
    const clientEmail = process.env.GOOGLE_CLOUD_CLIENT_EMAIL;
    let privateKey = process.env.GOOGLE_CLOUD_PRIVATE_KEY;

    // Use private key as-is from environment
    if (privateKey && !privateKey.includes('-----BEGIN PRIVATE KEY-----')) {
      console.log('⚠️ Private key format appears invalid. Please check your GOOGLE_CLOUD_PRIVATE_KEY environment variable.');
      return null;
    }

    if (!projectId || !clientEmail || !privateKey) {
      console.log('⚠️ Google Cloud credentials not found. Storage features will be disabled.');
      return null;
    }

    storageClient = new Storage({
      projectId,
      credentials: {
        client_email: clientEmail,
        private_key: privateKey,
      },
    });

    storageInitialized = true;
    console.log('✅ Google Cloud Storage initialized successfully');
    return storageClient;
  } catch (error) {
    console.error('❌ Error initializing Google Cloud Storage:', error.message);
    return null;
  }
}

const storage = initializeStorage();

// Initialize Document AI
let documentAIClient: DocumentProcessorServiceClient | null = null;
let documentAIInitialized = false;

function initializeDocumentAI() {
  if (documentAIInitialized) {
    return documentAIClient;
  }

  try {
    const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID;
    const clientEmail = process.env.GOOGLE_CLOUD_CLIENT_EMAIL;
    let privateKey = process.env.GOOGLE_CLOUD_PRIVATE_KEY;

    // Use private key as-is from environment
    if (privateKey && !privateKey.includes('-----BEGIN PRIVATE KEY-----')) {
      console.log('⚠️ Private key format appears invalid. Please check your GOOGLE_CLOUD_PRIVATE_KEY environment variable.');
      return null;
    }

    if (!projectId || !clientEmail || !privateKey) {
      console.log('⚠️ Google Cloud credentials not found. Document AI features will be disabled.');
      return null;
    }

    documentAIClient = new DocumentProcessorServiceClient({
      projectId,
      credentials: {
        client_email: clientEmail,
        private_key: privateKey,
      },
    });

    documentAIInitialized = true;
    console.log('✅ Google Document AI initialized successfully');
    return documentAIClient;
  } catch (error) {
    console.error('❌ Error initializing Document AI:', error.message);
    return null;
  }
}

const documentAI = initializeDocumentAI();

const BUCKET_NAME = 'kimberley-handyman-files';
let bucket: any = null;

function getBucket() {
  if (!storageClient) {
    throw new Error('Google Cloud Storage not initialized. Please check your credentials.');
  }
  if (!bucket) {
    bucket = storageClient.bucket(BUCKET_NAME);
  }
  return bucket;
}

export interface FileUploadResult {
  fileId: string;
  originalName: string;
  mimeType: string;
  size: number;
  cloudUrl: string;
  metadata?: any;
}

export interface DocumentAnalysisResult {
  text: string;
  entities: Array<{
    type: string;
    value: string;
    confidence: number;
  }>;
  keyValuePairs: Array<{
    key: string;
    value: string;
    confidence: number;
  }>;
  tables: Array<{
    headers: string[];
    rows: string[][];
  }>;
  confidence: number;
}

export class CloudStorageService {

  /**
   * Initialize the storage bucket (create if it doesn't exist)
   */
  async initializeBucket(): Promise<void> {
    try {
      if (!storage) {
        console.log('⚠️ Skipping bucket initialization - Google Cloud Storage not available');
        return;
      }

      const bucket = getBucket();
      const [exists] = await bucket.exists();
      if (!exists) {
        await bucket.create({
          location: 'australia-southeast1', // Australian data center
          storageClass: 'STANDARD',
          versioning: { enabled: true },
          lifecycle: {
            rule: [
              {
                action: { type: 'SetStorageClass', storageClass: 'NEARLINE' },
                condition: { age: 30 }
              },
              {
                action: { type: 'SetStorageClass', storageClass: 'COLDLINE' },
                condition: { age: 365 }
              }
            ]
          }
        });
        console.log(`✅ Created storage bucket: ${BUCKET_NAME}`);
      }
    } catch (error) {
      console.error('❌ Error initializing bucket:', error);
      throw error;
    }
  }

  /**
   * Upload a file to Google Cloud Storage
   */
  async uploadFile(
    fileBuffer: Buffer,
    originalName: string,
    mimeType: string,
    category: 'invoices' | 'reports' | 'photos' | 'documents' | 'emails',
    jobId?: number,
    clientId?: number
  ): Promise<FileUploadResult> {
    try {
      if (!storage) {
        throw new Error('Google Cloud Storage not available. Please check your credentials.');
      }

      const fileId = uuidv4();
      const extension = path.extname(originalName);
      const fileName = `${category}/${fileId}${extension}`;

      const bucket = getBucket();
      const file = bucket.file(fileName);

      const metadata = {
        contentType: mimeType,
        metadata: {
          originalName,
          category,
          jobId: jobId?.toString(),
          clientId: clientId?.toString(),
          uploadedAt: new Date().toISOString(),
          fileId
        }
      };

      // Upload the file
      await file.save(fileBuffer, metadata);

      // Make file publicly readable (for authorized users)
      await file.makePublic();

      const cloudUrl = `https://storage.googleapis.com/${BUCKET_NAME}/${fileName}`;

      return {
        fileId,
        originalName,
        mimeType,
        size: fileBuffer.length,
        cloudUrl,
        metadata: metadata.metadata
      };
    } catch (error) {
      console.error('❌ Error uploading file:', error);
      throw error;
    }
  }

  /**
   * Download a file from Google Cloud Storage
   */
  async downloadFile(fileId: string, category: string): Promise<Buffer> {
    try {
      // Find file by searching metadata
      const [files] = await bucket.getFiles({
        prefix: category + '/',
      });

      const file = files.find(f => {
        const metadata = f.metadata?.metadata;
        return metadata?.fileId === fileId;
      });

      if (!file) {
        throw new Error(`File not found: ${fileId}`);
      }

      const [buffer] = await file.download();
      return buffer;
    } catch (error) {
      console.error('❌ Error downloading file:', error);
      throw error;
    }
  }

  /**
   * Delete a file from Google Cloud Storage
   */
  async deleteFile(fileId: string, category: string): Promise<boolean> {
    try {
      const [files] = await bucket.getFiles({
        prefix: category + '/',
      });

      const file = files.find(f => {
        const metadata = f.metadata?.metadata;
        return metadata?.fileId === fileId;
      });

      if (!file) {
        return false;
      }

      await file.delete();
      return true;
    } catch (error) {
      console.error('❌ Error deleting file:', error);
      return false;
    }
  }

  /**
   * List files by category or job
   */
  async listFiles(
    category?: string,
    jobId?: number,
    clientId?: number
  ): Promise<FileUploadResult[]> {
    try {
      const prefix = category ? `${category}/` : '';
      const [files] = await bucket.getFiles({ prefix });

      const results: FileUploadResult[] = [];

      for (const file of files) {
        const metadata = file.metadata?.metadata;
        if (metadata) {
          // Filter by jobId or clientId if specified
          if (jobId && metadata.jobId !== jobId.toString()) continue;
          if (clientId && metadata.clientId !== clientId.toString()) continue;

          results.push({
            fileId: metadata.fileId,
            originalName: metadata.originalName,
            mimeType: file.metadata.contentType || 'application/octet-stream',
            size: parseInt(file.metadata.size || '0'),
            cloudUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${file.name}`,
            metadata
          });
        }
      }

      return results.sort((a, b) => 
        new Date(b.metadata?.uploadedAt || 0).getTime() - 
        new Date(a.metadata?.uploadedAt || 0).getTime()
      );
    } catch (error) {
      console.error('❌ Error listing files:', error);
      return [];
    }
  }

  /**
   * Analyze document using Google Document AI
   */
  async analyzeDocument(
    fileBuffer: Buffer,
    mimeType: string,
    processorType: 'FORM_PARSER' | 'INVOICE_PARSER' | 'EXPENSE_PARSER' | 'OCR_PROCESSOR' = 'FORM_PARSER'
  ): Promise<DocumentAnalysisResult> {
    try {
      const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID!;
      const location = 'us'; // Document AI location
      const processorId = `projects/${projectId}/locations/${location}/processors/${processorType}`;

      const request = {
        name: processorId,
        rawDocument: {
          content: fileBuffer.toString('base64'),
          mimeType: mimeType,
        },
      };

      const [result] = await documentAI.processDocument(request);
      const document = result.document!;

      // Extract text
      const text = document.text || '';

      // Extract entities
      const entities = (document.entities || []).map(entity => ({
        type: entity.type || 'unknown',
        value: entity.textAnchor?.content || entity.normalizedValue?.text || '',
        confidence: entity.confidence || 0
      }));

      // Extract key-value pairs
      const keyValuePairs = (document.pages?.[0]?.formFields || []).map(field => ({
        key: field.fieldName?.textAnchor?.content || 'unknown',
        value: field.fieldValue?.textAnchor?.content || '',
        confidence: field.fieldName?.confidence || 0
      }));

      // Extract tables
      const tables = (document.pages?.[0]?.tables || []).map(table => {
        const headers: string[] = [];
        const rows: string[][] = [];

        // Process table structure
        if (table.headerRows && table.headerRows.length > 0) {
          const headerRow = table.headerRows[0];
          headerRow.cells?.forEach(cell => {
            headers.push(cell.layout?.textAnchor?.content || '');
          });
        }

        table.bodyRows?.forEach(row => {
          const rowData: string[] = [];
          row.cells?.forEach(cell => {
            rowData.push(cell.layout?.textAnchor?.content || '');
          });
          rows.push(rowData);
        });

        return { headers, rows };
      });

      return {
        text,
        entities,
        keyValuePairs,
        tables,
        confidence: document.entities?.[0]?.confidence || 0.8
      };
    } catch (error) {
      console.error('❌ Error analyzing document:', error);
      throw error;
    }
  }

  /**
   * Process invoice and extract key information
   */
  async processInvoice(fileBuffer: Buffer, mimeType: string): Promise<{
    invoiceNumber: string;
    totalAmount: number;
    currency: string;
    date: string;
    vendor: string;
    items: Array<{
      description: string;
      quantity: number;
      unitPrice: number;
      totalPrice: number;
    }>;
  }> {
    try {
      const analysis = await this.analyzeDocument(fileBuffer, mimeType, 'INVOICE_PARSER');

      // Extract invoice-specific information
      const invoiceNumber = this.extractValue(analysis.entities, 'invoice_number') || 
                           this.extractKeyValue(analysis.keyValuePairs, 'invoice') || 'N/A';

      const totalAmountStr = this.extractValue(analysis.entities, 'total_amount') || 
                            this.extractKeyValue(analysis.keyValuePairs, 'total') || '0';
      const totalAmount = parseFloat(totalAmountStr.replace(/[^0-9.]/g, '')) || 0;

      const currency = this.extractValue(analysis.entities, 'currency') || 'AUD';

      const date = this.extractValue(analysis.entities, 'invoice_date') || 
                   this.extractKeyValue(analysis.keyValuePairs, 'date') || 
                   new Date().toISOString().split('T')[0];

      const vendor = this.extractValue(analysis.entities, 'supplier_name') || 
                     this.extractKeyValue(analysis.keyValuePairs, 'vendor') || 'Unknown';

      // Extract line items from tables
      const items: Array<{
        description: string;
        quantity: number;
        unitPrice: number;
        totalPrice: number;
      }> = [];

      for (const table of analysis.tables) {
        if (table.headers.length > 0 && table.rows.length > 0) {
          table.rows.forEach(row => {
            if (row.length >= 3) {
              items.push({
                description: row[0] || 'Item',
                quantity: parseFloat(row[1]?.replace(/[^0-9.]/g, '')) || 1,
                unitPrice: parseFloat(row[2]?.replace(/[^0-9.]/g, '')) || 0,
                totalPrice: parseFloat(row[3]?.replace(/[^0-9.]/g, '')) || 0
              });
            }
          });
        }
      }

      return {
        invoiceNumber,
        totalAmount,
        currency,
        date,
        vendor,
        items
      };
    } catch (error) {
      console.error('❌ Error processing invoice:', error);
      throw error;
    }
  }

  private extractValue(entities: any[], type: string): string | null {
    const entity = entities.find(e => e.type.toLowerCase().includes(type.toLowerCase()));
    return entity?.value || null;
  }

  private extractKeyValue(keyValuePairs: any[], key: string): string | null {
    const pair = keyValuePairs.find(p => p.key.toLowerCase().includes(key.toLowerCase()));
    return pair?.value || null;
  }
}

export const cloudStorage = new CloudStorageService();

// Initialize bucket on startup
cloudStorage.initializeBucket().catch(console.error);
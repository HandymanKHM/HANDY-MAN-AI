import type { ChatMessage, ChatSession } from './gemini-assistant';

// FieldValue for Firestore operations
let FieldValue: any = null;

function getFieldValue() {
  if (!FieldValue) {
    try {
      const { FieldValue: FV } = require('firebase-admin/firestore');
      FieldValue = FV;
    } catch (error) {
      console.warn('⚠️ FieldValue not available - some Firestore operations may not work');
    }
  }
  return FieldValue;
}

// Firebase will be initialized when credentials are provided
let db: any = null;
let firebaseInitialized = false;

function initializeFirebase() {
  if (firebaseInitialized) {
    return true;
  }

  try {
    const { initializeApp, getApps, cert } = require('firebase-admin/app');
    const { getFirestore } = require('firebase-admin/firestore');
    
    const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID || "apt-deployment-457300-f0";
    const clientEmail = process.env.GOOGLE_CLOUD_CLIENT_EMAIL;
    let privateKey = process.env.GOOGLE_CLOUD_PRIVATE_KEY;

    // Use private key as-is from environment
    if (privateKey && !privateKey.includes('-----BEGIN PRIVATE KEY-----')) {
      console.log('⚠️ Invalid private key format for Firebase. Falling back to default credentials.');
      privateKey = null;
    }

    if (!getApps().length) {
      let credential;
      
      if (clientEmail && privateKey) {
        // Use service account credentials
        credential = cert({
          projectId,
          clientEmail,
          privateKey,
        });
      } else {
        // Fall back to default credentials
        const { applicationDefault } = require('firebase-admin/app');
        credential = applicationDefault();
      }

      initializeApp({
        credential,
        projectId,
      });
    }
    
    db = getFirestore();
    firebaseInitialized = true;
    console.log(`✅ Firebase initialized with project ${projectId}`);
    return true;
  } catch (error) {
    console.log('⚠️ Firebase initialization error:', error.message);
    console.log('⚠️ Firestore features will be disabled. Please check your Google Cloud credentials.');
    return false;
  }
}

export interface UserProfile {
  id: number;
  username: string;
  fullName: string;
  role: string;
  preferences: {
    preferredHelpTopics: string[];
    learningStyle: 'visual' | 'step-by-step' | 'quick-reference';
    expertiseLevel: 'beginner' | 'intermediate' | 'advanced';
  };
  interactionHistory: {
    totalSessions: number;
    commonQuestions: string[];
    masteredTopics: string[];
    needsHelp: string[];
  };
  createdAt: Date;
  lastActive: Date;
}

export interface KnowledgeEntry {
  id: string;
  topic: string;
  content: string;
  tags: string[];
  category: 'feature' | 'workflow' | 'troubleshooting' | 'best-practice';
  popularity: number;
  effectiveness: number;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
}

export interface ConversationInsight {
  id: string;
  questionPattern: string;
  commonResponse: string;
  userSatisfaction: number;
  frequency: number;
  relatedTopics: string[];
  improvements: string[];
  createdAt: Date;
}

export class FirestoreService {
  
  private get db() {
    this.ensureInitialized();
    return db;
  }
  
  private ensureInitialized(): boolean {
    if (!firebaseInitialized) {
      const initialized = initializeFirebase();
      if (!initialized) {
        throw new Error('Firestore not available. Please check your Google Cloud credentials.');
      }
    }
    return true;
  }
  
  // Chat Session Management
  async saveChatSession(session: ChatSession): Promise<void> {
    this.ensureInitialized();
    const sessionRef = this.db.collection('chatSessions').doc(session.id);
    await sessionRef.set({
      ...session,
      createdAt: session.createdAt,
      updatedAt: session.updatedAt
    });
  }

  async getChatSession(sessionId: string): Promise<ChatSession | null> {
    const sessionDoc = await this.db.collection('chatSessions').doc(sessionId).get();
    if (!sessionDoc.exists) return null;
    
    const data = sessionDoc.data()!;
    return {
      ...data,
      createdAt: data.createdAt.toDate(),
      updatedAt: data.updatedAt.toDate(),
      messages: data.messages.map((msg: any) => ({
        ...msg,
        timestamp: msg.timestamp.toDate()
      }))
    } as ChatSession;
  }

  async saveMessage(sessionId: string, message: ChatMessage): Promise<void> {
    const sessionRef = this.db.collection('chatSessions').doc(sessionId);
    
    await this.db.runTransaction(async (transaction) => {
      const sessionDoc = await transaction.get(sessionRef);
      if (sessionDoc.exists) {
        const session = sessionDoc.data()!;
        const messages = session.messages || [];
        messages.push({
          ...message,
          timestamp: new Date(message.timestamp)
        });
        
        transaction.update(sessionRef, {
          messages,
          updatedAt: new Date()
        });
      }
    });
  }

  async getUserChatHistory(userId: number, limit: number = 10): Promise<ChatSession[]> {
    const sessionsSnapshot = await this.db.collection('chatSessions')
      .where('userId', '==', userId)
      .orderBy('updatedAt', 'desc')
      .limit(limit)
      .get();

    return sessionsSnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        createdAt: data.createdAt.toDate(),
        updatedAt: data.updatedAt.toDate(),
        messages: data.messages.map((msg: any) => ({
          ...msg,
          timestamp: msg.timestamp.toDate()
        }))
      } as ChatSession;
    });
  }

  // User Profile Management
  async saveUserProfile(profile: UserProfile): Promise<void> {
    const userRef = this.db.collection('userProfiles').doc(profile.id.toString());
    await userRef.set({
      id: profile.id,
      username: profile.username,
      fullName: profile.fullName,
      role: profile.role,
      preferences: profile.preferences,
      interactionHistory: profile.interactionHistory,
      createdAt: profile.createdAt,
      lastActive: profile.lastActive
    });
  }

  async getUserProfile(userId: number): Promise<UserProfile | null> {
    const userDoc = await this.db.collection('userProfiles').doc(userId.toString()).get();
    if (!userDoc.exists) return null;
    
    const data = userDoc.data()!;
    return {
      ...data,
      createdAt: data.createdAt.toDate(),
      lastActive: data.lastActive.toDate()
    } as UserProfile;
  }

  async updateUserInteraction(userId: number, questionTopic: string, wasHelpful: boolean): Promise<void> {
    const userRef = this.db.collection('userProfiles').doc(userId.toString());
    
    await this.db.runTransaction(async (transaction) => {
      const userDoc = await transaction.get(userRef);
      if (userDoc.exists) {
        const profile = userDoc.data()! as UserProfile;
        
        // Update interaction history
        profile.interactionHistory.totalSessions += 1;
        profile.lastActive = new Date();
        
        // Track common questions
        if (!profile.interactionHistory.commonQuestions.includes(questionTopic)) {
          profile.interactionHistory.commonQuestions.push(questionTopic);
        }
        
        // Mark as mastered if consistently helpful
        if (wasHelpful && !profile.interactionHistory.masteredTopics.includes(questionTopic)) {
          profile.interactionHistory.masteredTopics.push(questionTopic);
        }
        
        transaction.update(userRef, profile);
      }
    });
  }

  // Knowledge Base Management
  async saveKnowledgeEntry(entry: KnowledgeEntry): Promise<void> {
    const entryRef = this.db.collection('knowledgeBase').doc(entry.id);
    await entryRef.set({
      ...entry,
      createdAt: entry.createdAt,
      updatedAt: entry.updatedAt
    });
  }

  async searchKnowledgeBase(query: string, category?: string): Promise<KnowledgeEntry[]> {
    let queryRef = this.db.collection('knowledgeBase')
      .orderBy('popularity', 'desc')
      .limit(10);

    if (category) {
      queryRef = queryRef.where('category', '==', category) as any;
    }

    const snapshot = await queryRef.get();
    const entries = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        createdAt: data.createdAt.toDate(),
        updatedAt: data.updatedAt.toDate()
      } as KnowledgeEntry;
    });

    // Simple text-based filtering (in production, use vector search)
    return entries.filter(entry => 
      entry.content.toLowerCase().includes(query.toLowerCase()) ||
      entry.topic.toLowerCase().includes(query.toLowerCase()) ||
      entry.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
    );
  }

  async incrementKnowledgePopularity(entryId: string): Promise<void> {
    this.ensureInitialized();
    const FV = getFieldValue();
    if (!FV) {
      console.warn('⚠️ Cannot increment popularity - FieldValue not available');
      return;
    }
    
    const entryRef = this.db.collection('knowledgeBase').doc(entryId);
    await entryRef.update({
      popularity: FV.increment(1),
      updatedAt: new Date()
    });
  }

  // Conversation Insights
  async saveConversationInsight(insight: ConversationInsight): Promise<void> {
    const insightRef = db.collection('conversationInsights').doc(insight.id);
    await insightRef.set({
      ...insight,
      createdAt: insight.createdAt
    });
  }

  async getPopularQuestions(limit: number = 5): Promise<ConversationInsight[]> {
    const snapshot = await db.collection('conversationInsights')
      .orderBy('frequency', 'desc')
      .limit(limit)
      .get();

    return snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        createdAt: data.createdAt.toDate()
      } as ConversationInsight;
    });
  }

  async updateQuestionFrequency(questionPattern: string): Promise<void> {
    const insightRef = db.collection('conversationInsights').doc(questionPattern);
    
    await db.runTransaction(async (transaction) => {
      const insightDoc = await transaction.get(insightRef);
      
      if (insightDoc.exists) {
        transaction.update(insightRef, {
          frequency: FieldValue.increment(1)
        });
      } else {
        transaction.set(insightRef, {
          id: questionPattern,
          questionPattern,
          frequency: 1,
          userSatisfaction: 0,
          commonResponse: '',
          relatedTopics: [],
          improvements: [],
          createdAt: new Date()
        });
      }
    });
  }

  // Analytics and Insights
  async getSystemUsageStats(): Promise<{
    totalSessions: number;
    activeUsers: number;
    popularTopics: string[];
    averageSatisfaction: number;
  }> {
    const [sessionsSnapshot, usersSnapshot, insightsSnapshot] = await Promise.all([
      db.collection('chatSessions').count().get(),
      db.collection('userProfiles').where('lastActive', '>', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).count().get(),
      db.collection('conversationInsights').orderBy('frequency', 'desc').limit(5).get()
    ]);

    const popularTopics = insightsSnapshot.docs.map(doc => doc.data().questionPattern);
    
    return {
      totalSessions: sessionsSnapshot.data().count,
      activeUsers: usersSnapshot.data().count,
      popularTopics,
      averageSatisfaction: 4.2 // Calculate from actual data
    };
  }

  // Learning and Improvement
  async identifyKnowledgeGaps(): Promise<string[]> {
    const lowSatisfactionInsights = await db.collection('conversationInsights')
      .where('userSatisfaction', '<', 3)
      .orderBy('frequency', 'desc')
      .limit(10)
      .get();

    return lowSatisfactionInsights.docs.map(doc => doc.data().questionPattern);
  }

  async suggestContentImprovements(): Promise<{
    topic: string;
    currentGaps: string[];
    suggestedContent: string[];
  }[]> {
    // Analyze patterns in unsuccessful conversations
    const gapInsights = await this.identifyKnowledgeGaps();
    
    return gapInsights.map(gap => ({
      topic: gap,
      currentGaps: ['Missing step-by-step guides', 'Needs visual examples'],
      suggestedContent: ['Create tutorial videos', 'Add screenshot guides', 'Develop FAQ section']
    }));
  }
  // AI Agent Orchestrator Support Methods
  async saveFeedback(feedback: any): Promise<void> {
    try {
      const feedbackRef = this.db.collection('user_feedback').doc(feedback.id);
      await feedbackRef.set({
        ...feedback,
        createdAt: feedback.createdAt || new Date(),
        updatedAt: new Date()
      });
    } catch (error) {
      console.error('Error saving feedback:', error);
      throw error;
    }
  }

  async saveAgentMemory(agentId: string, memory: any): Promise<void> {
    try {
      const memoryRef = this.db.collection('agent_memories').doc(agentId);
      await memoryRef.set({
        agentId,
        memory,
        lastUpdated: new Date()
      }, { merge: true });
    } catch (error) {
      console.error('Error saving agent memory:', error);
      throw error;
    }
  }

  async saveAgentError(errorData: any): Promise<void> {
    try {
      const errorRef = this.db.collection('agent_errors').doc();
      await errorRef.set({
        ...errorData,
        id: errorRef.id,
        timestamp: errorData.timestamp || new Date()
      });
    } catch (error) {
      console.error('Error saving agent error:', error);
    }
  }

  async updateFeedbackStatus(feedbackId: string, status: string, updates: any = {}): Promise<void> {
    try {
      const feedbackRef = this.db.collection('user_feedback').doc(feedbackId);
      await feedbackRef.update({
        status,
        ...updates,
        updatedAt: new Date()
      });
    } catch (error) {
      console.error('Error updating feedback status:', error);
      throw error;
    }
  }
}

export const firestoreService = new FirestoreService();
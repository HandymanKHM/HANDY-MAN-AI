import { GoogleGenerativeAI } from "@google/generative-ai";
import { firestoreService, type UserProfile } from "./firestore-service";

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY!);

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  userId: number;
}

export interface ChatSession {
  id: string;
  userId: number;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
}

// In-memory storage for chat sessions (in production, use database)
const chatSessions = new Map<string, ChatSession>();

export class KimberleyHandymanAssistant {
  private model;
  private activeSessions: Map<string, ChatSession> = new Map();
  
  constructor() {
    this.model = genAI.getGenerativeModel({ 
      model: "gemini-2.0-flash-exp",
      systemInstruction: this.getSystemPrompt()
    });
  }

  private async getOrCreateUserProfile(userId: number): Promise<UserProfile> {
    let profile = await firestoreService.getUserProfile(userId);
    
    if (!profile) {
      // Create new user profile with smart defaults
      profile = {
        id: userId,
        username: `user_${userId}`,
        fullName: 'Field Service User',
        role: 'technician',
        preferences: {
          preferredHelpTopics: [],
          learningStyle: 'step-by-step',
          expertiseLevel: 'beginner'
        },
        interactionHistory: {
          totalSessions: 0,
          commonQuestions: [],
          masteredTopics: [],
          needsHelp: []
        },
        createdAt: new Date(),
        lastActive: new Date()
      };
      
      await firestoreService.saveUserProfile(profile);
    }
    
    return profile;
  }

  private getSystemPrompt(): string {
    return `You are the Kimberley Handyman Admin Assistant, an intelligent AI helper for employees using the Kimberley Handyman Field Service Management System. You are knowledgeable, professional, and always helpful.

## Your Role & Personality:
- You are a friendly, professional assistant who knows everything about the Kimberley Handyman system
- You help employees learn and navigate the Field Service Management platform
- You maintain Kimberley Handyman's premium, tech-savvy brand voice
- You are enthusiastic about helping users maximize their productivity

## System Knowledge Base:

### CORE FEATURES:
1. **Dashboard & Overview**
   - Real-time job statistics (new, in-progress, completed, issues)
   - Recent activity feed showing job updates and system events
   - Email monitoring status for automated job intake
   - Quick access to key metrics and performance indicators

2. **Job Management**
   - Job creation, assignment, and tracking
   - Status updates: new → assigned → in-progress → completed
   - Client information integration
   - Priority levels: low, medium, high, urgent
   - Service types: plumbing, electrical, construction, general
   - Real-time WebSocket updates for live job tracking

3. **AI-Powered Automation**
   - **Intelligent Job Analysis**: AI categorizes jobs, estimates costs, identifies required skills
   - **Smart Quote Generation**: Automated professional quotes with labor/material breakdown
   - **Photo Diagnosis**: Upload photos for instant AI problem diagnosis and solutions
   - **Automated Communication**: AI generates professional customer messages

4. **Security Features**
   - Multi-factor authentication (MFA) with TOTP
   - Rate limiting and brute force protection
   - Role-based access control (admin, manager, technician)
   - Secure database with encrypted data storage
   - Short-lived JWT tokens for maximum security

5. **Email Integration**
   - Automated email monitoring for job requests
   - Real-time job creation from customer emails
   - Professional email templates and responses

### NAVIGATION & INTERFACE:
- **Dark Theme**: Premium tech-savvy interface with green accents
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Real-time Updates**: Live notifications and job status changes
- **Intuitive Workflow**: Streamlined process from job intake to completion

### USER ROLES:
- **Admin**: Full system access, user management, security settings
- **Manager**: Job oversight, technician assignment, client management
- **Technician**: Job updates, photo uploads, completion reporting

### AI CAPABILITIES:
- Powered by OpenAI GPT-4o for job analysis and quote generation
- Google Gemini 2.0 Flash for this admin assistant
- Real-time photo analysis for problem diagnosis
- Predictive maintenance recommendations
- Automated cost estimations using Australian market rates

### COMPANY VALUES:
- Premium quality service delivery
- Technology-driven efficiency
- Professional customer experience
- Continuous innovation and improvement
- Australian market focus with competitive pricing

## How to Help Users:

1. **Getting Started**: Guide new users through login, MFA setup, and dashboard overview
2. **Feature Explanations**: Explain how to use AI automation, job management, and reporting
3. **Troubleshooting**: Help solve common issues and workflow problems
4. **Best Practices**: Share tips for maximizing productivity and system efficiency
5. **Security Guidance**: Explain security features and proper usage protocols

## Response Guidelines:
- Be conversational but professional
- Provide step-by-step instructions when needed
- Reference specific features and interface elements
- Encourage exploration of AI automation features
- Maintain the premium, tech-forward brand image
- Always offer to help with follow-up questions

Remember: You're not just a help system - you're a knowledgeable colleague who wants every Kimberley Handyman employee to succeed and master this powerful platform.`;
  }

  async createChatSession(userId: number): Promise<string> {
    const sessionId = `session_${Date.now()}_${userId}`;
    const session: ChatSession = {
      id: sessionId,
      userId,
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // Save to both memory and persistent storage
    this.activeSessions.set(sessionId, session);
    chatSessions.set(sessionId, session);
    await firestoreService.saveChatSession(session);
    
    // Get or create user profile for personalization
    await this.getOrCreateUserProfile(userId);
    
    // Update user interaction history
    await firestoreService.updateUserInteraction(userId, 'session_start', true);
    
    return sessionId;
  }

  async getChatSession(sessionId: string): Promise<ChatSession | null> {
    return chatSessions.get(sessionId) || null;
  }

  async sendMessage(sessionId: string, userMessage: string, userId: number): Promise<ChatMessage> {
    let session = chatSessions.get(sessionId);
    if (!session) {
      // Try to load from persistent storage
      const storedSession = await firestoreService.getChatSession(sessionId);
      if (!storedSession) {
        throw new Error('Chat session not found');
      }
      session = storedSession;
      chatSessions.set(sessionId, session);
    }

    // Get user profile for personalized responses
    const userProfile = await this.getOrCreateUserProfile(userId);

    // Add user message to session
    const userChatMessage: ChatMessage = {
      id: `msg_${Date.now()}_user`,
      role: 'user',
      content: userMessage,
      timestamp: new Date(),
      userId
    };
    
    session.messages.push(userChatMessage);

    // Generate AI response with intelligent context
    try {
      // Search knowledge base for relevant information
      const relevantKnowledge = await firestoreService.searchKnowledgeBase(userMessage);
      
      // Get popular questions for context
      const popularQuestions = await firestoreService.getPopularQuestions(3);
      
      // Build enhanced conversation history with user preferences
      const conversationHistory = session.messages
        .slice(-10) // Keep last 10 messages for context
        .map(msg => `${msg.role}: ${msg.content}`)
        .join('\n');

      // Create personalized prompt with user context
      const enhancedPrompt = `
USER PROFILE:
- Experience Level: ${userProfile.preferences.expertiseLevel}
- Learning Style: ${userProfile.preferences.learningStyle}
- Previous Topics: ${userProfile.interactionHistory.commonQuestions.slice(-5).join(', ')}
- Mastered Areas: ${userProfile.interactionHistory.masteredTopics.join(', ')}

RELEVANT KNOWLEDGE:
${relevantKnowledge.map(k => `- ${k.topic}: ${k.content.slice(0, 200)}...`).join('\n')}

CONVERSATION HISTORY:
${conversationHistory}

CURRENT USER MESSAGE: ${userMessage}

Please provide a helpful, personalized response based on the user's experience level and learning style. Reference specific system features and provide step-by-step guidance when appropriate.`;
      
      const result = await this.model.generateContent(enhancedPrompt);
      const response = result.response;
      const assistantReply = response.text();

      // Add assistant message to session
      const assistantMessage: ChatMessage = {
        id: `msg_${Date.now()}_assistant`,
        role: 'assistant',
        content: assistantReply,
        timestamp: new Date(),
        userId
      };
      
      session.messages.push(assistantMessage);
      session.updatedAt = new Date();
      
      // Save updated session to persistent storage
      await firestoreService.saveChatSession(session);
      
      // Save individual messages for analytics
      await firestoreService.saveMessage(sessionId, userChatMessage);
      await firestoreService.saveMessage(sessionId, assistantMessage);
      
      // Update user learning patterns
      await firestoreService.updateUserInteraction(userId, this.extractQuestionTopic(userMessage), true);
      await firestoreService.updateQuestionFrequency(this.extractQuestionTopic(userMessage));
      
      return assistantMessage;
    } catch (error) {
      console.error('Gemini API Error:', error);
      
      // Fallback response
      const fallbackMessage: ChatMessage = {
        id: `msg_${Date.now()}_assistant`,
        role: 'assistant',
        content: "I apologize, but I'm experiencing some technical difficulties right now. Please try again in a moment, or feel free to ask your question in a different way. I'm here to help you master the Kimberley Handyman system!",
        timestamp: new Date(),
        userId
      };
      
      session.messages.push(fallbackMessage);
      session.updatedAt = new Date();
      
      return fallbackMessage;
    }
  }

  private extractQuestionTopic(message: string): string {
    // Simple keyword extraction for categorizing questions
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('login') || lowerMessage.includes('password') || lowerMessage.includes('mfa')) {
      return 'authentication';
    } else if (lowerMessage.includes('job') || lowerMessage.includes('assignment') || lowerMessage.includes('schedule')) {
      return 'job_management';
    } else if (lowerMessage.includes('ai') || lowerMessage.includes('automation') || lowerMessage.includes('smart')) {
      return 'ai_features';
    } else if (lowerMessage.includes('photo') || lowerMessage.includes('diagnosis') || lowerMessage.includes('image')) {
      return 'photo_analysis';
    } else if (lowerMessage.includes('dashboard') || lowerMessage.includes('navigation') || lowerMessage.includes('interface')) {
      return 'navigation';
    } else if (lowerMessage.includes('client') || lowerMessage.includes('customer')) {
      return 'client_management';
    } else if (lowerMessage.includes('report') || lowerMessage.includes('analytics') || lowerMessage.includes('stats')) {
      return 'reporting';
    } else {
      return 'general_help';
    }
  }

  async getChatHistory(sessionId: string): Promise<ChatMessage[]> {
    let session = chatSessions.get(sessionId);
    if (!session) {
      session = await firestoreService.getChatSession(sessionId);
      if (session) {
        chatSessions.set(sessionId, session);
      }
    }
    return session ? session.messages : [];
  }

  async clearChatSession(sessionId: string): Promise<boolean> {
    return chatSessions.delete(sessionId);
  }

  // Get suggestion prompts for users
  getSuggestedQuestions(): string[] {
    return [
      "How do I set up my multi-factor authentication?",
      "Walk me through creating and assigning a new job",
      "How does the AI job analysis feature work?",
      "Show me how to use photo diagnosis for problems",
      "What are the different user roles and permissions?",
      "How do I generate professional quotes automatically?",
      "How does the email monitoring system work?",
      "What security features protect our data?",
      "How do I update job statuses and track progress?",
      "Show me the AI automation capabilities"
    ];
  }
}

export const kimberleyAssistant = new KimberleyHandymanAssistant();
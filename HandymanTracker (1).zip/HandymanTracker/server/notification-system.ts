import { EventEmitter } from 'events';
import { storage } from './storage';
import { firestoreService } from './firestore-service';
import type { User, Job, Client } from '@shared/schema';

export interface NotificationPreferences {
  userId: number;
  emailNotifications: boolean;
  smsNotifications: boolean;
  pushNotifications: boolean;
  notificationTypes: {
    jobAssigned: boolean;
    jobStatusChanged: boolean;
    newJobCreated: boolean;
    clientUpdated: boolean;
    systemAlerts: boolean;
    emergencyAlerts: boolean;
    dailyDigest: boolean;
    weeklyReport: boolean;
  };
  quietHours: {
    enabled: boolean;
    startTime: string; // "22:00"
    endTime: string;   // "08:00"
  };
  urgencyFilter: 'all' | 'high' | 'urgent';
}

export interface Notification {
  id: string;
  userId: number;
  type: 'job_assigned' | 'job_status_changed' | 'new_job_created' | 'client_updated' | 'system_alert' | 'emergency_alert';
  title: string;
  message: string;
  urgency: 'low' | 'medium' | 'high' | 'urgent';
  data?: any;
  read: boolean;
  deliveredAt?: Date;
  readAt?: Date;
  createdAt: Date;
}

export interface SystemAlert {
  id: string;
  type: 'maintenance' | 'security' | 'performance' | 'feature_update';
  title: string;
  message: string;
  urgency: 'low' | 'medium' | 'high' | 'urgent';
  affectedUsers: number[];
  startTime?: Date;
  endTime?: Date;
  actionRequired: boolean;
  actionUrl?: string;
  createdAt: Date;
}

class NotificationSystem extends EventEmitter {
  private userPreferences: Map<number, NotificationPreferences> = new Map();
  private activeNotifications: Map<string, Notification> = new Map();
  private systemAlerts: Map<string, SystemAlert> = new Map();

  constructor() {
    super();
    this.initializeSystem();
  }

  private async initializeSystem(): Promise<void> {
    console.log('🔔 Initializing Kimberley Handyman Notification System...');
    
    // Load user preferences from database/storage
    await this.loadUserPreferences();
    
    // Set up system event listeners
    this.setupSystemEventListeners();
    
    console.log('✅ Notification System Ready!');
  }

  private async loadUserPreferences(): Promise<void> {
    try {
      // Load all users and set default preferences
      // In production, this would come from a dedicated preferences table
      const users = await this.getAllUsers();
      
      for (const user of users) {
        if (!this.userPreferences.has(user.id)) {
          this.userPreferences.set(user.id, this.getDefaultPreferences(user.id));
        }
      }
    } catch (error) {
      console.error('❌ Error loading user preferences:', error);
    }
  }

  private async getAllUsers(): Promise<User[]> {
    // This is a simplified approach - in production you'd have a proper user service
    try {
      const users: User[] = [];
      // Get users from storage (this would be implemented in your storage service)
      return users;
    } catch (error) {
      console.error('Error fetching users:', error);
      return [];
    }
  }

  private getDefaultPreferences(userId: number): NotificationPreferences {
    return {
      userId,
      emailNotifications: true,
      smsNotifications: false,
      pushNotifications: true,
      notificationTypes: {
        jobAssigned: true,
        jobStatusChanged: true,
        newJobCreated: true,
        clientUpdated: false,
        systemAlerts: true,
        emergencyAlerts: true,
        dailyDigest: true,
        weeklyReport: false,
      },
      quietHours: {
        enabled: true,
        startTime: "22:00",
        endTime: "08:00"
      },
      urgencyFilter: 'medium'
    };
  }

  private setupSystemEventListeners(): void {
    // Listen for job events
    this.on('job:assigned', this.handleJobAssigned.bind(this));
    this.on('job:status_changed', this.handleJobStatusChanged.bind(this));
    this.on('job:created', this.handleJobCreated.bind(this));
    
    // Listen for client events
    this.on('client:updated', this.handleClientUpdated.bind(this));
    
    // Listen for system events
    this.on('system:alert', this.handleSystemAlert.bind(this));
    this.on('system:emergency', this.handleEmergencyAlert.bind(this));
  }

  /**
   * Send a notification to specific users
   */
  async sendNotification(
    userIds: number[],
    type: Notification['type'],
    title: string,
    message: string,
    urgency: Notification['urgency'] = 'medium',
    data?: any
  ): Promise<void> {
    const notification: Notification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      userId: 0, // Will be set per user
      type,
      title,
      message,
      urgency,
      data,
      read: false,
      createdAt: new Date()
    };

    for (const userId of userIds) {
      const userNotification = { ...notification, userId };
      
      // Check user preferences
      if (await this.shouldSendNotification(userId, type, urgency)) {
        await this.deliverNotification(userNotification);
      }
    }
  }

  private async shouldSendNotification(
    userId: number,
    type: Notification['type'],
    urgency: Notification['urgency']
  ): Promise<boolean> {
    const preferences = this.userPreferences.get(userId);
    if (!preferences) return false;

    // Check if notification type is enabled
    const typeMapping = {
      'job_assigned': preferences.notificationTypes.jobAssigned,
      'job_status_changed': preferences.notificationTypes.jobStatusChanged,
      'new_job_created': preferences.notificationTypes.newJobCreated,
      'client_updated': preferences.notificationTypes.clientUpdated,
      'system_alert': preferences.notificationTypes.systemAlerts,
      'emergency_alert': preferences.notificationTypes.emergencyAlerts,
    };

    if (!typeMapping[type]) return false;

    // Check urgency filter
    const urgencyLevels = { low: 1, medium: 2, high: 3, urgent: 4 };
    const filterLevels = { all: 1, high: 3, urgent: 4 };
    
    if (urgencyLevels[urgency] < filterLevels[preferences.urgencyFilter]) {
      return false;
    }

    // Check quiet hours
    if (preferences.quietHours.enabled && urgency !== 'urgent') {
      const now = new Date();
      const currentTime = now.getHours() * 100 + now.getMinutes();
      const startTime = this.parseTime(preferences.quietHours.startTime);
      const endTime = this.parseTime(preferences.quietHours.endTime);
      
      if (startTime > endTime) {
        // Overnight quiet hours (e.g., 22:00 to 08:00)
        if (currentTime >= startTime || currentTime <= endTime) {
          return false;
        }
      } else {
        // Same day quiet hours
        if (currentTime >= startTime && currentTime <= endTime) {
          return false;
        }
      }
    }

    return true;
  }

  private parseTime(timeStr: string): number {
    const [hours, minutes] = timeStr.split(':').map(Number);
    return hours * 100 + minutes;
  }

  private async deliverNotification(notification: Notification): Promise<void> {
    try {
      // Store notification
      this.activeNotifications.set(notification.id, notification);
      
      // Save to persistent storage
      await this.saveNotificationToStorage(notification);
      
      // Emit real-time notification event
      this.emit('notification:new', notification);
      
      // Send through various channels based on user preferences
      const preferences = this.userPreferences.get(notification.userId);
      if (preferences) {
        if (preferences.pushNotifications) {
          await this.sendPushNotification(notification);
        }
        if (preferences.emailNotifications) {
          await this.sendEmailNotification(notification);
        }
        if (preferences.smsNotifications) {
          await this.sendSMSNotification(notification);
        }
      }
      
      notification.deliveredAt = new Date();
      
    } catch (error) {
      console.error('❌ Error delivering notification:', error);
    }
  }

  private async saveNotificationToStorage(notification: Notification): Promise<void> {
    try {
      // Save to Firestore for persistence and analytics
      await firestoreService.saveChatSession({
        id: `notification_${notification.id}`,
        userId: notification.userId,
        messages: [{
          id: notification.id,
          role: 'assistant',
          content: `${notification.title}: ${notification.message}`,
          timestamp: notification.createdAt,
          userId: notification.userId
        }],
        createdAt: notification.createdAt,
        updatedAt: notification.createdAt
      });
    } catch (error) {
      console.error('Error saving notification:', error);
    }
  }

  private async sendPushNotification(notification: Notification): Promise<void> {
    // Emit WebSocket event for real-time push notifications
    this.emit('push:send', {
      userId: notification.userId,
      notification: {
        title: notification.title,
        body: notification.message,
        icon: '/favicon.ico',
        badge: '/badge.png',
        urgency: notification.urgency,
        data: notification.data
      }
    });
  }

  private async sendEmailNotification(notification: Notification): Promise<void> {
    // Implementation would integrate with email service
    console.log(`📧 Email notification sent to user ${notification.userId}: ${notification.title}`);
  }

  private async sendSMSNotification(notification: Notification): Promise<void> {
    // Implementation would integrate with SMS service like Twilio
    console.log(`📱 SMS notification sent to user ${notification.userId}: ${notification.title}`);
  }

  // Event Handlers
  private async handleJobAssigned(data: { jobId: number; userId: number; assignedBy: number }): Promise<void> {
    try {
      const job = await storage.getJob(data.jobId);
      const assignedUser = await storage.getUser(data.userId);
      
      if (job && assignedUser) {
        await this.sendNotification(
          [data.userId],
          'job_assigned',
          'New Job Assigned',
          `You have been assigned to job #${job.claimId}: ${job.description?.substring(0, 50)}...`,
          'high',
          { jobId: job.id, claimId: job.claimId }
        );
      }
    } catch (error) {
      console.error('Error handling job assigned:', error);
    }
  }

  private async handleJobStatusChanged(data: { jobId: number; oldStatus: string; newStatus: string; updatedBy: number }): Promise<void> {
    try {
      const job = await storage.getJob(data.jobId);
      
      if (job) {
        // Notify relevant users (assigned technician, managers, etc.)
        const notifyUsers: number[] = [];
        
        if (job.assignedTo) {
          notifyUsers.push(job.assignedTo);
        }
        
        // Add managers or supervisors here
        
        await this.sendNotification(
          notifyUsers,
          'job_status_changed',
          'Job Status Updated',
          `Job #${job.claimId} status changed from ${data.oldStatus} to ${data.newStatus}`,
          data.newStatus === 'completed' ? 'high' : 'medium',
          { jobId: job.id, claimId: job.claimId, newStatus: data.newStatus }
        );
      }
    } catch (error) {
      console.error('Error handling job status change:', error);
    }
  }

  private async handleJobCreated(data: { jobId: number; createdBy: number }): Promise<void> {
    try {
      const job = await storage.getJob(data.jobId);
      
      if (job) {
        // Notify managers and available technicians
        const allUsers = await this.getAllUsers();
        const notifyUsers = allUsers
          .filter(user => user.role === 'manager' || user.role === 'technician')
          .map(user => user.id);
        
        await this.sendNotification(
          notifyUsers,
          'new_job_created',
          'New Job Available',
          `New ${job.serviceType} job: ${job.description?.substring(0, 50)}...`,
          job.priority === 'urgent' ? 'urgent' : 'medium',
          { jobId: job.id, claimId: job.claimId }
        );
      }
    } catch (error) {
      console.error('Error handling job creation:', error);
    }
  }

  private async handleClientUpdated(data: { clientId: number; updatedBy: number }): Promise<void> {
    try {
      const client = await storage.getClient(data.clientId);
      
      if (client) {
        // Notify relevant team members
        const notifyUsers = [data.updatedBy]; // Could expand this logic
        
        await this.sendNotification(
          notifyUsers,
          'client_updated',
          'Client Information Updated',
          `Client ${client.fullName} information has been updated`,
          'low',
          { clientId: client.id }
        );
      }
    } catch (error) {
      console.error('Error handling client update:', error);
    }
  }

  private async handleSystemAlert(alert: SystemAlert): Promise<void> {
    this.systemAlerts.set(alert.id, alert);
    
    await this.sendNotification(
      alert.affectedUsers,
      'system_alert',
      alert.title,
      alert.message,
      alert.urgency,
      { alertId: alert.id, actionRequired: alert.actionRequired, actionUrl: alert.actionUrl }
    );
  }

  private async handleEmergencyAlert(data: { title: string; message: string; affectedUsers: number[] }): Promise<void> {
    await this.sendNotification(
      data.affectedUsers,
      'emergency_alert',
      data.title,
      data.message,
      'urgent'
    );
  }

  // Public API Methods
  async updateUserPreferences(userId: number, preferences: Partial<NotificationPreferences>): Promise<void> {
    const current = this.userPreferences.get(userId) || this.getDefaultPreferences(userId);
    const updated = { ...current, ...preferences };
    this.userPreferences.set(userId, updated);
    
    // Save to persistent storage
    await this.saveUserPreferences(userId, updated);
  }

  private async saveUserPreferences(userId: number, preferences: NotificationPreferences): Promise<void> {
    try {
      // Save to Firestore or your preferred storage
      console.log(`💾 Saved notification preferences for user ${userId}`);
    } catch (error) {
      console.error('Error saving user preferences:', error);
    }
  }

  async getUserNotifications(userId: number, limit: number = 20): Promise<Notification[]> {
    const userNotifications = Array.from(this.activeNotifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
    
    return userNotifications;
  }

  async markNotificationAsRead(notificationId: string, userId: number): Promise<void> {
    const notification = this.activeNotifications.get(notificationId);
    if (notification && notification.userId === userId) {
      notification.read = true;
      notification.readAt = new Date();
      this.emit('notification:read', notification);
    }
  }

  async getUnreadCount(userId: number): Promise<number> {
    return Array.from(this.activeNotifications.values())
      .filter(notification => notification.userId === userId && !notification.read)
      .length;
  }

  // System Alert Methods
  async createSystemAlert(alert: Omit<SystemAlert, 'id' | 'createdAt'>): Promise<void> {
    const systemAlert: SystemAlert = {
      ...alert,
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date()
    };
    
    this.emit('system:alert', systemAlert);
  }

  async createMaintenanceAlert(
    title: string,
    message: string,
    startTime: Date,
    endTime: Date,
    affectedUsers: number[]
  ): Promise<void> {
    await this.createSystemAlert({
      type: 'maintenance',
      title,
      message,
      urgency: 'medium',
      affectedUsers,
      startTime,
      endTime,
      actionRequired: false
    });
  }

  // Trigger Methods (to be called from other parts of the system)
  triggerJobAssigned(jobId: number, userId: number, assignedBy: number): void {
    this.emit('job:assigned', { jobId, userId, assignedBy });
  }

  triggerJobStatusChanged(jobId: number, oldStatus: string, newStatus: string, updatedBy: number): void {
    this.emit('job:status_changed', { jobId, oldStatus, newStatus, updatedBy });
  }

  triggerJobCreated(jobId: number, createdBy: number): void {
    this.emit('job:created', { jobId, createdBy });
  }

  triggerClientUpdated(clientId: number, updatedBy: number): void {
    this.emit('client:updated', { clientId, updatedBy });
  }

  triggerEmergencyAlert(title: string, message: string, affectedUsers: number[]): void {
    this.emit('system:emergency', { title, message, affectedUsers });
  }
}

export const notificationSystem = new NotificationSystem();
export { NotificationSystem };
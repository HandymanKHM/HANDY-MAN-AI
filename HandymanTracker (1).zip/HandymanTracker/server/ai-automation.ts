import OpenAI from "openai";
import { storage } from "./storage";
import { Job, Client, User } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface JobAnalysis {
  category: 'plumbing' | 'electrical' | 'construction' | 'general';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedDuration: number; // hours
  estimatedCost: number; // dollars
  requiredSkills: string[];
  materials: string[];
  riskFactors: string[];
  recommendation: string;
}

export interface SmartQuote {
  laborCost: number;
  materialCost: number;
  totalCost: number;
  breakdown: {
    item: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }[];
  timeline: string;
  warranty: string;
  notes: string;
}

export interface PhotoDiagnosis {
  problem: string;
  severity: 'minor' | 'moderate' | 'major' | 'emergency';
  urgency: 'immediate' | 'within_24h' | 'within_week' | 'routine';
  solutions: string[];
  preventiveMeasures: string[];
  estimatedCost: number;
}

export class AIAutomationService {
  
  /**
   * Intelligent Job Analysis - Automatically categorizes and analyzes incoming jobs
   */
  async analyzeJob(description: string, location: string, clientHistory?: string): Promise<JobAnalysis> {
    try {
      const prompt = `
        As an expert handyman service AI, analyze this job request and provide detailed insights:
        
        Job Description: ${description}
        Location: ${location}
        ${clientHistory ? `Client History: ${clientHistory}` : ''}
        
        Provide analysis in JSON format with these fields:
        - category: plumbing, electrical, construction, or general
        - priority: low, medium, high, or urgent
        - estimatedDuration: hours as number
        - estimatedCost: estimated cost in dollars
        - requiredSkills: array of skills needed
        - materials: array of materials likely needed
        - riskFactors: array of potential risks or complications
        - recommendation: specific recommendation for handling this job
        
        Consider Australian market rates and Kimberley Handyman's premium service standards.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: "You are an expert Australian handyman service AI assistant specializing in job analysis and cost estimation. Always respond with valid JSON." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || '{}') as JobAnalysis;
    } catch (error) {
      console.error('AI Job Analysis Error:', error);
      throw new Error('Failed to analyze job with AI');
    }
  }

  /**
   * Smart Quote Generation - Creates detailed quotes automatically
   */
  async generateSmartQuote(jobDescription: string, analysis: JobAnalysis): Promise<SmartQuote> {
    try {
      const prompt = `
        Generate a detailed professional quote for this handyman job:
        
        Job: ${jobDescription}
        Category: ${analysis.category}
        Estimated Duration: ${analysis.estimatedDuration} hours
        Required Skills: ${analysis.requiredSkills.join(', ')}
        Materials: ${analysis.materials.join(', ')}
        
        Create a comprehensive quote in JSON format:
        - laborCost: total labor cost in AUD
        - materialCost: total material cost in AUD
        - totalCost: combined total in AUD
        - breakdown: array of items with quantity, unitPrice, and total
        - timeline: realistic completion timeline
        - warranty: warranty terms offered
        - notes: additional notes or recommendations
        
        Use premium Australian market rates reflecting high-quality workmanship.
        Labor rate should be $85-120/hour depending on complexity.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: "You are a professional Australian handyman service quote generator. Provide accurate, competitive pricing in Australian dollars." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      return JSON.parse(response.choices[0].message.content || '{}') as SmartQuote;
    } catch (error) {
      console.error('Smart Quote Generation Error:', error);
      throw new Error('Failed to generate smart quote');
    }
  }

  /**
   * Photo Diagnosis - Analyzes photos to diagnose problems
   */
  async analyzePhoto(base64Image: string, description?: string): Promise<PhotoDiagnosis> {
    try {
      const prompt = `
        Analyze this image of a handyman/maintenance issue and provide expert diagnosis:
        ${description ? `Additional context: ${description}` : ''}
        
        Provide diagnosis in JSON format:
        - problem: clear description of the issue
        - severity: minor, moderate, major, or emergency
        - urgency: immediate, within_24h, within_week, or routine
        - solutions: array of recommended solutions
        - preventiveMeasures: array of preventive measures
        - estimatedCost: rough cost estimate in AUD
        
        Consider Australian building standards and safety requirements.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt },
              {
                type: "image_url",
                image_url: { url: `data:image/jpeg;base64,${base64Image}` }
              }
            ]
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
        max_tokens: 1000
      });

      return JSON.parse(response.choices[0].message.content || '{}') as PhotoDiagnosis;
    } catch (error) {
      console.error('Photo Analysis Error:', error);
      throw new Error('Failed to analyze photo');
    }
  }

  /**
   * Intelligent Scheduling - Optimizes technician assignments
   */
  async optimizeScheduling(jobs: Job[], technicians: User[], date: Date): Promise<{
    assignments: { jobId: number; technicianId: number; timeSlot: string; reasoning: string }[];
    efficiency: number;
    recommendations: string[];
  }> {
    try {
      const jobsData = jobs.map(job => ({
        id: job.id,
        location: job.location,
        priority: job.priority,
        estimatedDuration: job.estimatedDuration || 2,
        serviceType: job.serviceType
      }));

      const techData = technicians.map(tech => ({
        id: tech.id,
        skills: tech.skills || [],
        location: tech.location || 'Central',
        availability: 8 // hours per day
      }));

      const prompt = `
        Optimize technician scheduling for ${date.toISOString().split('T')[0]}:
        
        Jobs: ${JSON.stringify(jobsData)}
        Technicians: ${JSON.stringify(techData)}
        
        Create optimal assignments considering:
        - Travel time between locations
        - Technician skills matching job requirements
        - Priority levels
        - Workload balance
        
        Return JSON with:
        - assignments: array of {jobId, technicianId, timeSlot, reasoning}
        - efficiency: score 0-100
        - recommendations: array of optimization suggestions
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: "You are an expert scheduling optimization AI for field service operations." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.4
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error('Scheduling Optimization Error:', error);
      throw new Error('Failed to optimize scheduling');
    }
  }

  /**
   * Automated Customer Communication - Generates professional messages
   */
  async generateCustomerMessage(type: 'confirmation' | 'update' | 'completion' | 'follow-up', 
                                job: Job, client: Client, customDetails?: string): Promise<{
    subject: string;
    message: string;
    tone: string;
  }> {
    try {
      const prompt = `
        Generate a professional customer communication for Kimberley Handyman:
        
        Type: ${type}
        Job: ${job.description}
        Service: ${job.serviceType}
        Client: ${client.name}
        ${customDetails ? `Details: ${customDetails}` : ''}
        
        Create professional messaging in JSON format:
        - subject: email subject line
        - message: full message content (use proper formatting)
        - tone: description of the tone used
        
        Use Kimberley Handyman's premium, professional, tech-savvy brand voice.
        Include relevant details and maintain customer confidence.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: "You are Kimberley Handyman's professional communication AI, known for premium service and clear, confident messaging." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.6
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error('Customer Message Generation Error:', error);
      throw new Error('Failed to generate customer message');
    }
  }

  /**
   * Predictive Maintenance Analysis - Identifies potential issues before they become problems
   */
  async analyzePredictiveMaintenance(clientHistory: string, jobPatterns: string[]): Promise<{
    riskAreas: string[];
    recommendations: string[];
    timeframe: string;
    preventiveCost: number;
    emergencyCost: number;
  }> {
    try {
      const prompt = `
        Analyze maintenance patterns to predict future issues:
        
        Client History: ${clientHistory}
        Job Patterns: ${jobPatterns.join(', ')}
        
        Provide predictive analysis in JSON format:
        - riskAreas: areas likely to need attention
        - recommendations: specific preventive actions
        - timeframe: when issues might occur
        - preventiveCost: estimated cost of prevention in AUD
        - emergencyCost: estimated cost if issues become emergencies
        
        Focus on Australian residential/commercial maintenance patterns.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: "You are a predictive maintenance AI expert specializing in Australian building systems and handyman services." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error('Predictive Maintenance Error:', error);
      throw new Error('Failed to analyze predictive maintenance');
    }
  }
}

export const aiAutomation = new AIAutomationService();
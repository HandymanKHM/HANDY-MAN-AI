import { pgTable, text, serial, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("technician"),
  mfaSecret: text("mfa_secret"),
  mfaEnabled: boolean("mfa_enabled").default(false),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  rememberMe: z.boolean().optional()
});

export const mfaSchema = z.object({
  email: z.string().email(),
  token: z.string().length(6).regex(/^\d+$/)
});

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  insurer: text("insurer").notNull(),
  policyNumber: text("policy_number"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertClientSchema = createInsertSchema(clients).omit({
  id: true,
  createdAt: true
});

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  claimId: text("claim_id").notNull().unique(),
  clientId: integer("client_id").references(() => clients.id),
  serviceType: text("service_type").notNull(),
  status: text("status").notNull().default("new"),
  description: text("description"),
  location: text("location"),
  priority: text("priority").default("medium"),
  assignedTo: integer("assigned_to").references(() => users.id),
  scheduledDate: timestamp("scheduled_date"),
  completedDate: timestamp("completed_date"),
  emailData: jsonb("email_data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => jobs.id),
  userId: integer("user_id").references(() => users.id),
  activityType: text("activity_type").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true
});

export const emailMonitoring = pgTable("email_monitoring", {
  id: serial("id").primaryKey(),
  lastChecked: timestamp("last_checked").defaultNow(),
  status: text("status").notNull().default("active"),
  processedCount: integer("processed_count").default(0)
});

export const insertEmailMonitoringSchema = createInsertSchema(emailMonitoring).omit({
  id: true
});

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  fileId: text("file_id").notNull().unique(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  category: text("category").notNull(), // 'invoices', 'reports', 'photos', 'documents', 'emails'
  cloudUrl: text("cloud_url").notNull(),
  jobId: integer("job_id").references(() => jobs.id),
  clientId: integer("client_id").references(() => clients.id),
  uploadedBy: integer("uploaded_by").references(() => users.id),
  analysisResult: text("analysis_result"), // JSON string from Document AI
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertFileSchema = createInsertSchema(files).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  emailNotifications: boolean("email_notifications").default(true),
  smsNotifications: boolean("sms_notifications").default(false),
  pushNotifications: boolean("push_notifications").default(true),
  jobAssigned: boolean("job_assigned").default(true),
  jobStatusChanged: boolean("job_status_changed").default(true),
  newJobCreated: boolean("new_job_created").default(true),
  clientUpdated: boolean("client_updated").default(false),
  systemAlerts: boolean("system_alerts").default(true),
  emergencyAlerts: boolean("emergency_alerts").default(true),
  dailyDigest: boolean("daily_digest").default(true),
  weeklyReport: boolean("weekly_report").default(false),
  quietHoursEnabled: boolean("quiet_hours_enabled").default(true),
  quietHoursStart: text("quiet_hours_start").default("22:00"),
  quietHoursEnd: text("quiet_hours_end").default("08:00"),
  urgencyFilter: text("urgency_filter").default("medium"), // 'all', 'high', 'urgent'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  notificationId: text("notification_id").notNull().unique(),
  userId: integer("user_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // 'job_assigned', 'job_status_changed', etc.
  title: text("title").notNull(),
  message: text("message").notNull(),
  urgency: text("urgency").default("medium"), // 'low', 'medium', 'high', 'urgent'
  data: jsonb("data"), // Additional data payload
  read: boolean("read").default(false),
  deliveredAt: timestamp("delivered_at"),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Login = z.infer<typeof loginSchema>;
export type MFAVerify = z.infer<typeof mfaSchema>;

export type Client = typeof clients.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;

export type EmailMonitoring = typeof emailMonitoring.$inferSelect;
export type InsertEmailMonitoring = z.infer<typeof insertEmailMonitoringSchema>;

export type File = typeof files.$inferSelect;
export type InsertFile = z.infer<typeof insertFileSchema>;

export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
